## Logic Chain Review

### Logic Chain Diagnostic

The chain is coherent in its negative half and weak in its positive half. C3 is the best-closed contract: three out-of-corpus questions, five verified-absent questions in the eighteen-arm battery, and two non-gold E8 probes all produced explicit not-found reports, while the oversized-catalog false refusal is correctly classified as a transport execution failure rather than semantic absence. The verifier-ordering result is internally coherent in Results: on the same logged pools, with the same scores and the same top-five read window, fusion order gives Hit@5 0.94, judge-score ordering gives 0.44, and retaining fusion order among recorded survivors gives 0.94. The paper repeatedly distinguishes association from causation and null from negative evidence (E6, E8, Discussion). The weaknesses are claim-to-design upgrades: "separates" is used for a filter that removed nothing; "supported" is used for a placement mechanism that was not isolated; "substrate effect rather than run noise" is inferred from one run per grid; and "names its gold document" is inferred from an answer-or-trace string check.

| Link | Promise / question | Evidence | Status | Breakpoint |
|---|---|---|---|---|
| C1 placement | content, not filename, drives placement; checks validate consequences | E1 membership 0.875 (en) and 1.0 (zh, ja) on Wikipedia; E2 three-source check on 33/322 documents; E8 says the scope test does not measure placement accuracy | outcome observed; mechanism untested | B2 |
| C2 admission | verifier score is an admission signal | E4/E6: 191 recorded scores exceed 0.5, filter replay equals fusion order, judge ordering loses golds; E8 gate ablation null | filtering not identified; ordering negative | B1, B7, B9 |
| C3 absence | answer layer reports completed absence | E5 3/3 out-of-corpus; E5b 5/5 verified-absent; E8 2/2; transport false refusal classified as execution failure | observed at answer layer; not server-enforced | — |
| RQ1 | management layer: parsing, admission, placement, lifecycle | E1--E2; E3 | answered as operational observation; E3 is unmapped | B12 |
| RQ2 | answer quality per question and interface | E5: two 30-cell grids | identifier/lexical only; gold availability and metric issues | B3, B4 |
| RQ3 | configurations compare on document recall and evidence markers | E4 tool layer; E5 citation markers | recall plus citation syntax; "evidence markers" not measured | B10 |
| RQ4 | verifier should order or only filter | E4/E6/E8 | ordering rejected; filtering untested; the disjunction is unresolved | B1, B7, B9 |
| RQ5 | abstention, cost, execution reliability | E5/E5b/E7 | mostly observed; E7 is capacity, not end-to-end | — |
| Conclusion | contributions 1--3 | E1--E8 | negative diagnostic closed; management and filter claims overreach | B8, B9 |

```mermaid
flowchart TD
  A["Intro: C1-C3, RQ1-RQ5"] --> B["Related work gap: three commitments (B11)"]
  B --> C["Methods: C1 supported (B2); C2 filter untested; C3 observed"]
  C --> D["E1-E2: management audits"]
  D --> E["E3: experience store, no RQ (B12)"]
  E --> F["E4-E6: verifier diagnostic (B1, B7, B9)"]
  F --> G["E5: 30-cell grids; BQ03 (B3); gold-ID metric (B4); marker count (B6)"]
  G --> H["E7-E8: non-functional and null ablations"]
  H --> I["Discussion: substrate effect (B5)"]
  I --> J["Conclusion: storage audit (B8); filter acceptability (B9)"]
  J --> K["Closure: partial"]
```

### Breakpoints (quoted)

- (Type: concept shift)
  - Quote + Location: "A same-pool diagnostic that separates verifier \emph{ordering} from verifier \emph{filtering}." — Introduction, Contributions; the Discussion repeats the "separating" framing.
  - Why this breaks: The same-pool replay holds the candidate set and scores fixed, and all 191 recorded scores exceed the 0.5 threshold. The "filter" arm therefore retains every recorded survivor in fusion order and is identical to fusion-only by construction. E4 states this directly: "the filter replay is identical to fusion order by construction and does not test filtering." The design isolates the ordering effect at the configured threshold; it does not produce an independent estimate of the filtering role. "Separates" claims that both roles were varied or tested. The further phrase "so the loss is attributable to the induced ordering, not to filtering" is valid for this no-filter run, but it is not a general exoneration of filtering at other cuts.
  - Minimal fix: Reword to "isolates the ordering effect at the configured threshold; filtering at other thresholds was not tested." Delete "separates" from the contribution and the Discussion, and keep the bounded E4 conclusion.

- (Type: over-inference)
  - Quote + Location: "C1 is supported by these mechanical checks together with one membership measurement that does not use the ingest naming convention" — Methods, Section 3.1.
  - Why this breaks: The mechanical checks validate storage state and three-source consistency; C1 itself says they do not validate semantic routing accuracy. The only placement-accuracy figure is the cross-lingual membership result (0.875 English, 1.0 Chinese/Japanese), an outcome measure on a different corpus. It does not show that the ingest agent used parsed content rather than filename or title cues. E8 is explicit that the scope diagnostic "do not independently measure the accuracy of the ingest agent's placement decision," and E1 calls membership "the one filename-independent placement measurement" but not a mechanism test. "Supported" upgrades an outcome correlation into support for the content-informed mechanism.
  - Minimal fix: Downgrade to "partly supported" or "consistent with"; state that the content-versus-filename mechanism is not isolated. Either add a routing ablation or restrict C1 to "placement outcomes are mostly correct on the cross-lingual corpus."

- (Type: logical jump)
  - Quote + Location: "The same contracts carry to the arXiv grid: every gold was present in the substrate its arm searched, all 30 cells answer" — Results, E5b, second-corpus replication.
  - Why this breaks: E4 reports that "BQ03's gold paper was not retrievable" and gives 0.90 over all ten questions and 1.00 over the nine with available gold. E5's table nevertheless records BQ03's gold (2212.13138) as present in every answer cell, and the text says every answer names its gold document. The paper never reconciles whether BQ03's gold was absent from the retrievable corpus, present but unretrieved, or present in an arm-specific substrate. If it was absent, gold-ID coverage can be satisfied by parametric memory or a non-substrate source and is not a retrieval-grounded result. This is the one hard contradiction in a headline claim.
  - Minimal fix: Define "retrievable," "present," and "substrate" consistently; report per-question gold availability for both grids and the provenance of each gold-ID hit (retrieved trace versus model output). If BQ03's gold was absent, exclude it from the "every answer" claim and report it as an answer/memory check separately.

- (Type: concept shift)
  - Quote + Location: "every answer names its gold document" — Abstract; Discussion first implication; Conclusion.
  - Why this breaks: Methods defines the end-to-end gold-hit as whether "the answer or recorded retrieval trace contains the gold identifier"; E5 repeats "gold-ID presence in the answer or trace." The measured property is a string match, not that the answer names the document, cites it, or that the document was retrieved. The paper itself says the checks are "traceability, not entailment" and "do not establish semantic support." The Abstract, Results, Discussion, and Conclusion upgrade the metric to "names its gold document" and "locates the right document," which is a different claim. The Discussion's recommendation to judge on "provenance" inherits the same ambiguity: the provenance measure is the same identifier-presence check, not a source-resolution audit.
  - Minimal fix: Say "every answer or trace contains the gold identifier" and report answer-only and trace-only rates separately. Reserve "names," "cites," and "locates" for a check that verifies the answer's citation to the retrieved document.

- (Type: over-inference)
  - Quote + Location: "so the change is a substrate effect rather than run noise" — Discussion, first implication.
  - Why this breaks: The two grids differ in substrate and in run (the original grid is from 2026-10-13; the replication is rerun5-2026-10-17), and each grid is one run per arm. There is no within-substrate repeat, so directional consistency of the discordant cells cannot separate a substrate effect from a run-level or model-version shift. The marker result (9/7/2 to 9/9/9) supports that the marker ordering is not a stable interface property; it does not establish that substrate is the cause. The strict component rests on five discordant cells (exact McNemar p=0.0625), not significant at 0.05, yet the Abstract says the replication "shows" strict keyword counts are substrate-bound. The Threats section itself says each grid is one run per arm.
  - Minimal fix: Replace the causal sentence with "associated with the substrate change; with one run per grid, substrate and run cannot be separated." Report model and harness version stability across the two dates, and add a repeat run if the causal claim is retained. Treat the strict difference as suggestive (p=0.0625), not as part of a "shows" claim.

- (Type: logical jump)
  - Quote + Location: "the two grids agree on gold ID in 30, alias coverage in 28, strict coverage in 25 and marker presence in 18" — Results, E5.
  - Why this breaks: Thirty paired cells minus 18 agreements leaves 12 disagreements, but the next clause reports "all nine marker disagreements." The table implies 21 agreements and 9 disagreements (P 10 + F 8 + D 3). The McNemar p=0.0039 corresponds to 9 discordant pairs, so "18" is the inconsistent number. As written, the paired-cell accounting does not compose, and the substrate-bound inference is presented with an arithmetic error.
  - Minimal fix: Correct the agreement count to 21 (or explain the denominator); re-check the paired counts and the McNemar input.

- (Type: concept shift)
  - Quote + Location: "The archived pools store the survivors of each judged pool rather than the dropped list, so the filter role cannot be re-derived beyond the recorded scores." — Discussion, Threats to validity (Execution and grading).
  - Why this breaks: E4 and E6 describe the 191 scores as the logged twelve-candidate pools (twelve per question, eleven for Q14), which would show that every pooled candidate passed 0.5. The Threats section says the archived pools store survivors rather than the dropped list. If the 191 are survivors, "all recorded scores exceed 0.5" is a survivor-selected observation and the claim that the 0.5 cut "filtered nothing" cannot be established because the dropped candidates are absent. If the 191 are the full twelve-candidate pools, the Threats sentence is wrong. One Q14 fused candidate also has no recorded score. The Abstract states the absolute "the 0.5 cut filtered nothing" without either caveat.
  - Minimal fix: State explicitly whether the 191 are full twelve-candidate pools or survivors. Release the full pool with all scores, including below-threshold candidates, and the dropped list; if the archive is survivor-only, downgrade to "no recorded survivor fell below 0.5; the dropped list is unavailable."

- (Type: over-inference)
  - Quote + Location: "In the demonstration instance these checks hold in place: 322 stored parts pass storage and content audits" — Conclusion.
  - Why this breaks: E2 reports the content check on all 322 documents but the three-source consistency check on a 33-document sample, one tenth of the corpus. It also reports a rename defect (18 versus 9 vector chunks until force re-index) and two lifecycle failures (task status, update check). The Conclusion's 322 figure implies a full storage audit and omits those recorded defects, even though the next sentence says the layer records its failures.
  - Minimal fix: "322 parts pass the content check; a 33-document storage/consistency sample passes; one rename defect and two lifecycle failures were observed." Add these to the Conclusion's failure list, or qualify the 322 figure as a content-only audit.

- (Type: over-inference)
  - Quote + Location: "A verifier score that is acceptable as an admission filter should not be assumed usable as a ranker." — Conclusion.
  - Why this breaks: The study never establishes that the score is acceptable as a filter. All 191 recorded scores pass 0.5, the filter removes nothing, no answer-level test of a higher cut was run, and E6 says the analysis "does not establish calibration"; E4 says it "does not establish that the verdicts reliably identify evidence." Passing a threshold is not evidence of filter validity. The supported lesson is conditional: a score that merely survives an admission threshold is not thereby validated as a ranker.
  - Minimal fix: "A verifier score that has passed an admission threshold should not be assumed usable as a ranker"; or "the present study provides no evidence that the verifier is a valid filter."

- (Type: concept shift)
  - Quote + Location: "how the tested retrieval configurations compare on document recall and evidence markers" — Introduction, RQ3.
  - Why this breaks: E5 measures "recognized citation markers" such as section or table locators and explicitly says they "do not establish that a cited section exists or supports the sentence citing it." E4 says marker counts are substrate-bound. No evidence or claim-support marker is measured. RQ3 is therefore answered only for document recall and citation-syntax counts, not for "evidence markers." The Discussion's RQ3 closure ("tool-layer recall separately from end-to-end source-marker checks") confirms the split but does not rename the construct.
  - Minimal fix: Rename the RQ to "document recall and citation-marker counts," or add a claim-support measure. State in the RQ closure that RQ3 is answered only on recall and marker presence.

- (Type: concept shift)
  - Quote + Location: "The study treats three design commitments as questions to test" — Introduction, Related work, Research gap.
  - Why this breaks: The Introduction lists five RQs. The research-gap paragraph says the study treats three design commitments as questions and lists (i) content-informed placement and lifecycle checks, (ii) verifier re-ranking versus fusion order, and (iii) absence reporting. That set drops C2's admission role, RQ2 (answer quality), and RQ3 (retrieval comparison), and it reframes C2 from admission to ordering. The reader cannot map the five RQs to the three test questions, and the contract-to-experiment chain is not one-to-one. Section 3 then reintroduces the three contracts without reconciling them with the five RQs.
  - Minimal fix: Add one explicit mapping (contract to RQ to experiment) in the Introduction or at the start of the Evaluation, or enumerate all five RQs in the research-gap paragraph. Do not describe the three commitments as the complete set of test questions.

- (Type: logical jump)
  - Quote + Location: "One scenario and thirteen candidates cannot support an effectiveness claim" — Results, E3.
  - Why this breaks: E3 is included in the evaluation, but no RQ asks about operational-experience distillation. RQ1 enumerates parsing, admission, placement, and lifecycle and omits the experience store; the three contributions omit it too. The paper itself says the evidence cannot support an effectiveness claim, and the approval path was never exercised. E3 therefore has no argumentative function in the chain and consumes a main-text subsection. E7 is only loosely tied to RQ5's execution-reliability clause and reports capacity, not end-to-end reliability.
  - Minimal fix: Add an explicit RQ or contribution that E3 answers, or move E3 to the supplement as a bounded case observation and remove it from the main chain.

Anti-sycophancy accounting: challenges_made=14; surrenders=2; surrender_rate=0.14; frame_lock_alert=false. The two withdrawn challenges were (i) the Abstract's wall-clock/cost sentence, because E5 explicitly scopes it to a single-run observation rather than an efficiency result, and (ii) the Abstract's "21 of 100" attribution, because E1 and the Abstract both state that the failure inventory is incomplete and the count is not attributed to parsing alone. Both implicit rebuttals scored 4/5. The deliverable JSON is an issues array; this paragraph carries the bundle-level accounting.
