\section{Introduction}
\label{sec:intro}

Enterprises record regulations, failure analyses and operational lessons in
unstructured documents. A document collection becomes a knowledge base only
when three things hold: its documents are parsed and admitted reliably, they
are organized so that the right material can be found, and the system can
answer a question with a citation whose source is traceable. Answering a
question such as \emph{why did edge delamination appear in a photovoltaic
inspection?} requires the report that records the decision, the evidence
inside it and an accurate pointer to both. Retrieval-augmented generation
(RAG) addresses discovery by embedding queries and passages in a shared vector
space \cite{rag-lewis,dpr}; agentic systems extend this process by letting a
language model call retrieval tools \cite{mcp,singh-agentic-rag}. Yet semantic
similarity measures topical relatedness, not whether a passage contains
evidence for the requested claim \cite{siren,gao-ragsurvey}.

The relevant capabilities are usually treated separately. Retrieval asks
whether a relevant passage enters a ranked list. Knowledge management governs
how documents are organized and maintained. Document AI recovers text, tables
and formulas from complex layouts \cite{mineru}. In operational systems, these
operations form one dependency chain: parsing errors affect indexing, placement
limits what retrieval can see, and ranking alone cannot establish whether a
candidate supports an answer. A knowledge-base management system has to own
this chain, yet no single stage in common deployments owns the property the
user actually needs---that the sentence being cited is supported by the
document being cited.

This paper presents QDCVR (Query-Driven Content-Verified Retrieval), a
self-hosted knowledge-base management system that treats content as the
shared object across acquisition, organization and question answering. It
organizes the workflow around three design contracts:

\begin{enumerate}
\item \emph{Content informs placement.} An ingest agent uses the parsed body
to choose a library and derive descriptions or tags; server-side checks
validate storage state and consistency, not semantic routing accuracy.
\item \emph{Content informs admission.} When the retrieval workflow invokes
the server-side Laya tool, it fetches and scores candidate segments and returns
survivors with provenance; the score is an admission signal, not truth.
\item \emph{Absence is reported.} The answer workflow instructs the agent to
report the searched scope when a completed evidence review finds no support.
Tool failures and incomplete searches are execution failures, not evidence of
semantic absence.
\end{enumerate}

The platform integrates document parsing, content-informed
organization, lifecycle management, operational experiences, multi-lane
retrieval and a Model Context Protocol (MCP) server with 95 registered tools
\cite{mcp}. It runs locally and exposes retrieval functions to several agent
harnesses. Untested functions are identified rather than inferred from their
implementation.

\noindent\textbf{Contributions.}
\begin{enumerate}
\item A self-hosted knowledge-base management system that links quality-gated
acquisition, content-informed placement, three-source consistency and lifecycle
operations, with an invoked server-side evidence gate on the query path. The
management layer is described function by function, from parse admission to
lifecycle audits (Sections~\ref{sec:system}--\ref{sec:implementation}).
\item An answer-level evaluation over ten questions crossed with three
retrieval interfaces in two 30-cell grids (original and common-substrate),
reported per question: gold-identifier
presence, strict and alias-aware keyword coverage, recognized citation markers,
and abstention on verified-absent questions (Section~\ref{sec:e5},
Table~\ref{tab:e5-answers}).
\item A same-pool diagnostic that separates verifier \emph{ordering} from
verifier \emph{filtering}. Ordering candidates by the verifier score lowers
Hit@5 from 0.94 to 0.44, while retaining fusion order among recorded survivors
restores 0.94; all 191 recorded scores exceed the configured threshold, so the
loss is attributable to the induced ordering, not to filtering. A verifier
score that survives an admission filter is therefore not thereby usable as a
ranker (Sections~\ref{sec:lanes} and~\ref{sec:e4}--\ref{sec:e6}).
\end{enumerate}

A CIKM~2026 demonstration introduced the organization and retrieval layers
\cite{qdcvr-demo}. The journal extension adds acquisition and lifecycle
measurements, the operational-knowledge case study, and the verifier-placement
and transport-failure analyses. The architecture and retrieval interface build
on the demo; the contribution claimed here is the additional evidence and
failure analysis, not a wholly new system.

\subsection{Research questions and reading guide}
\label{sec:rq}

Five questions structure the design-to-evidence sequence, ordered by the
weight of the answer rather than by the pipeline: how the management layer
behaves on demonstration and public collections, covering parsing, admission, placement and
lifecycle (RQ1); what answer quality the end-to-end workflow reaches on a fixed
question set, measured per question and per interface (RQ2); how the tested
retrieval configurations compare on document recall and evidence markers
(RQ3); whether a verifier score should order candidates or only filter them
(RQ4); and what abstention, cost and execution-reliability observations arise
in end-to-end trials (RQ5).

Section~\ref{sec:related} positions the work; Sections~\ref{sec:system}--
\ref{sec:organization} describe the architecture and management functions;
Section~\ref{sec:lanes} specifies retrieval and verification;
Section~\ref{sec:implementation} covers deployment and enforcement; and
Section~\ref{sec:eval} evaluates the system, followed by implications,
limitations and conclusions in
Sections~\ref{sec:discussion}--\ref{sec:conclusion}.
