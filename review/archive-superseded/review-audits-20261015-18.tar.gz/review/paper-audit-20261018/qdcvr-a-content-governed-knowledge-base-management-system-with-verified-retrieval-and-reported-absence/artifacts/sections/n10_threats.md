\section{Threats to validity}
\label{sec:threats}

\noindent\textbf{Corpus and scale.} The results cover bounded demonstration and public
collections and a small arXiv-based corpus. Retrieval-only modes searched live
libraries, whereas lexical and dense baselines used a corpus index; these are
not identical retrieval substrates. The three answer arms of the original
grid also differ in substrate (default library scope, exported file tree,
800-character mirror), so that grid compares interface plus substrate; the
30-cell replication pins every arm to the same five libraries, and the marker
differences do not survive it. The three-source consistency
check is a 33-document sample, one tenth of the 322-document corpus, not a full
audit. Findings should not be generalized to larger or differently organized
collections without replication.

\noindent\textbf{Question construction and denominators.} Questions and gold
annotations were developer-authored. The two three-arm grids of
Section~\ref{sec:e5} are ten questions of one question family on one model,
each run once per arm: the platform arm's latency separation holds in both,
but the citation separation does not survive the common substrate, and the
grids cannot resolve differences smaller than one cell. The grounding reading
is at ceiling in both. Two answers in the original grid contain
an evidence-insufficiency qualifier; the grader's
\texttt{insufficient\_evidence} flag is a substring test that also fires when
the phrase appears inside a fully answering text, so we read those two flags
as measurement artifacts, not as hedges. Agent-track retrieval
hits are inferred from trace and answer, while citation checks provide the
more direct functional measure.

\noindent\textbf{Execution and grading.} The refusal battery has one final
observation per arm after rerunning two MCP-mount interruptions. Fabrication
checks were manually audited, and the binary gate required reclassification
of one body-level partial answer. Retrieval-only elapsed time is not directly
comparable to end-to-end agent latency. The E5 grader is deterministic but
lexical: its gold-ID, keyword and citation-marker checks do not establish
semantic claim support; gold-ID presence is checked in the answer or the
recorded trace, and keyword coverage passes at $\lceil 3n/5\rceil$ of the
annotated terms, so a missing term can still pass. Aliases are reported as a
separate regrade. The 30-cell grid and its controlled replication are each one run
per arm on one model, recorded as claude-opus-4-8[1m]; the paired analysis in
Section~\ref{sec:e5} bounds the stable reads. Three cells of the original grid
departed from the stated contract (Section~\ref{sec:e5}), and one platform
answer in the replication contains a short Chinese phrase. The archived pools store the survivors of each judged pool rather
than the dropped list, so the filter role cannot be re-derived beyond the
recorded scores. The BQ06 gold key was corrected to the source paper's
thermodynamic reading after inspection, and declared aliases cover known
word-form variants and Chinese renderings; the pre-correction question set and
its grade (strict 10/9/9) are retained alongside the corrected regrade (strict
9/9/9), and both sets are frozen for this submission in
\path{paper-kbs/tex/journal_20p/.frozen-experiment-sha256.txt}, so the
two-grade disclosure cannot drift after review. The
MCP lifecycle script passed its 16 direct assertions and the stdio protocol
test passed, but the lifecycle script is not pytest-collection-safe because it
calls \texttt{sys.exit} at module import.

{% keep the closing paragraph off a one-line orphan at a column foot;
% the blank line must sit inside this group so \par sees the penalty
\clubpenalty=10000
\noindent\textbf{Scope.} Tests ran on a single local workstation and one
verifier checkpoint. They do not establish generalization across model hosts,
large-scale corpora, independently authored questions, operator adoption,
adversarial access or crash-mid-write recovery. The pagination repair was
verified on selected catalog and query cases; broader transport boundary
testing remains necessary.

}

