# Back matter and appendix

%% ===== source: n_back.tex =====
%% n_back.tex — back matter, included by main_20p.tex after n11_conclusion.tex
%% and before the bibliography. This file is the single source of truth for
%% every declaration; n11_conclusion.tex carries the Conclusion and nothing else.
%%
%% Section order follows the KBS Guide for Authors: CRediT, competing interest,
%% funding, ethics, data availability and acknowledgements after the
%% Conclusion; the appendix follows them; the mandated generative-AI
%% declaration is placed last so that it sits before the reference list, which
%% is where the guide requires it.
%%
%% AUTHOR ACTION: replace the CRediT names, confirm the funding wording, and
%% adjust or remove the acknowledgements.

\section*{CRediT authorship contribution statement}
\textbf{Author 1:} Conceptualization, Methodology, Software, Investigation,
Data curation, Writing -- original draft. \textbf{Author 2:} Validation,
Writing -- review \& editing, Supervision. %% AUTHOR ACTION: adjust.

\section*{Declaration of competing interest}
The authors declare that they have no known competing financial interests
or personal relationships that could have appeared to influence the work
reported in this paper.

\section*{Funding}
This research did not receive any specific grant from funding agencies in
the public, commercial, or not-for-profit sectors. %% AUTHOR ACTION

\section*{Ethics statement}
This article does not report studies involving human participants, human
data, or animals.

\section*{Data availability}
The platform source code, campaign logs and scripts, gold question sets,
replays and per-run JSON records cited in this paper are available at
\url{https://github.com/kingdol666/rag-knowledge} (benchmark suite:
\texttt{benchmark-suite/}; paper artifacts: \texttt{paper-kbs/}). The
evaluation inventory is indexed in \path{TEST-RESULTS/ARTIFACTS.md}. Within
\texttt{benchmark-suite/}: the end-to-end grid of Section~\ref{sec:e5} is
\path{results/runs/run-20261013T094350Z-5f9faac/}; original-annotation grades
are in \path{results/exp_r2_grade_original_revised.json}; corrected
annotations and their regrade are in
\path{data/papers/qa_questions_e5_corrected.json} and
\path{results/exp_r2_grade_corrected.json}; the grader is
\path{scripts/107_exp_grade.py}; and superseded campaigns stay in
\path{results/archive-superseded/}. Derived latency and cost statistics are in
\path{paper-kbs/tex/journal_20p/e5_numbers.json}. The corrected annotation set
is frozen for this submission (version ``2026-10-14 corrected evaluation
annotations'', frozen 2026-10-16, SHA-256
\texttt{86b07a9370984d42\ldots e62ece}), and the annotations, the
pre-correction question set and the grader are pinned together in
\path{paper-kbs/tex/journal_20p/.frozen-experiment-sha256.txt} so every
reported grade can be re-derived exactly. The supplementary material
(\path{paper-kbs/supplementary/supplementary-material.pdf}) carries the
campaign inventory, the appendix tables S1--S5 that
\ref{app:perq} cites, and the evaluation tables S6--S8. The 42-document industrial corpus is a demonstration
instance prepared for this study and is not customer data; it is not included
in the public repository, but the demonstration documents are available from
the authors on request. The headline ordering comparison does not depend on
its text: the judge-ordering row recomputes from the
released per-candidate scores in
\path{paper-kbs/experiments/results/exp1_retrieval.json}, the released gold
annotations and the grader, and the fusion lists behind the derived rows are
released for the anatomy query of Fig.~\ref{fig:anatomy} and retained per
question in the campaign records. An end-to-end re-run would additionally
require a substitute corpus; its construction recipe is documented with an
illustrative synthetic sample
(\path{paper-kbs/notes/industrial-corpus-substitute-recipe-2026-10-16.md}).

\section*{Acknowledgments}
The authors thank the maintainers of the open-source components the platform
builds on. %% AUTHOR ACTION: adjust or remove.

\appendix
\setcounter{table}{0}
\section{Supplementary tables}
\label{app:perq}

Eight tables are carried in the supplementary material
(\path{paper-kbs/supplementary/supplementary-material.pdf}) rather than in
this build: Table~S1, the stores read by the three-source checks; S2, the
cross-lingual ingestion result; S3, the sixteen gold questions with their
design intent; S4, the per-question best-gold-rank grid; S5, the
lifecycle-operation outcomes, including the two that failed; and S6--S8, the
verdict-score threshold sweep and the two source-presence audits.
The per-question grid localizes the aggregate metrics: judge-score re-ranking
misses eight golds that remain in the fusion order, the derived survivor
replay restores those ranks but inherits Q16's upstream miss, and the Q14
candidate without a recorded score remains unclassified. The S1--S5 LaTeX
sources are archived under
\path{paper-kbs/tex/journal_20p/_appendix-archived/}; S6--S8 are generated by
the scripts named in the supplement.

%% AUTHOR ACTION: confirm the service names (and add versions if the editors
%% ask) before submission. The two agent CLIs named here are the harnesses the
%% authors used on this project; repository state is not otherwise a source for
%% this declaration.
\section*{Declaration of generative AI and AI-assisted technologies in the manuscript preparation process}
During the preparation of this work the authors used the Anthropic Claude
Code and ZCode command-line coding agents in order to assist with experiment
execution, data tabulation, figure preparation and manuscript drafting. After
using these tools, the authors reviewed and edited the content as needed and
take full responsibility for the content of the publication. All experimental
numbers originate from logged runs of the system on the authors'
machine.
