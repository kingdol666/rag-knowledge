\section{Evaluation}
\label{sec:eval}

We evaluate the system on three corpora differing in origin, language
and scale, and we separate two questions: whether the management layer keeps
its collections in a usable state, and what the answers built on those
collections are worth. Sections~\ref{sec:e1}--\ref{sec:e3} cover the
management layer: acquisition and parsing, organization and three-source
consistency, and the operational-experience store. Sections
\ref{sec:e4}--\ref{sec:e8} cover the query path: retrieval quality
(Section~\ref{sec:e4}), answer quality per question and abstention
(Section~\ref{sec:e5}, the paper's end-to-end evidence), a deployment-layer
replication through the public API (Section~\ref{sec:sysarms}), verifier
failure (Section~\ref{sec:e6}), non-functional behavior (Section~\ref{sec:e7})
and the gate and search-scope ablations (Section~\ref{sec:e8}). Numbers are
reported against the corpus that produced them, never merged; the campaign
inventory and per-question tool-layer results are supplementary material.

\subsection{Experimental setup}
\label{sec:eval-setup}

\textbf{Corpora.} (i)~\emph{Industrial demonstration corpus}: five libraries
hold 42 documents prepared as a demonstration instance, not customer data; one
library contains twenty near-duplicate
equipment-telemetry reports sharing prefixes, vocabulary and structure---a
deliberate stressor for near-duplicate detection and confuser
density~\cite{manku-near-dup-2007}; sixteen gold questions and four
out-of-corpus probes ran against it. (ii)~\emph{arXiv corpus}: 100 submitted
papers spanning about 25 domains, 79 retrievable at evaluation time and routed
by content into five domain libraries holding 322 stored parts; ten gold
questions (BQ01--BQ10) target papers referenced by those papers, keyed by arXiv
identifier, and the running instance held 19 libraries. (iii)~\emph{Cross-lingual
ingestion corpus}: 400 Wikipedia pages per language (English, Chinese,
Japanese), 40 extractive cloze queries each with verbatim in-page answers;
ingestion only, no retrieval-quality numbers reported.

\textbf{Questions and gold annotations.} The sixteen industrial questions were
authored, not sampled from logs; each identifies one or two gold documents by
a unique filename fragment and one to three fact markers. Q16 includes a token
also present in its gold filename, so a filename-ranking retriever could match
it without reading content; we retain this limitation and report a sensitivity
check in Section~\ref{sec:e4}. The arXiv answer grader
checks gold-ID presence in the answer or trace plus a word-boundary keyword
rule that counts a cell as covered when it matches at least $\lceil 3n/5\rceil$
of the $n$ annotated terms; it does not assess semantic support. Citation
markers are counted separately by a deterministic pattern and do not assess
source resolution or claim-to-source entailment.

\textbf{Metric families.} Retrieval uses Hit@5, Recall@5 and MRR@5, following
passage-ranking conventions~\cite{craswell-msmarco-2021}; Hit@5 and Recall@5
are document-level over the top five returned documents, and MRR@5 is $1/r$
for the first gold at rank $r\le 5$ and zero otherwise.
nDCG@5~\cite{jarvelin-cumulated-gain-2002} was computed only inside one
exploratory arm we do not report. The end-to-end "gold-hit" measure checks
whether the answer or recorded retrieval trace contains the gold identifier;
keyword coverage is a deterministic lexical proxy. Citation counts record
whether the answer contains a part, section or table marker under the stated
pattern. These checks support traceability and marker-presence claims, not
semantic faithfulness or claim-to-source support, for which model-based
measures such as RAGAS~\cite{es-ragas-2024} or ARES~\cite{saad-falcon-ares-2024}
are designed. The third metric family covers wall-clock time, agent turns,
tool calls, cost and whether refusals were appropriate.

\textbf{Controls.} The deterministic retrieval lanes were re-run and compared
field by field, latency excluded; the 27-cell stability suite
(Section~\ref{sec:e7}) and the eighteen-arm honesty battery
(Section~\ref{sec:sysarms}) carry repeats, whereas the 30-cell answer grid of
Section~\ref{sec:e5} is a single run per arm on one model, recorded in the run
timeline as claude-opus-4-8[1m] with seed~0 and harness prompt v4-neutral, and
is reported as such, as is its controlled replication. The fixed retry
policy (one retry for
an empty zero-turn response or transient gateway timeout) fired twice,
succeeding both times. Before measurement we repaired two corpus-integrity
faults through the platform's own operations: one document missing from its
vector collection was re-indexed, and one library whose collection had been
lost was rebuilt, the same failure class that Section~\ref{sec:e2} measures. The tool-layer
retrieval lanes, grading rule, audits, duplicate adjudication and cross-lingual
ingestion pipeline are deterministic; agent lanes and text-derived results are
not.

\begin{table*}[t]
\centering
\footnotesize
\setlength{\tabcolsep}{4pt}
\caption{Functional checks on the management layer. Each row names the
function, the test and its scale, the observed outcome, and the subsection
that reports it. The numbers are those of the cited campaigns; none is
re-estimated. A passing check means the stated property was observed on the
stated scale, not that the function is exhaustively verified.}
\label{tab:kb-checks}
\begin{tabular}{@{}>{\raggedright\arraybackslash}p{0.115\textwidth}>{\raggedright\arraybackslash}p{0.265\textwidth}>{\raggedright\arraybackslash}p{0.39\textwidth}>{\raggedright\arraybackslash}p{0.10\textwidth}@{}}
\toprule
Function & Test and scale & Observed outcome & Where\\
\midrule
Parse and ingest & 100-paper campaign; nine checks per paper & nine checks per paper, all pass; 91 names in the state file, 79 retrievable at evaluation, 21 unattributable (twelve recorded plus nine unrecorded) & E1\\
Parse quality & 50-paper, 26-domain campaign & 50/50 parsed and verified, all probes ok; 202 tags; 41 tag flags negative without blocking ingestion & E1\\
Structural split & 50 papers at the 30{,}000-character tier & 165 documents (9 whole, 156 parts) in 2{,}672\,s; storage 50/50; descriptions and tags 165/165 & E1\\
Near-duplicate review & 322-document corpus, 0.90 threshold & 35 candidate groups (0.90--0.975), zero true duplicates, nothing deleted & E2\\
Content placement & 100 papers into five libraries; 400 pages per language & 322 stored parts; membership 0.875 (en) and 1.0 (zh, ja) & E1--E2\\
Three-source consistency & Full corpus and 33-document spot check & 322/322 content and 33/33 storage; one rename defect (18 vs 9 chunks) until force re-index & E2\\
Lifecycle operations & 16 scenarios on two disposable libraries & create, move, delete and forced re-index pass; two failures (task status, update check) & E2\\
Sub-library hierarchy & Three-level disposable fixture & create, parent-to-child move, listing, reading and judging all pass & E2\\
Tags and graph & 316-tag registry; 658-node graph & 165 documents pass the tag check in 47.6\,s; four tag edges on one document move 4{,}675 to 4{,}679 & E2\\
Experience store & One small knowledge base; one end-to-end scenario & 13 candidate drafts; one lesson retrieved first at 0.711; approval path unexercised & E3\\
\bottomrule
\end{tabular}
\end{table*}

\subsection{E1: Acquisition and parsing}
\label{sec:e1}

The 100 submitted papers were parsed and content-routed into five domain
libraries, producing 322 stored parts after the 30{,}000-character split. The
submission funnel does not reconcile on its face: 91 names appear in the ingest
state file and 79 papers were retrievable at evaluation, so twelve recorded
papers never became retrievable, and nine submitted papers never entered the
state file. The 21 unretrievable papers are the sum of those twelve and nine,
and neither attempts against failed papers nor per-paper parse status is
recorded, so the 21 cannot be attributed to parsing alone
\cite{missier-prov-2013}. Reported failure modes are formula-dense scans and
one tool-layer crash during batch parsing, restarted from a checkpoint.
Table~\ref{tab:kb-checks} lists every functional check with its scale and
outcome.

The cross-lingual benchmark ran twice over 400 pages per language and
reproduced round~1 bit-for-bit, with ingestion success 1.0; storage
completeness, self-retrieval Hit@1 and the membership figures are in
Table~S2. Its English membership accuracy of 0.875 is an organization
defect---the page stored in the wrong library roughly one time in eight---not
a parsing defect. Membership is scored against the benchmark's source category labels, not a
naming convention derived by the ingest agent, so it is the one
filename-independent placement measurement in this paper.

A second 50-paper, 26-domain campaign parsed and verified every paper, indexed
them in batch, reported all probes ok, and left 41 of 50 documents with a
negative tag flag even though verification passed, so tag-quality failures
never blocked ingestion.
One stage re-ran on inbox ordering, and more than 800 extracted images were
not uploaded. Descriptions and tags are checked against content before
storage~\cite{park-metadata-quality-2009}.


\subsection{E2: Organization, consistency, and management operations}
\label{sec:e2}


Organizational correctness is three-source consistency: disk files, the tree
index and per-library metadata must agree on document existence, location and
indexed content. Under that definition we found one real defect in a
disposable test library: after a rename the vector index kept the old name's
chunks---count 18 where 9 were expected, a duplicate search matching the
document against its own former path at 0.9738 similarity, a vector probe
returning every chunk twice at identical scores. Only an explicit force
re-index removed them, restoring the count to 9. The failure is invisible from
the metadata alone.

The reorganization campaign over the 322-document corpus passed its content
check on all 322 documents and its three-source consistency check on a
33-document sample, one tenth of the corpus; the duplicate review held no true
duplicate and deleted nothing. Sub-library splitting and hierarchy
creation ran on a disposable three-level fixture: creation with a parent
reference, a parent-to-sub-library move, and listing, reading and judging
through sub-library addresses all returned correct results. A parent catalog
lists its sub-libraries as container entries carrying their own descriptions,
the one-call view that ladder navigation reads.

Growing from 50 to 100 papers cost no retrieval quality: dense top-1 hits moved
from 48/50 to 49/50 and MRR from 0.98 to 1.00, recorded as a post hoc
held-within-5-pp band
$\pm$5\,pp. In the 16 lifecycle scenarios, create, move, delete and forced
re-index behaved as specified (Table~S5). Two failures remain: the task-status
tool reports \texttt{running} after \texttt{finished\_at} is written, and the
update check timed out after 30\,s while every other probe passed. Merge and
split were never exercised under controlled conditions, so we claim nothing
about them.

The tag registry held 316 tags; the tag-quality check passed 165
documents with zero failures in 47.6\,s, and orphan tags accumulate (test tags,
section titles), for which a dry-run detector exists. In one case test-library
tags leaked into the main registry, the failure mode vocabulary-based
organization is prone to~\cite{golder-tagging-2006}. The document graph is
navigation, never evidence: four tag edges on one document moved the edge count
from 4{,}675 to 4{,}679.
