# 1 Introduction / 2 Related work

%% ===== source: n1_intro.tex =====
\section{Introduction}
\label{sec:intro}

Enterprises record regulations, failure analyses and operational lessons in
unstructured documents. A document collection becomes a knowledge base only
when three things hold: its documents are parsed and admitted reliably, they
are organized so that the right material can be found, and the system can
answer a question with a citation whose source is traceable. Answering a
question such as \emph{why did edge delamination appear in a photovoltaic
inspection?} requires the report that records the decision, the evidence
inside it and an accurate pointer to both. Retrieval-augmented generation
(RAG) addresses discovery by embedding queries and passages in a shared vector
space \cite{rag-lewis,dpr}; agentic systems extend this process by letting a
language model call retrieval tools \cite{mcp,singh-agentic-rag}. Yet semantic
similarity measures topical relatedness, not whether a passage contains
evidence for the requested claim \cite{siren,gao-ragsurvey}.

The relevant capabilities are usually treated separately. Retrieval asks
whether a relevant passage enters a ranked list. Knowledge management governs
how documents are organized and maintained. Document AI recovers text, tables
and formulas from complex layouts \cite{mineru}. In operational systems, these
operations form one dependency chain: parsing errors affect indexing, placement
limits what retrieval can see, and ranking alone cannot establish whether a
candidate supports an answer. A knowledge-base management system has to own
this chain, yet no single stage in common deployments owns the property the
user actually needs---that the sentence being cited is supported by the
document being cited.

This paper presents QDCVR (Query-Driven Content-Verified Retrieval), a
self-hosted knowledge-base management system that treats content as the
shared object across acquisition, organization and question answering. It
organizes the workflow around three design contracts:

\begin{enumerate}
\item \emph{Content informs placement.} An ingest agent uses the parsed body
to choose a library and derive descriptions or tags; server-side checks
validate storage state and consistency, not semantic routing accuracy.
\item \emph{Content informs admission.} When the retrieval workflow invokes
the server-side Laya tool, it fetches and scores candidate segments and returns
survivors with provenance; the score is an admission signal, not truth.
\item \emph{Absence is reported.} The answer workflow instructs the agent to
report the searched scope when a completed evidence review finds no support.
Tool failures and incomplete searches are execution failures, not evidence of
semantic absence.
\end{enumerate}

The platform integrates document parsing, content-informed
organization, lifecycle management, operational experiences, multi-lane
retrieval and a Model Context Protocol (MCP) server with 95 registered tools
\cite{mcp}. It runs locally and exposes retrieval functions to several agent
harnesses. Untested functions are identified rather than inferred from their
implementation.

\noindent\textbf{Contributions.}
\begin{enumerate}
\item A self-hosted knowledge-base management system that links quality-gated
acquisition, content-informed placement, three-source consistency and lifecycle
operations, with an invoked server-side evidence gate on the query path. The
management layer is described function by function, from parse admission to
lifecycle audits (Sections~\ref{sec:system}--\ref{sec:implementation}).
\item An answer-level evaluation over ten questions crossed with three
retrieval interfaces in two 30-cell grids (original and common-substrate),
reported per question: gold-identifier
presence, strict and alias-aware keyword coverage, recognized citation markers,
and abstention on verified-absent questions (Section~\ref{sec:e5},
Table~\ref{tab:e5-answers}).
\item A same-pool diagnostic that separates verifier \emph{ordering} from
verifier \emph{filtering}. Ordering candidates by the verifier score lowers
Hit@5 from 0.94 to 0.44, while retaining fusion order among recorded survivors
restores 0.94; all 191 recorded scores exceed the configured threshold, so the
loss is attributable to the induced ordering, not to filtering. A verifier
score that survives an admission filter is therefore not thereby usable as a
ranker (Sections~\ref{sec:lanes} and~\ref{sec:e4}--\ref{sec:e6}).
\end{enumerate}

A CIKM~2026 demonstration introduced the organization and retrieval layers
\cite{qdcvr-demo}. The journal extension adds acquisition and lifecycle
measurements, the operational-knowledge case study, and the verifier-placement
and transport-failure analyses. The architecture and retrieval interface build
on the demo; the contribution claimed here is the additional evidence and
failure analysis, not a wholly new system.

\subsection{Research questions and reading guide}
\label{sec:rq}

Five questions structure the design-to-evidence sequence, ordered by the
weight of the answer rather than by the pipeline: how the management layer
behaves on demonstration and public collections, covering parsing, admission, placement and
lifecycle (RQ1); what answer quality the end-to-end workflow reaches on a fixed
question set, measured per question and per interface (RQ2); how the tested
retrieval configurations compare on document recall and evidence markers
(RQ3); whether a verifier score should order candidates or only filter them
(RQ4); and what abstention, cost and execution-reliability observations arise
in end-to-end trials (RQ5).

Section~\ref{sec:related} positions the work; Sections~\ref{sec:system}--
\ref{sec:organization} describe the architecture and management functions;
Section~\ref{sec:lanes} specifies retrieval and verification;
Section~\ref{sec:implementation} covers deployment and enforcement; and
Section~\ref{sec:eval} evaluates the system, followed by implications,
limitations and conclusions in
Sections~\ref{sec:discussion}--\ref{sec:conclusion}.

%% ===== source: n2_related.tex =====
\section{Related work}
\label{sec:related}

\subsection{Knowledge management and document acquisition}
Public knowledge bases organize facts under explicit ontologies
\citep{auer-dbpedia-kb-2007,hoffart-yago2-kb-2013}, whereas enterprise content
management emphasizes governance over organizational documents
\citep{paivarinta-ecm-2005,tyrvaainen-ecm-2006}. Research on organizational
knowledge explains how tacit experience becomes shareable
\citep{nonaka-seci-1994,nonaka-seci-ba-2000}; adjacent work studies metadata
quality, tagging, human review and auditability
\citep{park-metadata-quality-2009,golder-tagging-2006,mosqueira-rey-hitl-2022,barredo-arrieta-xai-2020}. These strands motivate reliable placement
and governance, but do not by themselves connect those controls to evidence-
checked answers. Document-AI methods, including layout-aware analysis and
MinerU, recover text and structure from complex documents
\citep{zhong-publaynet-layout-2019,huang-layoutlmv3-docai-2022,mineru}. Near-
duplicate detection and provenance provide complementary safeguards during
ingestion \citep{manku-near-dup-2007,missier-prov-2013,cheney-provenance-2009}.
QDCVR treats acquisition quality and traceable indexing as prerequisites for
reliable retrieval rather than as preprocessing assumptions.

\subsection{Retrieval, organization and agentic search}
RAG grounds generated responses in retrieved passages \citep{rag-lewis}; dense
retrievers learn shared query--passage representations \citep{dpr}, while BM25
remains a strong lexical baseline \citep{bm25}. Hybrid retrieval combines
sparse and dense signals, including reciprocal-rank fusion
\citep{rrf-cormack}; embedding models such as BGE-M3 support multilingual and
multi-granularity search \citep{bge-m3}. Graph-based systems organize and
retrieve structured relationships: GraphRAG adds entity-relation graphs and
community summaries \citep{graphrag}, LightRAG uses dual-level retrieval
\citep{lightrag}, and RAPTOR builds hierarchical document representations
\citep{raptor}. QDCVR uses a narrower document--library--tag graph for
navigation and candidate expansion; the graph does not establish answer
evidence on its own.

Tool-using agents extend retrieval through iterative interaction
\citep{react-yao,toolformer}. MCP standardizes access to tool servers
\citep{mcp}, while Modular RAG and agentic-retrieval surveys describe
reconfigurable retrieval pipelines and their efficiency challenges
\citep{modular-rag,singh-agentic-rag}. DeepRead demonstrates structure-aware
navigation for agentic search \citep{deepread}; QDCVR similarly exposes a
catalog-first librarian lane, alongside dense and hybrid alternatives, under
explicit call and tool policies.

\subsection{Verification, correction and abstention}
Self-RAG and CRAG integrate evidence assessment or retrieval correction into
generation \citep{selfrag,crag}; FLARE triggers retrieval during generation
\citep{flare}. Other work studies selective prediction under domain shift,
ontology-grounded retrieval and citation verification
\citep{kamath,cyberbot,liu-verifiability,gao-citations}. QDCVR externalizes
verification as a reusable server-side operation: the gate fetches document
text, judges evidence and returns provenance to the answer layer. This design
makes the verifier inspectable, but not infallible.

The LLM-as-a-judge literature documents preference bias, imperfect agreement,
listwise instability and self-preference \citep{zheng-llmjudge,sun-urara,panickssery-selfpref}; verifier gaming is an additional concern
\citep{lightman-verify}. These findings motivate separating evidence
verification from rank ordering and testing abstention at the answer layer.

\subsection{Research gap}
\label{sec:gap}

Table~\ref{tab:positioning} compares representative strands rather than every
system in the literature. Prior work already studies selective question
answering, citation verifiability and retrieval correction; the distinction
here is not that abstention or evidence checks are absent from prior research.
The gap this study addresses is one of integration and of role separation
rather than of missing capabilities: QDCVR examines how acquisition checks,
content-informed placement, retrieval and answer-time evidence inspection
interact in one knowledge-base workflow, reports where implementation
and transport boundaries constrain that workflow, and measures separately the
two roles a verifier can play. The table therefore motivates an
integration question, not a universal claim that earlier systems lack reusable
verification or inspectable evidence.

The study treats three design commitments as questions to test: whether
content-informed placement and lifecycle checks expose collection state;
whether a retrieved document should be re-ranked by a verifier or retain its
fusion order; and whether agent workflows can report absence while separating
completed negative searches from execution failures. Its contribution is a
knowledge-base management workflow that owns the chain from parse admission to
answer citation, a per-question account of the answers that chain produces,
and a same-pool diagnostic showing that ordering by the verifier score, not
threshold filtering, is where the measurable loss sits. It proposes no new
ranking algorithm and does not claim that the underlying retrieval problem is
solved.

\begin{table*}[t]
\centering
\small
\setlength{\tabcolsep}{4pt}
\renewcommand{\arraystretch}{1.18}
\caption{Positioning. Each strand addresses part of the path from stored
document to answer. QDCVR studies a knowledge-base workflow combining content-informed
acquisition and placement, server-side checks when invoked, and answer-layer
reporting; the evaluation measures selected components and boundaries in
Section~\ref{sec:eval}.}
\label{tab:positioning}
\begin{tabular}{@{}>{\raggedright\arraybackslash}p{0.145\textwidth}>{\raggedright\arraybackslash}p{0.285\textwidth}>{\raggedright\arraybackslash}p{0.24\textwidth}>{\raggedright\arraybackslash}p{0.24\textwidth}@{}}
\toprule
Strand & Representative work & What it optimizes & What it leaves to the deployment\\
\midrule
Knowledge management & Public knowledge bases \citep{auer-dbpedia-kb-2007,hoffart-yago2-kb-2013}; enterprise content management \citep{paivarinta-ecm-2005,tyrvaainen-ecm-2006} & An explicit ontology, or governance over a curated collection & Whether an answer drawn from that collection is supported by the text it cites\\
Document AI & Layout-aware extraction \citep{zhong-publaynet-layout-2019,huang-layoutlmv3-docai-2022}; MinerU \citep{mineru} & Recovery of text, tables and formulas from difficult layouts & Whether what was recovered is complete enough to index, and where it is then stored\\
Retrieval & Dense \citep{dpr}, lexical \citep{bm25} and hybrid ranking \citep{rrf-cormack,bge-m3} & Rank quality over a corpus that is assumed indexed & Whether a top-ranked candidate contains evidence for the claim it is used to support\\
Graph-structured organization & GraphRAG \citep{graphrag}, LightRAG \citep{lightrag}, RAPTOR \citep{raptor} & Multi-hop and hierarchical relationships between documents & Evidentiary status: a graph edge is a navigation fact, not evidence\\
Self-reflective generation & Self-RAG \citep{selfrag}, CRAG \citep{crag}, FLARE \citep{flare}; judge-based verification \citep{zheng-llmjudge,lightman-verify} & Evidence assessment or retrieval correction in generation workflows & How verification and abstention interact with knowledge-base acquisition and organization in a knowledge-base workflow\\
Agentic tool use & ReAct \citep{react-yao}, MCP \citep{mcp}, DeepRead \citep{deepread} & Access to retrieval tools behind a stable interface & Whether configured retrieval budgets and failure states are exposed and checked in a particular deployment\\
\midrule
QDCVR (this work) & Sections~\ref{sec:system}--\ref{sec:lanes} & An integration of content-informed placement, indexed-state checks, an invoked server-side evidence gate and agent answer reporting & Claims beyond the measured corpora and configurations, bounded in Section~\ref{sec:threats}\\
\bottomrule
\end{tabular}
\end{table*}
