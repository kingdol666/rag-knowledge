# 3 System overview / 4 Acquisition / 5 Organization / 6 Retrieval / 7 Implementation

%% ===== source: n3_overview.tex =====
\section{System overview and design principles}
\label{sec:system}

QDCVR (v2.3) is a self-hosted knowledge-base management system for converting
heterogeneous documents into searchable, governable collections. A Python
parsing service, a TypeScript web application and an MCP tool server share
local storage and retrieval engines \cite{mcp}. The design follows from the
dependency chain of Section~\ref{sec:intro}. Content decides where a document
is filed and whether a candidate is admitted; state is kept auditable through
three mutually checkable sources, namely the document files, the tree registry
and the per-library metadata; and completion is established by a retrieval
probe rather than by a success message. Each decision sits at the layer that
can enforce it, and the evaluation measures it at that layer.

\subsection{Design principles: three contracts and enforcement layers}
\label{sec:req}
\label{sec:principles}

The three contracts are hypotheses about where content should govern the
workflow, implemented at different layers: some checks are mechanically
enforced by server-side tools, whereas placement and answer abstention also
depend on the calling workflow, which is where the hypotheses are weakest. We
therefore distinguish the mechanism that executes each step from the audit or
evaluation that checks its outcome, and Section~\ref{sec:eval} reports the
evidence level each check reaches.

\begin{description}
\item[Content informs placement.] \emph{Mechanism:} an ingest agent reads the
parsed content together with the library catalogue and selects a parent or
sub-library; storage APIs validate identifiers and required fields, not the
semantic correctness of that choice. \emph{Check:} descriptions and tags are
re-read against the body, and three-source consistency is checked after
lifecycle operations (Sections~\ref{sec:acquisition} and~\ref{sec:organization}).
\item[Content informs admission.] \emph{Mechanism:} when invoked, the server-side
Laya judging tool fetches or accepts document text, scores its segments, and
returns survivors with provenance; lane workflows are instructed to treat rank
as advisory. \emph{Check:} failed fetches or scores are not admitted, and the
ablation in Section~\ref{sec:e8} tests a bounded frozen-pool contrast
(Sections~\ref{sec:lanes} and~\ref{sec:gate}).
\item[Absence is reported.] \emph{Mechanism:} the answer workflow instructs the
agent to report not-found when completed retrieval provides no supporting
evidence and to state its searched scope. This is not a server-side semantic
classifier. \emph{Check:} out-of-corpus probes and unanswerable questions were
observed as abstentions in the reported trials (Section~\ref{sec:e5}).
\end{description}

Four deployment requirements constrain the contracts: expose parsing failures;
keep document files and library records consistent; require content evidence
before a retrieved item is used to support an answer; and remain operable on
one workstation. Server-side checks cover parse, metadata and index
post-conditions, the invoked evidence gate, and endpoint tool policies. They do
not mechanically establish semantic placement accuracy or answer faithfulness.
Read as hypotheses, C1 is supported by these mechanical checks together with
one membership measurement that does not use the ingest naming convention
(Section~\ref{sec:e1}); C2's filtering role was not exercised on the
industrial corpus, and its ordering role failed there
(Sections~\ref{sec:e4}--\ref{sec:e8}); C3 is answer-layer behavior observed in
trials, not a server-side classifier (Section~\ref{sec:e5}).

\subsection{Architecture and subsystems}
\label{sec:architecture}

Fig.~\ref{fig:arch} shows the acquisition and query paths. Ingestion parses and
quality-checks documents; an agent uses the parsed content and library
catalogue to select a parent or sub-library; save and index operations then
update records and search indices. At query time, the chat endpoint supplies a
lane-specific tool policy, and the agent retrieves candidates and invokes the
gate before the answer layer returns cited evidence or not-found. The MCP
server exposes 95 registered tools. The three contracts of
Section~\ref{sec:principles} sit at different points along this path:
placement during ingestion, admission at the gate, the abstention report in
the answer layer.

\begin{figure*}[t]
\centering
\includegraphics[width=\textwidth]{fig1_architecture}
\caption{QDCVR architecture and three design commitments. During ingestion, an
agent uses document content and the catalogue to choose a library; server-side
storage and consistency checks verify structural state (C1). At query time,
the endpoint applies a tool policy and the agent may invoke the server-side
Laya evidence tool, which returns scored survivors with provenance (C2). The
answer workflow is instructed to report not-found after a completed search
finds no support (C3). These commitments span distinct enforcement layers;
the evaluation measures selected mechanisms and observed outcomes.}
\label{fig:arch}
\end{figure*}

The management path covers acquisition (Section~\ref{sec:acquisition}),
content-routed organization and lifecycle checks
(Section~\ref{sec:organization}), and the tool and runtime layer
(Section~\ref{sec:implementation}). The chat
endpoint defines pinned-search and all-library librarian policies. Hybrid is
a composed retrieval configuration, not a third built-in server policy; it
combines vector and catalog calls under an explicit directive. The document
graph supports navigation, not evidence, and the experience store uses the
same catalog and gate but was not evaluated at scale.

Five function groups cover acquisition, organization, lifecycle, query and
operational experience. Each is paired with a server-side check rather than an
operator convention, and Table~\ref{tab:functions} maps every group to its
checks and to the evaluation that exercises it.

\begin{table*}[t]
\centering
\small
\setlength{\tabcolsep}{4pt}
\caption{Management functions, the server-side check attached to each, and the
evaluation that exercises it. The check column states what the platform
verifies mechanically; semantic choices such as where a document belongs
remain workflow decisions and are measured, not enforced.}
\label{tab:functions}
\begin{tabular}{@{}>{\raggedright\arraybackslash}p{0.13\textwidth}>{\raggedright\arraybackslash}p{0.37\textwidth}>{\raggedright\arraybackslash}p{0.30\textwidth}>{\raggedright\arraybackslash}p{0.11\textwidth}@{}}
\toprule
Group & Operations & Server-side check & Evidence\\
\midrule
Acquisition & submit, parse (MinerU), quality gate, near-duplicate flag, structural split, store, index & task state, OCR/binary/heading checks, content fingerprint, split invariance, post-index probe & E1\\
Organization & create library or sub-library, content-informed placement, descriptions and tags, duplicate review & identifier and required-field validation, description/tag re-read against the body, three-source consistency & E1--E2\\
Lifecycle & move, rename, delete, force re-index, graph build & post-operation audit of registry, library metadata and vector chunks & E2\\
Query & lane selection, vector, keyword, catalog and two-stage search, gate invocation & tool allow/deny lists, timeouts and turn limits, provenance on returned survivors & E4--E8\\
Experience & extract, approve, tier, search & approval state and credibility tier before display & E3\\
\bottomrule
\end{tabular}
\end{table*}

\subsection{Data model and object lifecycle}
\label{sec:datamodel}
\label{sec:lifecycle}

Documents are stored as Markdown with extracted images. Three sources describe
library state: document files, the \texttt{.tree-fs.json} registry and each
library's \texttt{.knowledge-base.yml}. Ingestion proceeds through raw,
parsed, stored and indexed states, and is complete only after a content-derived
probe retrieves the document. Indexing is explicit and asynchronous; task
identifiers support polling, while post-operation audits detect stale indices
or disagreement among the three sources.

%% ===== source: n4_acquisition.tex =====
\section{Knowledge acquisition: parsing, ingestion and index verification}
\label{sec:acquisition}

Acquisition determines what later retrieval can support, and it is where
content comes to govern placement. QDCVR submits PDFs,
Office files and scans to MinerU through an asynchronous parsing service
\citep{mineru}; parse tasks return identifiers that callers poll to completion,
and OCR, layout and formula-extraction failures remain visible rather than
being stored as empty documents.

An ingest follows a fixed sequence of observable stages: submit, parse, quality
verdict, duplicate decision, split, storage, indexing and a retrieval probe.
Each stage leaves a record that the next stage reads and the audit can revisit:
a parse task identifier, a quality report, a content fingerprint, a split
manifest, a storage record and a probe result. A document counts as ingested
only when a content-derived query retrieves it; an HTTP success from the save
call is not treated as success. The same path accepts scanned pages, Office
files and plain text, and a failure at one stage never silently promotes the
document to the next.

\subsection{Quality gates and ingest lifecycle}

Before storage, duplicate detection checks exact content fingerprints and
flags near-duplicates for review at a 0.90 similarity threshold. After parsing,
a quality gate checks extracted text for OCR noise, binary residue, bodyless
headings, whitespace collapse and language mismatch. The parsed result is saved
with task provenance but is not indexed by that save; direct-text documents use
the create path, which triggers background indexing. The ingestion agent
selects a library whose scope matches the parsed content's subject, not its
filename.

Documents exceeding the 30,000-character reading-context ceiling are split
at structural boundaries. The splitter targets 0.85 utilization and avoids
cuts that would divide atomic units such as equations or tables. Descriptions
and tags are derived from the body and checked against it; mismatches require
metadata correction, not document rewriting. Indexing populates vector, lexical
and graph representations separately; post-index verification checks for a
non-empty vector collection, expected chunk identifiers and graph/document
state. Ingestion also runs content-derived probes before marking an ingest
complete; API success alone is not proof of retrievability.

\subsection{Acquisition evidence and accounting limits}

The 100-paper campaign produced 322 stored parts in five libraries.
Its reconciliation is incomplete: the state file records 91 submitted names,
79 papers were retrievable at evaluation and 21 never became retrievable, and
the surviving artifacts do not enumerate attempts and failures per paper, so
the missing 21 cannot be attributed to parsing alone. Formula-dense scans and
a recovered batch-process crash were observed; neither establishes the cause
for every missing paper.

A separate cross-lingual test processed 400 Wikipedia pages per language:
ingestion success 1.0 in both rounds, membership accuracy 0.875 for English
against 1.0 for Chinese and Japanese, with the per-language storage and
self-retrieval results in Section~\ref{sec:e1}. These measurements
characterize ingestion and storage, not answer quality.

%% ===== source: n5_organization.tex =====
\section{Knowledge organization and lifecycle management}
\label{sec:organization}

Organization determines which candidates retrieval can see and whether the
stored state remains trustworthy. QDCVR places documents by content rather
than filename; split parts inherit the source assignment, and the catalog
exposes library and document descriptions before full bodies are read.

\subsection{Metadata, tags and duplicate review}
\label{sec:org-placement}
\label{sec:org-registries}
\label{sec:org-tags}
\label{sec:org-dedup}

Integrity checks compare the document files, the \texttt{.tree-fs.json} tree
and each library's \texttt{.knowledge-base.yml} for document existence, path
and index metadata. Tags derive from content and are checked against it.
Duplicate detection reports candidate pairs for review; deletion is not
automatic because adjacent parts may be similar while containing distinct
source sections.

The layer's operations are library and sub-library creation, placement,
description and tag edits, move, rename, delete, duplicate review and forced
re-index. Each writes the document files and both registries, so the audit can
compare the three sources afterwards. The catalog lists libraries, their
descriptions, sub-library containers and document descriptions, which lets a
reader or an agent decide where to look before opening a body. Placement is
the one operation whose semantic choice is not mechanical: the ingest agent
selects the library from the parsed content, and the platform checks the
consequences rather than the choice.

Sub-libraries are first-class tree nodes with their own descriptions and
indices. Index writes resolve the document's owning library; searching a parent
library traverses its descendants' collections. This supports hierarchical
organization without implying that child vectors are stored in the parent's
collection.

\subsection{Lifecycle operations, graph and operational knowledge}
\label{sec:org-lifecycle}
\label{sec:org-graph}
\label{sec:org-experience}

Re-indexing is explicit: a rename can leave stale vector chunks until a forced
re-index, so operation completion requires checking the resulting index, not
only the metadata record. The document graph supports navigation and candidate
expansion, not evidence. Operational lessons are stored as retrievable
documents with credibility tiers, but the available measurements are case
examples rather than a scale evaluation of distillation, approval or
credibility decay.

\subsection{Organization contract}
\label{sec:org-integrity}
\label{sec:org-summary}

The evaluation checks three-source consistency, content-derived descriptions,
regression probes and lifecycle outcomes (Section~\ref{sec:e2}). The contract
makes stale or inconsistent state detectable; it does not prevent every
failure by construction. Merge and split remain outside the controlled test
scope, so performance claims must be read within the corpus sizes reported in
the Evaluation section.

%% ===== source: n6_retrieval.tex =====
\section{Content-verified retrieval}
\label{sec:retrieval}
\label{sec:lanes}

Retrieval is the query module of the management system: it reads the
libraries, catalog and indices that acquisition and organization maintain, and
it returns either evidence for an answer or an explicit absence report.
Search, Librarian and Hybrid lanes use different retrieval affordances but
share a server-side content-verification tool when the calling workflow invokes
it. The tool fetches referenced document text, segments it and applies a local,
query-conditioned Laya verdict on a 0--1 scale---the model card's typed
binary-output field (\texttt{noul}), the calibrated probability that a
segment answers the posed evidence question; segments meeting the configured
threshold (0.5 by default) are returned as survivors with provenance. A scored segment below the
threshold is not admitted, but tool or fetch failures are reported separately
and a partially completed call may still return successfully scored survivors.

A lane invocation runs the same five steps and differs in the tools it calls.
\begin{enumerate}
\item \emph{Rewrite.} The agent decomposes the question into a subject, an
attribute and any constraint (Lane A), or classifies it as literal or
enumerative for the scanner and semantic for the judge (Lane B).
\item \emph{Gather.} The lane collects candidates: dense top-30 above cosine
0.35 inside a pinned library (A); catalog pages followed by the scanner or the
judge (B); one server call that merges vector top-30 with catalog results (C).
\item \emph{Merge and cap.} Candidates are deduplicated by library and
document, ordered with documents returned by both sources first, and capped at
twelve candidates.
\item \emph{Judge.} The gate fetches each candidate's text, splits it into
segments and scores every segment against the posed evidence question. Scored
survivors carry provenance; a fetch or tool failure is reported separately from
a low score.
\item \emph{Cut and read.} The answer step reads the first five survivors in
full. The shipped configuration orders them by verdict score; the filter replay
of Section~\ref{sec:e4} keeps the fusion order instead, and the relative margin
is evaluated there as a diagnostic rather than as a configured control.
\end{enumerate}
Exhausting a lane's call budget is intended to produce a scope and blind-spot
report. The endpoint enforces timeouts and turn limits; the per-lane budgets
are workflow instructions, not server quotas.

\subsection{Gate contract and retrieval lanes}
\label{sec:trace}
\label{sec:gate}
\label{sec:gate-primitive}
\label{sec:twostage}

The chat endpoint supplies two built-in policies. Lane A uses a wide dense search
(top 30, cosine threshold 0.35) within a pinned library and may escalate once
to the catalog ladder when no verified evidence survives. Lane B follows catalog descriptions, then
uses a deterministic scanner for literal or enumeration questions and the judge
for semantic questions. Endpoint-level timeouts and turn limits bound execution;
the lane call budgets and six-reference batching below are workflow instructions,
not independent server-enforced quotas. Exhaustion is intended to produce a
scope and blind-spot report. Lane C is a composed configuration used in
evaluation, not a third built-in server policy: it appends a hybrid directive
to the chat prompt that can call vector and catalog tools, merge up to twelve
candidates, judge them in batches of six, and return up to five survivors with
bounded evidence. Table~\ref{tab:lanes} and Fig.~\ref{fig:lanes} summarize the
policies and answer workflow.

The gate is the local Laya evidence classifier \cite{laya}, exposed as
\path{kb_laya_judge}. In reference mode, the server fetches each document,
judges its segments and returns provenance with a bounded evidence pack. The
verdict controls admission, not truth; the verifier remains subject to
calibration and transport limitations.

\begin{table*}[t]
\centering
\small
\setlength{\tabcolsep}{5pt}
\caption{Retrieval lanes as operating policies over a shared candidate and verification tool layer. Budgets describe the configured interface; latency and effectiveness are evaluated separately in Section~\ref{sec:eval}.}
\label{tab:lanes}
\begin{tabular}{@{}llll@{}}
\toprule
Lane & Retrieval affordance & Budget type & Intended terminal report \\
\midrule
Search & Pinned-library dense search & Endpoint turn limit & Answer or report not-found \\
Librarian & Catalog navigation and query-shaped scan/judging & Workflow call budget & Scope and blind spots \\
Hybrid & Agent-composed vector and catalog calls & Evaluation-specific candidate cap & Survivors for answer workflow \\
\bottomrule
\end{tabular}
\end{table*}

The two-stage tool builds a candidate pool with lexical search and optional
graph expansion, then applies dense ranking. It does not call the
content gate; a ranked chunk is not admissible evidence until verified, and a
similarity threshold is not an abstention mechanism. The 13 October catalog
incident showed that oversized tool returns can conceal documents before
reasoning begins. The tested repair adds a server-side character budget,
grouped views and pagination; its behavior is reported in the Evaluation
section.

\begin{figure*}[t]
\centering
\includegraphics[width=\textwidth]{fig2_lanes}
\caption{The three retrieval workflows can invoke the same content-verification
tool by different routes: a pinned wide dense search that may escalate once
to the catalog ladder when no survivors remain, a catalog ladder that selects a literal scanner or the judge,
and an agent-composed vector-and-catalog configuration capped at twelve
candidates in this evaluation. When invoked, the gate reads fetched text and
returns scored survivors with provenance; zero survivors or an exhausted
workflow budget is intended to elicit an explicit not-found report. Endpoint
tool and turn controls are server-side; the lane-level call sequence and
budgets are workflow instructions.}
\label{fig:lanes}
\end{figure*}

\subsection{Honest abstention}
A candidate list may contain high-similarity but unsupported documents. The
answer workflow instructs the agent to report not-found when its completed
evidence review finds no support, including the searched scope and known blind
spots, rather than falling back to parametric knowledge. This behavior was
observed in the reported trials; it is not a server-side semantic-classifier
guarantee. Timeouts, unavailable tools and incomplete searches are execution
failures, not evidence of semantic absence (Section~\ref{sec:eval}).

%% ===== source: n7_implementation.tex =====
\section{Agent interface and implementation}
\label{sec:implementation}
\label{sec:impl}

\subsection{MCP tools and lane policy}
\label{sec:impl-tools}

The platform exposes 95 MCP tools across twelve functional groups, including
parsing, search, content verification, indexing, tags, the document graph and
operational experience, plus persona distillation, which shares the same storage,
catalog and gate but lies outside the scope of this evaluation. Retrieval lanes
receive read-oriented tool sets; administrative writes remain separate, and
long-running parse, re-index and graph operations return pollable task
identifiers.

The chat endpoint adapts multiple agent harnesses to the lane interface. The
server selects a harness and permission mode, enforces configured tool
allow/deny lists, applies endpoint timeouts and turn limits, and may register an
asynchronous task. Lane-specific retrieval sequences and call budgets are
workflow instructions; the endpoint does not enforce a separate per-lane call
quota.

\subsection{Runtime and deployment}
\label{sec:impl-runtime}

The backend uses Python 3.12 and FastAPI. ChromaDB stores cosine-space HNSW
collections with normalized BGE-M3 embeddings (1024 dimensions)
\cite{chroma,hnsw,bge-m3}; Neo4j stores the document graph \cite{neo4j};
BM25 supports lexical search \cite{bm25}; MinerU provides parsing and OCR
\cite{mineru}. The Laya verifier runs locally as a serialized worker.

The evaluation environment is one self-hosted Windows workstation with an
RTX 5060 (8 GB) used for embeddings and judging. Local execution reduces
external service dependencies but does not establish privacy, access-control or
multi-host deployment guarantees. The implementation and scripts are available
at \url{https://github.com/kingdol666/rag-knowledge}; experimental corpora
remain subject to their data-use constraints.
