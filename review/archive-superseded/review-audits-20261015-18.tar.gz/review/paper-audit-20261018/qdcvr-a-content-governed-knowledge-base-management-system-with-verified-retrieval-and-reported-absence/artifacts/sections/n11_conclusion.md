\section{Conclusion}
\label{sec:conclusion}

QDCVR is a knowledge-base management system, and the evaluation is organized
around that claim. The management layer parses and admits documents through
gates that fail visibly, places them by content, keeps document files, the
tree registry and library metadata consistent, and audits rename, move, delete
and re-index operations. In the demonstration instance these checks hold in
place: 322 stored parts pass storage and content audits, the 50-paper campaign
parses 50/50, and sub-library creation and moves behave as specified. The same
layer also records its failures. Twenty-one of 100 submissions never became
retrievable and the surviving artifacts cannot attribute them, and one
oversized-catalog response hid entries from the agent and produced a false
refusal until a character budget and pagination repaired the tested paths.

The answer-level evaluation gives the system's end-to-end reading. Across ten
questions and three retrieval interfaces in two 30-cell grids (60 answer
cells), every answer names its gold document and alias-aware keyword coverage
is 9-10/10. Strict and
marker counts move with the substrate: the original marker ordering, 9/7/2,
becomes 9/9/9 on a common one, so these counts do not rank the interfaces.
The measures capture identifier presence and lexical or marker coverage, not
semantic support. An eighteen-arm honesty battery observed no fabricated
citations, and verified-absent questions returned explicit not-found reports;
that behavior is instructed at the answer layer, not enforced by a classifier.

The retrieval diagnostic bounds what the verifier can be used for. On
identical logged pools, ordering candidates by the verdict lowers Hit@5 from
0.94 to 0.44, while retaining fusion order among recorded survivors restores
0.94; all 191 recorded scores exceed the 0.5 threshold, and one additional
fusion candidate has no recorded score. The comparison therefore diagnoses a
harmful ordering role, not a benefit from threshold filtering. A verifier
score that is acceptable as an admission filter should not be assumed usable
as a ranker.

The contribution is a knowledge-base management workflow, a per-question
account of the answers it produces, and a same-pool diagnostic of verifier
placement, not a claim of universal retrieval or answer-quality superiority.
The results remain bounded by one workstation, one verifier checkpoint and
developer-authored questions. Next steps include independently curated
questions, repeated agent trials, claim-level evidence-support evaluation, a
confuser-density-controlled verifier evaluation, explicit execution-failure
states for incomplete searches, transport stress tests and operator studies
of not-found reports.

%% The back matter — CRediT, competing interest, funding, ethics statement,
%% data availability, acknowledgements, appendix and the mandated generative-AI
%% declaration — lives in n_back.tex, which main_20p.tex inputs immediately
%% after this file. Keeping it there gives every declaration one source of
%% truth and puts the AI declaration last before the reference list, as the
%% KBS guide requires.
