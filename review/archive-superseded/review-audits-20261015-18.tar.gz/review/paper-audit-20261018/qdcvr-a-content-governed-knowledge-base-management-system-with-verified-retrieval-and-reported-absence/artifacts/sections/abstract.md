abstract
Document collections need more than a retriever: documents must be
parsed and admitted, organized so that they can be found, and used to answer
questions whose cited evidence can be traced. We present QDCVR, a self-hosted
knowledge-base management system that treats content as the shared object
across acquisition, organization and question answering. Its management layer
parses and gates documents, splits long files, places
documents by content rather than filename, and keeps files, registry and
metadata consistent through rename, move, delete and re-index. Retrieval is one
module: three lanes share an invoked server-side content verifier, and an
answer workflow is instructed to report absence.
We evaluate the system on three corpora, one an industrial demonstration
instance. Our evaluation method combines functional audits, per-question
answer checks, abstention probes and same-pool replays.
On ten arXiv
questions crossed with three retrieval interfaces in two 30-cell grids, every
answer names its gold document and alias-aware coverage is 9-10/10; the
controlled common-substrate replication shows that strict keyword and marker
counts are substrate-bound, not interface-specific. Acquisition left 21 of 100 submissions unretrievable without a
complete failure inventory, and a reproduced catalog-transport failure was
repaired. In a same-pool replay on an industrial corpus, ordering
by the verifier score reduces Hit@5 from 0.94 to 0.44 while fusion order
restores 0.94; the scores are not usable as a ranker, and the 0.5 cut filtered
nothing. Wall-clock and cost disfavor the
platform arm. The findings indicate a bounded deployment account,
not universal retrieval superiority.
abstract