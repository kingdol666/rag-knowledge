# 9 Discussion / 10 Threats / 11 Conclusion

%% ===== source: n9_discussion.tex =====
\section{Discussion and lessons learned}
\label{sec:discussion}

The first implication concerns what the answers are worth. On the fixed
question set the workflow locates the right document in all 30 cells of both
grids, and alias-aware keyword coverage stays at 9-10/10. Citation-marker and
strict-keyword counts are not stable across substrates: the original marker
ordering, 9/7/2, becomes 9/9/9 when every arm reads the same libraries. Across
paired cells, all five strict disagreements and all nine marker disagreements
run in one direction, so the change is a substrate effect rather than run
noise. The practical lesson is therefore narrower: judge the workflow on
provenance and coverage, and report the substrate alongside any marker or
keyword comparison. Retrieval recall alone is a weak criterion here, because every
lexical baseline reaches it on the same corpus.

The second implication concerns verifier placement, and it is the paper's main
mechanical finding: separating a content verifier's filtering role from its
ordering role is what allows the failure to be located. On identical logged
pools, re-ranking by the verdict lowers Hit@5 from 0.94 under fusion-only to
0.44. A derived replay that keeps the fusion order among scored survivors
returns the fusion-only metrics, and rephrased questions separate the roles
further: the judged configuration falls to 0.5 while both fusion-order
variants hold at 0.9375. Because all 191 recorded scores exceed the 0.5
threshold and one Q14 fused candidate has no recorded score, the comparison
diagnoses the induced ordering, not a threshold-filter benefit. A second
checkpoint and its span-level variant fail the same way on the same pools. The
second corpus does not reproduce the collapse, so the strongest supported
claim is that ranking by these checkpoints should not replace fusion order
under the tested confuser density; whether confuser density itself is the
cause remains an association, because the probe moved domain, language and
corpus size together.

The third implication concerns abstention. Similarity can retrieve related
material without answering a query. In this system, the answer workflow
instructs the agent to report the searched scope and say not-found when its
completed evidence review finds no support; the retrieval threshold never
played that role, since the graded probes retained 10 to 12 of their 12
candidates at every tier. The adversarial battery observed no fabricated
citations in eighteen final arms, but one partial answer fell outside the
binary grading scheme and each arm has a single final observation. Timeouts,
unavailable tools and incomplete searches must be reported as execution
failures, not conflated with semantic absence.

The fourth implication concerns transport. A reproduced oversized-catalog
response hid entries from the agent and led to a false refusal. Server-side
budgets, grouped views and pagination repaired the selected tested paths on
rerun. This supports the narrower point that transport limits can affect
retrieval outcomes, and that the enforcement layer honesty requires has
limits of its own.

The five research questions close at different evidence levels. RQ1 is
answered as an operational observation of the management layer, bounded by 21
papers that never became retrievable and by the use of a filename-independent
membership measurement rather than a per-document adjudication of placement.
RQ2 is answered for one corpus, one model and one question family: every
answer names its gold document, alias-aware coverage is 9-10/10, and the
citation-syntax difference between interfaces does not survive a
common-substrate replication; the checks are lexical and do not establish
semantic support. RQ3 reports tool-layer recall separately from end-to-end
source-marker checks; it does not claim similar recall in every interface or
isolate the gate's causal effect. RQ4 is answered within one corpus, one
checkpoint and one question family: on identical logged pools the tested
answer is to keep fusion order, and the comparison does not validate threshold
discrimination. RQ5 documents observed abstentions, turn-dominated latency and
a transport failure/recovery, with no broad reliability or user-utility
estimate.

More broadly, parsers, registries, indices and answer workflows benefit from
post-conditions that can be checked independently of success messages.
Catalogues and graphs support navigation but are not themselves evidence, in
keeping with provenance and auditability work in data systems
\cite{missier-prov-2013,cheney-provenance-2009}. The results remain bounded by
the tested corpora, developer-authored questions, one workstation and few
end-to-end observations. Larger independent question sets, repeated agent
trials, claim-level support assessments, a confuser-density-controlled
verifier evaluation that holds corpus, language and question set fixed while
varying near-duplicate density, operator studies of not-found reports and
crash-recovery tests are needed before stronger deployment claims.

%% ===== source: n10_threats.tex =====
\section{Threats to validity}
\label{sec:threats}

\noindent\textbf{Corpus and scale.} The results cover bounded demonstration and public
collections and a small arXiv-based corpus. Retrieval-only modes searched live
libraries, whereas lexical and dense baselines used a corpus index; these are
not identical retrieval substrates. The three answer arms of the original
grid also differ in substrate (default library scope, exported file tree,
800-character mirror), so that grid compares interface plus substrate; the
30-cell replication pins every arm to the same five libraries, and the marker
differences do not survive it. The three-source consistency
check is a 33-document sample, one tenth of the 322-document corpus, not a full
audit. Findings should not be generalized to larger or differently organized
collections without replication.

\noindent\textbf{Question construction and denominators.} Questions and gold
annotations were developer-authored. The two three-arm grids of
Section~\ref{sec:e5} are ten questions of one question family on one model,
each run once per arm: the platform arm's latency separation holds in both,
but the citation separation does not survive the common substrate, and the
grids cannot resolve differences smaller than one cell. The grounding reading
is at ceiling in both. Two answers in the original grid contain
an evidence-insufficiency qualifier; the grader's
\texttt{insufficient\_evidence} flag is a substring test that also fires when
the phrase appears inside a fully answering text, so we read those two flags
as measurement artifacts, not as hedges. Agent-track retrieval
hits are inferred from trace and answer, while citation checks provide the
more direct functional measure.

\noindent\textbf{Execution and grading.} The refusal battery has one final
observation per arm after rerunning two MCP-mount interruptions. Fabrication
checks were manually audited, and the binary gate required reclassification
of one body-level partial answer. Retrieval-only elapsed time is not directly
comparable to end-to-end agent latency. The E5 grader is deterministic but
lexical: its gold-ID, keyword and citation-marker checks do not establish
semantic claim support; gold-ID presence is checked in the answer or the
recorded trace, and keyword coverage passes at $\lceil 3n/5\rceil$ of the
annotated terms, so a missing term can still pass. Aliases are reported as a
separate regrade. The 30-cell grid and its controlled replication are each one run
per arm on one model, recorded as claude-opus-4-8[1m]; the paired analysis in
Section~\ref{sec:e5} bounds the stable reads. Three cells of the original grid
departed from the stated contract (Section~\ref{sec:e5}), and one platform
answer in the replication contains a short Chinese phrase. The archived pools store the survivors of each judged pool rather
than the dropped list, so the filter role cannot be re-derived beyond the
recorded scores. The BQ06 gold key was corrected to the source paper's
thermodynamic reading after inspection, and declared aliases cover known
word-form variants and Chinese renderings; the pre-correction question set and
its grade (strict 10/9/9) are retained alongside the corrected regrade (strict
9/9/9), and both sets are frozen for this submission in
\path{paper-kbs/tex/journal_20p/.frozen-experiment-sha256.txt}, so the
two-grade disclosure cannot drift after review. The
MCP lifecycle script passed its 16 direct assertions and the stdio protocol
test passed, but the lifecycle script is not pytest-collection-safe because it
calls \texttt{sys.exit} at module import.

{% keep the closing paragraph off a one-line orphan at a column foot;
% the blank line must sit inside this group so \par sees the penalty
\clubpenalty=10000
\noindent\textbf{Scope.} Tests ran on a single local workstation and one
verifier checkpoint. They do not establish generalization across model hosts,
large-scale corpora, independently authored questions, operator adoption,
adversarial access or crash-mid-write recovery. The pagination repair was
verified on selected catalog and query cases; broader transport boundary
testing remains necessary.

}


%% ===== source: n11_conclusion.tex =====
\section{Conclusion}
\label{sec:conclusion}

QDCVR is a knowledge-base management system, and the evaluation is organized
around that claim. The management layer parses and admits documents through
gates that fail visibly, places them by content, keeps document files, the
tree registry and library metadata consistent, and audits rename, move, delete
and re-index operations. In the demonstration instance these checks hold in
place: 322 stored parts pass storage and content audits, the 50-paper campaign
parses 50/50, and sub-library creation and moves behave as specified. The same
layer also records its failures. Twenty-one of 100 submissions never became
retrievable and the surviving artifacts cannot attribute them, and one
oversized-catalog response hid entries from the agent and produced a false
refusal until a character budget and pagination repaired the tested paths.

The answer-level evaluation gives the system's end-to-end reading. Across ten
questions and three retrieval interfaces in two 30-cell grids (60 answer
cells), every answer names its gold document and alias-aware keyword coverage
is 9-10/10. Strict and
marker counts move with the substrate: the original marker ordering, 9/7/2,
becomes 9/9/9 on a common one, so these counts do not rank the interfaces.
The measures capture identifier presence and lexical or marker coverage, not
semantic support. An eighteen-arm honesty battery observed no fabricated
citations, and verified-absent questions returned explicit not-found reports;
that behavior is instructed at the answer layer, not enforced by a classifier.

The retrieval diagnostic bounds what the verifier can be used for. On
identical logged pools, ordering candidates by the verdict lowers Hit@5 from
0.94 to 0.44, while retaining fusion order among recorded survivors restores
0.94; all 191 recorded scores exceed the 0.5 threshold, and one additional
fusion candidate has no recorded score. The comparison therefore diagnoses a
harmful ordering role, not a benefit from threshold filtering. A verifier
score that is acceptable as an admission filter should not be assumed usable
as a ranker.

The contribution is a knowledge-base management workflow, a per-question
account of the answers it produces, and a same-pool diagnostic of verifier
placement, not a claim of universal retrieval or answer-quality superiority.
The results remain bounded by one workstation, one verifier checkpoint and
developer-authored questions. Next steps include independently curated
questions, repeated agent trials, claim-level evidence-support evaluation, a
confuser-density-controlled verifier evaluation, explicit execution-failure
states for incomplete searches, transport stress tests and operator studies
of not-found reports.

%% The back matter — CRediT, competing interest, funding, ethics statement,
%% data availability, acknowledgements, appendix and the mandated generative-AI
%% declaration — lives in n_back.tex, which main_20p.tex inputs immediately
%% after this file. Keeping it there gives every declaration one source of
%% truth and puts the AI declaration last before the reference list, as the
%% KBS guide requires.
