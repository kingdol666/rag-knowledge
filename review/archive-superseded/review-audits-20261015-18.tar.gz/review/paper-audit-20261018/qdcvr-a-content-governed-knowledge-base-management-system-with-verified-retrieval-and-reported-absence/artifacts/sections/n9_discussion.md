\section{Discussion and lessons learned}
\label{sec:discussion}

The first implication concerns what the answers are worth. On the fixed
question set the workflow locates the right document in all 30 cells of both
grids, and alias-aware keyword coverage stays at 9-10/10. Citation-marker and
strict-keyword counts are not stable across substrates: the original marker
ordering, 9/7/2, becomes 9/9/9 when every arm reads the same libraries. Across
paired cells, all five strict disagreements and all nine marker disagreements
run in one direction, so the change is a substrate effect rather than run
noise. The practical lesson is therefore narrower: judge the workflow on
provenance and coverage, and report the substrate alongside any marker or
keyword comparison. Retrieval recall alone is a weak criterion here, because every
lexical baseline reaches it on the same corpus.

The second implication concerns verifier placement, and it is the paper's main
mechanical finding: separating a content verifier's filtering role from its
ordering role is what allows the failure to be located. On identical logged
pools, re-ranking by the verdict lowers Hit@5 from 0.94 under fusion-only to
0.44. A derived replay that keeps the fusion order among scored survivors
returns the fusion-only metrics, and rephrased questions separate the roles
further: the judged configuration falls to 0.5 while both fusion-order
variants hold at 0.9375. Because all 191 recorded scores exceed the 0.5
threshold and one Q14 fused candidate has no recorded score, the comparison
diagnoses the induced ordering, not a threshold-filter benefit. A second
checkpoint and its span-level variant fail the same way on the same pools. The
second corpus does not reproduce the collapse, so the strongest supported
claim is that ranking by these checkpoints should not replace fusion order
under the tested confuser density; whether confuser density itself is the
cause remains an association, because the probe moved domain, language and
corpus size together.

The third implication concerns abstention. Similarity can retrieve related
material without answering a query. In this system, the answer workflow
instructs the agent to report the searched scope and say not-found when its
completed evidence review finds no support; the retrieval threshold never
played that role, since the graded probes retained 10 to 12 of their 12
candidates at every tier. The adversarial battery observed no fabricated
citations in eighteen final arms, but one partial answer fell outside the
binary grading scheme and each arm has a single final observation. Timeouts,
unavailable tools and incomplete searches must be reported as execution
failures, not conflated with semantic absence.

The fourth implication concerns transport. A reproduced oversized-catalog
response hid entries from the agent and led to a false refusal. Server-side
budgets, grouped views and pagination repaired the selected tested paths on
rerun. This supports the narrower point that transport limits can affect
retrieval outcomes, and that the enforcement layer honesty requires has
limits of its own.

The five research questions close at different evidence levels. RQ1 is
answered as an operational observation of the management layer, bounded by 21
papers that never became retrievable and by the use of a filename-independent
membership measurement rather than a per-document adjudication of placement.
RQ2 is answered for one corpus, one model and one question family: every
answer names its gold document, alias-aware coverage is 9-10/10, and the
citation-syntax difference between interfaces does not survive a
common-substrate replication; the checks are lexical and do not establish
semantic support. RQ3 reports tool-layer recall separately from end-to-end
source-marker checks; it does not claim similar recall in every interface or
isolate the gate's causal effect. RQ4 is answered within one corpus, one
checkpoint and one question family: on identical logged pools the tested
answer is to keep fusion order, and the comparison does not validate threshold
discrimination. RQ5 documents observed abstentions, turn-dominated latency and
a transport failure/recovery, with no broad reliability or user-utility
estimate.

More broadly, parsers, registries, indices and answer workflows benefit from
post-conditions that can be checked independently of success messages.
Catalogues and graphs support navigation but are not themselves evidence, in
keeping with provenance and auditability work in data systems
\cite{missier-prov-2013,cheney-provenance-2009}. The results remain bounded by
the tested corpora, developer-authored questions, one workstation and few
end-to-end observations. Larger independent question sets, repeated agent
trials, claim-level support assessments, a confuser-density-controlled
verifier evaluation that holds corpus, language and question set fixed while
varying near-duplicate density, operator studies of not-found reports and
crash-recovery tests are needed before stronger deployment claims.
