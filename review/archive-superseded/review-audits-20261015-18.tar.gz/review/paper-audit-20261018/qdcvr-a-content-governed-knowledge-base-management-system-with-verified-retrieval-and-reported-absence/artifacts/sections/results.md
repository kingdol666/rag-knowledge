# 8 Evaluation (E1-E8)

%% ===== source: n8a_eval.tex =====
\section{Evaluation}
\label{sec:eval}

We evaluate the system on three corpora differing in origin, language
and scale, and we separate two questions: whether the management layer keeps
its collections in a usable state, and what the answers built on those
collections are worth. Sections~\ref{sec:e1}--\ref{sec:e3} cover the
management layer: acquisition and parsing, organization and three-source
consistency, and the operational-experience store. Sections
\ref{sec:e4}--\ref{sec:e8} cover the query path: retrieval quality
(Section~\ref{sec:e4}), answer quality per question and abstention
(Section~\ref{sec:e5}, the paper's end-to-end evidence), a deployment-layer
replication through the public API (Section~\ref{sec:sysarms}), verifier
failure (Section~\ref{sec:e6}), non-functional behavior (Section~\ref{sec:e7})
and the gate and search-scope ablations (Section~\ref{sec:e8}). Numbers are
reported against the corpus that produced them, never merged; the campaign
inventory and per-question tool-layer results are supplementary material.

\subsection{Experimental setup}
\label{sec:eval-setup}

\textbf{Corpora.} (i)~\emph{Industrial demonstration corpus}: five libraries
hold 42 documents prepared as a demonstration instance, not customer data; one
library contains twenty near-duplicate
equipment-telemetry reports sharing prefixes, vocabulary and structure---a
deliberate stressor for near-duplicate detection and confuser
density~\cite{manku-near-dup-2007}; sixteen gold questions and four
out-of-corpus probes ran against it. (ii)~\emph{arXiv corpus}: 100 submitted
papers spanning about 25 domains, 79 retrievable at evaluation time and routed
by content into five domain libraries holding 322 stored parts; ten gold
questions (BQ01--BQ10) target papers referenced by those papers, keyed by arXiv
identifier, and the running instance held 19 libraries. (iii)~\emph{Cross-lingual
ingestion corpus}: 400 Wikipedia pages per language (English, Chinese,
Japanese), 40 extractive cloze queries each with verbatim in-page answers;
ingestion only, no retrieval-quality numbers reported.

\textbf{Questions and gold annotations.} The sixteen industrial questions were
authored, not sampled from logs; each identifies one or two gold documents by
a unique filename fragment and one to three fact markers. Q16 includes a token
also present in its gold filename, so a filename-ranking retriever could match
it without reading content; we retain this limitation and report a sensitivity
check in Section~\ref{sec:e4}. The arXiv answer grader
checks gold-ID presence in the answer or trace plus a word-boundary keyword
rule that counts a cell as covered when it matches at least $\lceil 3n/5\rceil$
of the $n$ annotated terms; it does not assess semantic support. Citation
markers are counted separately by a deterministic pattern and do not assess
source resolution or claim-to-source entailment.

\textbf{Metric families.} Retrieval uses Hit@5, Recall@5 and MRR@5, following
passage-ranking conventions~\cite{craswell-msmarco-2021}; Hit@5 and Recall@5
are document-level over the top five returned documents, and MRR@5 is $1/r$
for the first gold at rank $r\le 5$ and zero otherwise.
nDCG@5~\cite{jarvelin-cumulated-gain-2002} was computed only inside one
exploratory arm we do not report. The end-to-end "gold-hit" measure checks
whether the answer or recorded retrieval trace contains the gold identifier;
keyword coverage is a deterministic lexical proxy. Citation counts record
whether the answer contains a part, section or table marker under the stated
pattern. These checks support traceability and marker-presence claims, not
semantic faithfulness or claim-to-source support, for which model-based
measures such as RAGAS~\cite{es-ragas-2024} or ARES~\cite{saad-falcon-ares-2024}
are designed. The third metric family covers wall-clock time, agent turns,
tool calls, cost and whether refusals were appropriate.

\textbf{Controls.} The deterministic retrieval lanes were re-run and compared
field by field, latency excluded; the 27-cell stability suite
(Section~\ref{sec:e7}) and the eighteen-arm honesty battery
(Section~\ref{sec:sysarms}) carry repeats, whereas the 30-cell answer grid of
Section~\ref{sec:e5} is a single run per arm on one model, recorded in the run
timeline as claude-opus-4-8[1m] with seed~0 and harness prompt v4-neutral, and
is reported as such, as is its controlled replication. The fixed retry
policy (one retry for
an empty zero-turn response or transient gateway timeout) fired twice,
succeeding both times. Before measurement we repaired two corpus-integrity
faults through the platform's own operations: one document missing from its
vector collection was re-indexed, and one library whose collection had been
lost was rebuilt, the same failure class that Section~\ref{sec:e2} measures. The tool-layer
retrieval lanes, grading rule, audits, duplicate adjudication and cross-lingual
ingestion pipeline are deterministic; agent lanes and text-derived results are
not.

\begin{table*}[t]
\centering
\footnotesize
\setlength{\tabcolsep}{4pt}
\caption{Functional checks on the management layer. Each row names the
function, the test and its scale, the observed outcome, and the subsection
that reports it. The numbers are those of the cited campaigns; none is
re-estimated. A passing check means the stated property was observed on the
stated scale, not that the function is exhaustively verified.}
\label{tab:kb-checks}
\begin{tabular}{@{}>{\raggedright\arraybackslash}p{0.115\textwidth}>{\raggedright\arraybackslash}p{0.265\textwidth}>{\raggedright\arraybackslash}p{0.39\textwidth}>{\raggedright\arraybackslash}p{0.10\textwidth}@{}}
\toprule
Function & Test and scale & Observed outcome & Where\\
\midrule
Parse and ingest & 100-paper campaign; nine checks per paper & nine checks per paper, all pass; 91 names in the state file, 79 retrievable at evaluation, 21 unattributable (twelve recorded plus nine unrecorded) & E1\\
Parse quality & 50-paper, 26-domain campaign & 50/50 parsed and verified, all probes ok; 202 tags; 41 tag flags negative without blocking ingestion & E1\\
Structural split & 50 papers at the 30{,}000-character tier & 165 documents (9 whole, 156 parts) in 2{,}672\,s; storage 50/50; descriptions and tags 165/165 & E1\\
Near-duplicate review & 322-document corpus, 0.90 threshold & 35 candidate groups (0.90--0.975), zero true duplicates, nothing deleted & E2\\
Content placement & 100 papers into five libraries; 400 pages per language & 322 stored parts; membership 0.875 (en) and 1.0 (zh, ja) & E1--E2\\
Three-source consistency & Full corpus and 33-document spot check & 322/322 content and 33/33 storage; one rename defect (18 vs 9 chunks) until force re-index & E2\\
Lifecycle operations & 16 scenarios on two disposable libraries & create, move, delete and forced re-index pass; two failures (task status, update check) & E2\\
Sub-library hierarchy & Three-level disposable fixture & create, parent-to-child move, listing, reading and judging all pass & E2\\
Tags and graph & 316-tag registry; 658-node graph & 165 documents pass the tag check in 47.6\,s; four tag edges on one document move 4{,}675 to 4{,}679 & E2\\
Experience store & One small knowledge base; one end-to-end scenario & 13 candidate drafts; one lesson retrieved first at 0.711; approval path unexercised & E3\\
\bottomrule
\end{tabular}
\end{table*}

\subsection{E1: Acquisition and parsing}
\label{sec:e1}

The 100 submitted papers were parsed and content-routed into five domain
libraries, producing 322 stored parts after the 30{,}000-character split. The
submission funnel does not reconcile on its face: 91 names appear in the ingest
state file and 79 papers were retrievable at evaluation, so twelve recorded
papers never became retrievable, and nine submitted papers never entered the
state file. The 21 unretrievable papers are the sum of those twelve and nine,
and neither attempts against failed papers nor per-paper parse status is
recorded, so the 21 cannot be attributed to parsing alone
\cite{missier-prov-2013}. Reported failure modes are formula-dense scans and
one tool-layer crash during batch parsing, restarted from a checkpoint.
Table~\ref{tab:kb-checks} lists every functional check with its scale and
outcome.

The cross-lingual benchmark ran twice over 400 pages per language and
reproduced round~1 bit-for-bit, with ingestion success 1.0; storage
completeness, self-retrieval Hit@1 and the membership figures are in
Table~S2. Its English membership accuracy of 0.875 is an organization
defect---the page stored in the wrong library roughly one time in eight---not
a parsing defect. Membership is scored against the benchmark's source category labels, not a
naming convention derived by the ingest agent, so it is the one
filename-independent placement measurement in this paper.

A second 50-paper, 26-domain campaign parsed and verified every paper, indexed
them in batch, reported all probes ok, and left 41 of 50 documents with a
negative tag flag even though verification passed, so tag-quality failures
never blocked ingestion.
One stage re-ran on inbox ordering, and more than 800 extracted images were
not uploaded. Descriptions and tags are checked against content before
storage~\cite{park-metadata-quality-2009}.


\subsection{E2: Organization, consistency, and management operations}
\label{sec:e2}


Organizational correctness is three-source consistency: disk files, the tree
index and per-library metadata must agree on document existence, location and
indexed content. Under that definition we found one real defect in a
disposable test library: after a rename the vector index kept the old name's
chunks---count 18 where 9 were expected, a duplicate search matching the
document against its own former path at 0.9738 similarity, a vector probe
returning every chunk twice at identical scores. Only an explicit force
re-index removed them, restoring the count to 9. The failure is invisible from
the metadata alone.

The reorganization campaign over the 322-document corpus passed its content
check on all 322 documents and its three-source consistency check on a
33-document sample, one tenth of the corpus; the duplicate review held no true
duplicate and deleted nothing. Sub-library splitting and hierarchy
creation ran on a disposable three-level fixture: creation with a parent
reference, a parent-to-sub-library move, and listing, reading and judging
through sub-library addresses all returned correct results. A parent catalog
lists its sub-libraries as container entries carrying their own descriptions,
the one-call view that ladder navigation reads.

Growing from 50 to 100 papers cost no retrieval quality: dense top-1 hits moved
from 48/50 to 49/50 and MRR from 0.98 to 1.00, recorded as a post hoc
held-within-5-pp band
$\pm$5\,pp. In the 16 lifecycle scenarios, create, move, delete and forced
re-index behaved as specified (Table~S5). Two failures remain: the task-status
tool reports \texttt{running} after \texttt{finished\_at} is written, and the
update check timed out after 30\,s while every other probe passed. Merge and
split were never exercised under controlled conditions, so we claim nothing
about them.

The tag registry held 316 tags; the tag-quality check passed 165
documents with zero failures in 47.6\,s, and orphan tags accumulate (test tags,
section titles), for which a dry-run detector exists. In one case test-library
tags leaked into the main registry, the failure mode vocabulary-based
organization is prone to~\cite{golder-tagging-2006}. The document graph is
navigation, never evidence: four tag edges on one document moved the edge count
from 4{,}675 to 4{,}679.

%% ===== source: n8b_eval.tex =====
%% n8b_eval.tex -- evaluation, middle part: E3 (operational knowledge and
%% automated distillation) and E4 (retrieval quality and the role of the
%% verdict). Compressed 2026-10-12. Labels owned here: sec:e3, sec:e4,
%% sec:eval-retrieval, tab:retrieval, tab:e4-modes, fig:retrieval,
%% fig:marginvariants.
\subsection{E3: Operational knowledge and automated distillation}
\label{sec:e3}

The experience store holds operational lessons as first-class retrievable
documents---addressed, indexed and searched as an ordinary document, with a
credibility tier deciding whether it may be shown at all
(Section~\ref{sec:org-experience}). Three case measurements exist: an
extraction campaign over one small knowledge base produced thirteen
candidate drafts (archived \path{experience_smoke.json} in the 2026-10-13
batch tarball; \texttt{extract\_candidates}~13, \texttt{drafts\_created}~13);
one end-to-end scenario was sedimented into one experience
(\texttt{exp-d6f4d47ae3d6}) that a later global experience search returned
first, at local similarity 0.711 (archived scenario A6 of the 2026-10-12
full-test campaign); and the draft-approval path was never exercised, because
the draft pool was empty (\texttt{count}~0) and \path{experience_draft_read}
and \path{experience_draft_approve} could not run; the heuristic extraction
path had run only in dry-run mode, returning a dump the quality gate would
reject. One scenario and thirteen candidates cannot support an effectiveness
claim; scheduled distillation, review and approval at scale, application
feedback and credibility decay went unexercised. What they show is narrower:
an operational lesson can travel the document path with its tier attached.

\subsection{E4: Retrieval quality and the role of the verdict}
\label{sec:e4}
\label{sec:eval-retrieval}

Nine configurations, defined here so the table reads on its own. Five were
measured through their own tool-layer entry points: \emph{Dense} via
\texttt{kb\_search\_vector} with BGE-M3 \cite{bge-m3}; \emph{Graph} via
\texttt{kb\_graph\_search}, a keyword match over node names, paths and tags in
the document graph; \emph{Two-stage} via
\texttt{kb\_search\_two\_stage} (Section~\ref{sec:twostage}); and the hybrid
rows via \texttt{kb\_hybrid\_search}, an earlier server-side single-call
composition of the vector, catalog and judging tools, with the gate off
(\emph{Fusion-only}) and on (\emph{QDCVR-Hybrid}). \emph{BM25} runs in process
over the fetched full texts (jieba tokenizer, $k_1=1.5$, $b=0.75$), and
\emph{RRF} fuses that ranking with the dense one at $k=60$
\cite{rrf-cormack}; neither is the platform's keyword tool, so the millisecond
latencies are in-process measurements rather than a server round trip. The
evaluated hybrid wrapper is no longer registered in the current tool layer,
whose hybrid lane is the composed chat configuration of
Section~\ref{sec:twostage}, so the negative ordering result below is bounded
to that retired wrapper. Two further rows are derived offline by replaying the
judged hybrid run's logged twelve-candidate pools and verdict scores:
\emph{Judge-as-filter} keeps survivors in fusion order and \emph{RRF-fuse}
fuses the fusion ranking with the judge-score ranking at $k=60$. All three
see the same candidates and scores, so the comparison is an attribution,
not a benchmark. Because every logged candidate survived the configured 0.5
threshold, the filter replay is identical to fusion order by construction and
does not test filtering.

\begin{table*}[t]
\centering
\small
\setlength{\tabcolsep}{3pt}
\caption{Tool-layer retrieval on the 42-document industrial demonstration corpus
(mean over 16 gold-annotated questions; top-5 document lists; latency per
call, warmed). The paraphrase column re-asks those sixteen questions in
different words (\protect\path{paper-kbs/experiments/results/exp6_paraphrase.json});
block~(b) repeats the Hit@5 measurement on a second corpus, the 79 retrievable
papers of the 100-paper arXiv ingestion, over ten questions.}
\label{tab:retrieval}
\resizebox{\textwidth}{!}{%
\footnotesize
\begin{tabular}{lcccccc}
\toprule
Method & Hit@5 & Recall@5 & MRR@5 & Paraphrase Hit@5 & Latency (mean) & Latency (median) \\
\midrule
BM25                  & 1.00 & 1.00 & 0.958 & 0.88 & 0.9\,ms    & 1\,ms \\
Dense (BGE-M3)        & 0.94 & 0.94 & 0.856 & 0.94 & 18\,ms     & 17\,ms \\
RRF (BM25$\|$Dense)   & 1.00 & 1.00 & 0.927 & 0.88 & 11\,ms     & 9\,ms \\
Graph (Neo4j)         & 0.56 & 0.53 & 0.562 & 0.56 & 68\,ms     & 68\,ms \\
Two-stage             & 1.00 & 0.97 & 0.927 & 0.94 & 77\,ms     & 40\,ms \\
Fusion-only           & 0.94 & 0.94 & 0.856 & 0.94 & 62\,ms     & 66\,ms \\
QDCVR-Hybrid          & 0.44 & 0.41 & 0.226 & 0.50 & 542\,ms    & 582\,ms \\
\midrule
\multicolumn{7}{l}{\emph{Derived (offline, same logged hybrid pools):}}\\
\quad Judge-as-filter$^{\dagger}$ & 0.94 & 0.94 & 0.856 & 0.94 & \multicolumn{2}{l}{$^{\dagger}$542\,ms / 582\,ms} \\
\quad RRF-fuse & 0.88 & 0.88 & 0.606 & 0.88 & \multicolumn{2}{l}{(same single call)} \\
\bottomrule
\end{tabular}}
\par\smallskip
\raggedright\small
$^{\dagger}$\,Derived rows replay the QDCVR-Hybrid run's own logged
12-candidate pools and judge scores, so they reuse that call's latency; the
judge executes once either way.

\par\smallskip
\resizebox{\textwidth}{!}{%
\begin{tabular}{@{}lcccccccc@{}}
\toprule
\multicolumn{9}{@{}l}{\textbf{(b)} Second corpus: 79 retrievable arXiv papers of the 100 submitted, ten questions}\\
\midrule
Configuration & BM25 & Dense & RRF & Graph & Two-stage & Fusion-only & QDCVR-Hybrid & Judge-as-filter \\
Hit@5 & 0.90 & 0.90 & 0.90 & 0.20 & 0.90 & 0.90 & 0.90 & 0.90 \\
\bottomrule
\end{tabular}}
\end{table*}

Table~\ref{tab:retrieval} compares the nine configurations on the sixteen
gold-annotated questions of the industrial demonstration corpus (42 documents;
\path{paper-kbs/experiments/results/exp1_retrieval.json},
\texttt{exp5\_judge\_filter.json}). The tool-layer arms retrieve and never
answer, so their latencies carry no token cost. With sixteen questions the
Wilson 95\% intervals on the headline proportions are wide (judged hybrid
$[0.23, 0.67]$; judge-as-filter $[0.72, 0.99]$; BM25 and RRF
$[0.81, 1.00]$), so the decomposition below, not the point estimates, is
the claim. An earlier six-method ablation was a smoke check at $n = 2$; the
scaled re-run on 2026-10-13 used ten questions (two built-in plus eight corpus
golds, each verified in both substrates), crossed with the three chat-endpoint
lanes (modes~A--C of
Table~\ref{tab:e4-matrix}) with BM25, dense and RRF ranking, pure retrieval,
no generation
(\path{benchmark-suite/results/}
\path{runs/run-20261013T035250Z-5f9faac/retmatrix.json}, archived as a
superseded campaign in
\path{superseded-20261013-batch2.tar.gz};
Table~\ref{tab:e4-matrix}). Document-level
recall: mode~A 10/10 (mean 19.8\,s), mode~B 7/10 (14.0\,s), mode~C 9/10
(33.1\,s); BM25, dense and RRF 10/10 at $\leq$0.1\,s, so on this question set
finding the gold document is not where the lanes earn their cost, and
Section~\ref{sec:e5} measures what they add. The three mode-B misses are
lane-diagnostic (an early-exit misfire onto a same-topic distractor family;
two description-overlap blind spots: a chunked-window and a
multiple-competing-documents question), and the hybrid lane recovers two
through its vector arm while adding one fail-closed judge loss of its own
(the QK01 gold's segments discarded). The dense baseline's first pass
searched an empty default library (zero documents on all ten questions); the
released row is a cross-library re-run, the default since removed from the
runner.

\begin{table}[t]
\caption{Six-method retrieval matrix, ten questions, pure retrieval.
Gold recall is document-level (the gold appears anywhere in the returned
set); every gold was verified to exist in both substrates
(live library for the modes, corpus index for the baselines).
Latency is mean wall clock per question.}
\label{tab:e4-matrix}
\centering\footnotesize
\setlength{\tabcolsep}{4pt}
\begin{tabular}{@{}lccc@{}}
\toprule
Method & Gold recall & Mean latency & Range \\
\midrule
Mode A (pinned dense + judge) & 10/10 & 19.8\,s & 18--24\,s \\
Mode B (ladder)               & 7/10  & 14.0\,s & 5--20\,s \\
Mode C (hybrid)               & 9/10  & 33.1\,s & 26--44\,s \\
BM25 (corpus index)           & 10/10 & $<$0.05\,s & --- \\
Dense (cross-library)         & 10/10 & 0.1\,s  & --- \\
RRF (BM25$\|$Dense)           & 10/10 & $<$0.05\,s & --- \\
\bottomrule
\end{tabular}
\end{table}

\textbf{On this corpus, lexical retrieval is strong.} BM25 \cite{bm25}
hits Hit@5 1.00 at about a millisecond per in-process call, reciprocal-rank
fusion \cite{rrf-cormack} matches it, and the two-stage BM25+graph-then-dense
pipeline reaches Recall@5 0.97 (Table~\ref{tab:retrieval}). Dense
retrieval with BGE-M3 \cite{bge-m3} misses one question (Q16), where four
near-duplicate sibling reports crowd the top-5 --- a confuser-density
failure, not a vocabulary one; graph search \cite{graphrag}, limited to
node-name and tag matching, is the weakest standalone signal. Nothing here
is a retrieval advance: three configurations tie at Hit@5 1.00, and the one
using only words leads on MRR. Q16 carries a filename token that also appears
in its gold path; excluding it leaves BM25 at 1.00 over the remaining fifteen
questions, so the tie does not depend on that leak.

\textbf{The measured result concerns ordering, not threshold-filter efficacy.}
Three configurations use the same logged candidate pools: fusion-only keeps
the original order (Hit@5 0.94), the judge-score reranker changes that order
(Hit@5 0.44), and the derived filter replay retains survivors in fusion order
(Hit@5 0.94). The filter replay matches fusion-only on Hit@5, Recall@5 and MRR;
it does not show a retrieval benefit from thresholding. All 191 recorded
segment scores exceed 0.5 (minimum 0.589); Q14 has one fused candidate without
a recorded score, whose status is unknown. We therefore conclude only that,
among the recorded scored candidates, the threshold rejected none and the
judge-induced ordering lost gold documents. On the eight questions where the
derived filter and reranker differ, restoring fusion order recovers Hit@5 on
all eight and loses none (exact binomial sign test, two-sided $p=0.008$); Q7
moves the gold from rank three to five, while four other questions move
upward. The evidence warns against using these verifier scores as a ranker on
this confuser-heavy corpus; it does not establish that the verdicts reliably
identify evidence or that filtering improves on fusion-only
(Figure~\ref{fig:marginvariants}(b)).

\textbf{A second corpus does not reproduce the Hit@5 collapse, but the ranking
effect is still visible.} Over ten
questions on the 79 retrievable papers of the 100-paper arXiv ingestion
(8{,}031 chunks logged; block~(b) of Table~\ref{tab:retrieval}), seven of
eight configurations reach Hit@5 0.90; graph search reaches 0.20. BQ03's
gold paper was not retrievable, so the observed denominator is 0.90 over all
ten questions and 1.00 over the nine with available gold. The judged ordering
keeps all nine golds inside the top five, but it demotes four of them from
rank one to rank two, and its MRR falls from 0.90 to 0.70 while the filter and
fusion rows stay at 0.90 (\texttt{exp10\_papers\_toollayer.json}). The
threshold-crossing harm therefore does not reproduce on this smaller,
less confuser-dense sample, while the ordering effect does. The graph result
is also configuration-specific: the bulk import bypassed the tagging path,
limiting what its node-name/path matching could retrieve.

\textbf{Thresholds and margins.} All 191 judged candidates from the
sixteen hybrid runs passed the configured absolute threshold of 0.5 (lowest
logged score 0.589), so at the threshold layer the gate filtered nothing on
this corpus (\texttt{exp1\_retrieval.json}). A sweep of the recorded scores
locates where filtering would begin to discriminate: cuts up to 0.70 keep
every in-pool gold and about 95\% of non-golds; 0.80 keeps 16 of 17 golds
while removing 21\% of non-golds; 0.85 keeps 13 of 17 and removes 40\%; at
0.88 the two retention rates converge (7 of 17 golds, 40\% of non-golds). The
signal is narrow and starts above the configured cut, and no answer-level test
of a higher cut was run (supplementary Table~S6). The margin sweep is a
separate diagnostic replay, not the configured control: it re-reads the logged pools
and keeps the top five candidates plus every candidate whose score lies
within a relative margin $m$ of the pool's best score. $m=0.15$ keeps 16 of
the 17 in-pool golds (Q11's gold sits deeper than 0.15 below its pool's
best) and $m=0.20$ keeps all 17; leave-one-out selection of the smallest
safe margin reaches 0.9375, missing only Q11, while a fixed $m=0.20$
reaches 1.00 (\texttt{exp6\_loo\_margin.json};
Figure~\ref{fig:marginvariants}(a) plots the sweep). Both constants are
replay parameters of this diagnostic; the calibration that would justify any
cut for deployment has not been run.

\begin{figure*}[t]
\centering
\includegraphics[width=0.78\textwidth]{fig6_margin_variants}
\caption{Two replays over the logged hybrid runs of this subsection; both
reuse recorded candidate pools and verdict scores rather than retrieving
again. (a)~A relative-margin replay: keep the top five plus every candidate
within $m$ of the pool's best score, $m$ swept 0.0--0.3; the solid curve
counts gold instances kept of the 17 that entered a pool, the grey curve the
mean candidates returned of the twelve submitted; dashed rules mark $m=0.15$
(16 of 17 golds kept) and $m=0.20$ (all 17). (b)~The verdict's four roles,
scored on identical candidates and identical verdict scores: fusion order,
verdict as re-ranker, verdict as filter, and rank fusion. Only the role
differs, which makes the panel an attribution rather than a benchmark; the
re-ranking role is the one that loses the gold.}
\label{fig:marginvariants}
\end{figure*}

\textbf{Rephrasing shows where the fragility sits.} On sixteen paraphrase
questions (\texttt{exp6\_paraphrase.json}) the judged configuration falls
to Hit@5 0.5 (MRR 0.189) while judge-as-filter and fusion-only hold at
0.9375 (MRR 0.833) and dense retrieval stays at 0.9375; BM25 falls from
1.00 to 0.875 (MRR 0.958 to 0.755). Under rewording both the lexical baseline and the judged re-ranking lose
ground while the configuration that keeps fusion order does not: the weakness
is the induced ordering, not the verdicts.

\textbf{End to end, the answer grid of Section~\ref{sec:e5} carries this
comparison.} Its original 30 cells name the gold document in every answer,
with recognized document-style markers in 9/10, 7/10 and 2/10 answers for P, F
and D; its common-substrate replication gives 9/9/9, so the marker ordering is
substrate-bound (Section~\ref{sec:e5}). Marker counts do not test whether
citations resolve or support claims; per-cell records and the replication are
in the supplementary material.


E4 establishes a bounded ordering result: on the logged industrial pools,
judge-score re-ranking lowered Hit@5, while retaining fusion order among
recorded survivors matched fusion-only. This does not establish a benefit from
threshold filtering or claim-level citation support. BM25 reaches Hit@5 1.00
on the same industrial set (Figure~\ref{fig:retrieval}), so retrieval recall is
not a demonstrated contribution here. The deployment-path question is whether
source identifiers, evidence traces and answer workflows improve auditability;
the E5 marker checks only partly address that question, and the verifier
failure analysis does not establish calibration.

\begin{figure}[t]
\centering
\includegraphics[width=\columnwidth]{fig3_retrieval}
\caption{Tool-layer retrieval over the 42-document industrial corpus (16
gold questions, top-5 document lists). BM25 reaches Hit@5 1.00. On the same
logged hybrid pools, verdict-score re-ranking reaches Hit@5 0.44, while a
derived replay that retains fusion order among recorded survivors reaches
0.94, matching fusion-only. The derived comparison diagnoses the effect of
ordering; because the 0.5 threshold rejects none of the 191 recorded scores,
it does not measure filtering benefit. Latency per call is in
Table~\ref{tab:retrieval}.}
\label{fig:retrieval}
\end{figure}


%% ===== source: n8c_eval.tex =====
% n8c_eval.tex — evaluation 8.6-8.8: E5 agent behaviour/abstention/cost,
% E6 verifier failure, E7 non-functional behaviour, E8 ablations.
% Every figure is attributed to its artifact; corpora are never mixed.
% Compressed 2026-10-12 (E7 and E8 reduced to single paragraphs; all
% floats and numbers retained). Round 2 2026-10-12: E6 prose tightened;
% floats and numbers untouched.

\subsection{E5: Answer quality, abstention and cost}
\label{sec:e5}
\label{sec:agentic}\label{sec:abstention}\label{sec:composition}\label{sec:eval-agent}
%% The four labels above are compatibility aliases: n2_related.tex:110,122,139
%% and n6_retrieval.tex:38,53-54 were written against the pre-restructure label
%% set. They all resolve to this subsection (answer quality, abstention,
%% latency composition).
%% Artifact shorthand used throughout this subsection: every path below is
%% relative to the repository root. Campaigns that were current when they were
%% written but are superseded today live in the tarballs listed under Data
%% availability (n_back.tex) and in TEST-RESULTS/ARTIFACTS.md; the
%% 30-cell grid of this subsection is current and unarchived.

\begin{table*}[t]
\centering
\footnotesize
\setlength{\tabcolsep}{3pt}
\caption{Answer quality per question and per interface in the original grid
(30 answer cells from \protect\path{run-20261013T094350Z-5f9faac}); the
controlled replication on a common substrate is reported in the text and adds
no column. Every answer passes the gold-ID
check, so coverage is 10/10 in each arm and the column is not repeated. Each
arm column gives strict keyword coverage (\yes\ or $\times$), alias-aware coverage,
and the number of recognized citation markers (m). Strict coverage is a
majority rule on the annotated terms, not an all-terms rule. Markers count
document-style syntax such as section or table locators; they do not establish
that a cited section exists or supports the sentence citing it.}
\label{tab:e5-answers}
\begin{tabular}{@{}l>{\raggedright\arraybackslash}p{0.335\textwidth}l*{9}{c}@{}}
\toprule
 & & & \multicolumn{3}{c}{Platform (P)} & \multicolumn{3}{c}{File tools (F)} & \multicolumn{3}{c}{Dense (D)}\\
\cmidrule(lr){4-6}\cmidrule(lr){7-9}\cmidrule(lr){10-12}
Q & Question (abridged) & Gold & s & a & m & s & a & m & s & a & m\\
\midrule
BQ01 & Transformer attention; why recurrence is replaced & 1706.03762 & \yes & \yes & 6 & \yes & \yes & 0 & \yes & \yes & 5\\
BQ02 & NISQ definition and its central limitation & 1801.00862 & \yes & \yes & 4 & \yes & \yes & 3 & \yes & \yes & 0\\
BQ03 & MultiMedQA and Flan-PaLM on MedQA & 2212.13138 & \yes & \yes & 4 & \yes & \yes & 1 & \yes & \yes & 1\\
BQ04 & Three ontologies subdividing the Gene Ontology & 1602.01876 & \yes & \yes & 1 & \yes & \yes & 1 & \yes & \yes & 0\\
BQ05 & European growth versus Unified Growth Theory & 1512.08067 & \yes & \yes & 0 & \yes & \yes & 0 & \yes & \yes & 0\\
BQ06 & Contributions governing precipitation extremes & 1503.07557 & $\times$ & \yes & 6 & \yes & \yes & 4 & \yes & \yes & 0\\
BQ07 & MameLoshnLM and its parameter scale & 2608.05850 & \yes & \yes & 1 & \yes & \yes & 2 & \yes & \yes & 0\\
BQ08 & Oxygen redox and cathode capacity & 2408.09942 & \yes & \yes & 2 & \yes & \yes & 0 & \yes & \yes & 0\\
BQ09 & Visual SLAM in dynamic scenes (MLP-SLAM) & 2410.10669 & \yes & \yes & 2 & $\times$ & \yes & 6 & \yes & \yes & 0\\
BQ10 & Tumour control under immune evasion & 2604.01385 & \yes & \yes & 3 & \yes & \yes & 6 & $\times$ & \yes & 0\\
\midrule
 & \emph{All ten questions} & & 9 & 10 & 29 & 9 & 10 & 23 & 9 & 10 & 6\\
\bottomrule
\end{tabular}
\end{table*}

\textbf{Answers locate the right document in all 30 cells of both grids;
keyword and marker counts depend on the substrate.}
Three arms answered ten gold questions through the public chat API on one model
(recorded in the run timeline as claude-opus-4-8[1m]) under one task contract.
In the original grid (Table~\ref{tab:e5-answers},
\path{run-20261013T094350Z-5f9faac}), every answer names its gold document,
alias-aware keyword coverage is 10/10 in every arm, strict keyword coverage is
9/10, and recognized citation-marker hits are 9/10, 7/10 and 2/10 for P, F and
D. Those arms differed in substrate: P used the default all-library scope, F
the exported file tree, and D an 800-character chunk replica. A controlled
replication then pinned all three arms to the same five domain libraries (322
stored parts): P and D search the vector collections and F reads the same
parts in full (\path{rerun5-20261017}). In that grid gold-identifier
coverage is again 10/10 in every arm, but strict coverage is 7/10, 7/10 and
8/10, alias-aware coverage 9/10, 9/10 and 10/10, and citation-marker hits
9/10 in every arm. Across the 30 paired cells the two grids agree on gold ID
in 30, alias coverage in 28, strict coverage in 25 and marker presence in 18;
all five strict disagreements favour the original grid and all nine marker
disagreements the common substrate (exact McNemar $p=0.0625$ and
$p=0.0039$). The marker contrast therefore tracks the substrate, not citation
quality; strict counts are not exchangeable between grids. We report
provenance and alias-aware coverage as the more stable measures and treat
strict and marker counts as substrate-bound; answer quality here means
provenance and lexical coverage, not semantic faithfulness.

\textbf{Per-question reading.}
In the original grid nine platform and seven file-tool answers carry a
document-style marker, while the dense arm produces eight with none; in the
replication the dense arm reads the same libraries and every arm gives nine. BQ05 carries no marker in any grid because it cites by title, a
form the deterministic pattern does not count. The strict misses differ between grids: the
original misses BQ06 in P (a Chinese answer that the declared aliases cover),
BQ09 in F and BQ10 in D; the replication misses BQ06 in all three arms, BQ08
and BQ09 in P and F, and BQ10 in D. Alias-aware coverage loses BQ08 in P and F
in the replication. Figure~\ref{fig:threearms}
shows the original grid's aggregate. Under the
pre-correction BQ06 key the platform arm scored 10/10 strict against a
mis-specified gold, and both grades are retained. A source-presence audit
found that in 29 of the original grid's 30 cells every strict keyword an
answer matched also occurs in the cited gold document (BQ06/P matched none),
and in all 30 replication cells; this is traceability, not entailment
(supplementary Tables~S7 and S8). The original grid also departed from the
stated contract in three cells: the BQ06 platform answer is not in English,
the BQ10 file-tool answer ran to 13 turns, and three platform cells invoked a
host shell outside the knowledge-base tool surface; the replication stayed
within the turn cap but one platform answer contains a short Chinese phrase
(Section~\ref{sec:threats}).

\begin{figure}[t]
\centering
\includegraphics[width=\columnwidth]{fig11_three_arms}
\caption{Answer checks for the original grid (30 cells,
\protect\path{run-20261013T094350Z-5f9faac}). Gold-identifier coverage is at
ceiling in all three arms; strict keyword coverage shows three misses, and
recognized citation markers fall from nine to seven to two answers. On a
common substrate the replication gives nine marker-bearing answers in every
arm, so this contrast is substrate-bound. The marker pattern counts
document-style syntax; it does not verify citation
resolution or claim support. Wall-clock and cost figures for these cells are
reported in the text and in the supplementary material.}
\label{fig:threearms}
\end{figure}

\textbf{Wall clock and cost.}
Arm~P averaged 52.6\,s and \$0.711 per question, against 22.2\,s/\$0.487 for
F and 24.5\,s/\$0.527 for D. These are single-run means: the platform arm is
slower and dearer in this run, and we report that as an observation about this
implementation rather than an efficiency result. Arm~F answered the same
questions by scanning the exported file tree without an index, which shows
direct scanning is viable at this corpus size but does not establish behavior
on the live 322-document collection. An archived sixteen-cell lane grid
recorded sub-second machine-side retrieval against a 36--91\,s end-to-end wall
clock, consistent with model turns dominating latency
\cite{singh-agentic-rag}; per-cell times, tool counts and costs are in the
supplementary material.

\textbf{Abstention is a property of the reading-and-answering layer, not of
a threshold.}
Three out-of-corpus questions produced three explicit not-found reports
(47.9, 73.3 and 113.5\,s wall clock; turns not recorded for this probe
family; \path{paper-kbs/experiments/results/exp8b_absent_agent.json}), each
enumerating the scope it searched (five libraries, 42 documents of the
industrial corpus). The
retrieval tools themselves never abstain: six graded probes
(\path{paper-kbs/experiments/results/exp8_graded_probes.json};
$n = 6$; three partially covered, three absent) retained 10 to 12 of their
12 candidates at every tier, with top scores up to 0.983 on absent probes
and 0.965 on partial ones, and the 0.5 threshold never fired as a refusal
(Figure~\ref{fig:ood}). The lane instructions ask the agent to abstain at the answer stage rather than
using a similarity cut-off as a refusal rule \cite{selfrag,feng-abstain,yin-knowwhat};
we report the observed behavior in these trials, not a server-enforced
abstention guarantee.

\begin{figure}[t]
\centering
\includegraphics[width=\columnwidth]{fig7_ood}
\caption{Tool-layer out-of-corpus probes
(\protect\path{paper-kbs/experiments/results/exp3_abstention.json}) retained 9--11
of the 42--43 merged candidates; dense scores also exceeded the search
threshold. Thus the retrieval threshold did not identify semantic absence in
these probes. In a separate answer-workflow probe family
(\protect\path{paper-kbs/experiments/results/exp8b_absent_agent.json}), three
completed absent queries returned natural-language not-found reports and no
fabricated citation was observed. The latter is an observation of instructed
agent behavior, not a server-side guarantee.}
\label{fig:ood}
\end{figure}

\textbf{Engines and channels.}
Across a separate 18-run task set, every run contained a gold-ID hit and no
manually identified fabricated citation. In the archived channel replay, two
channels each passed 8/9 gates and shared one false refusal after a 300\,s
vector-search stall, an execution failure rather than evidence of absence.
Per-run records are in the supplementary material, and these are observations
across engines and channels, not a one-factor estimate.

\subsection{E5b: Deployment-layer system arms through the public API (2026-10-12 campaign)}
\label{sec:sysarms}
E1--E5 exercise the platform from the operator side. Invoked as an external
caller, does it deliver the same contracts? Three questions (an English
methodology question, a Chinese clinical question and an out-of-corpus probe)
crossed three system arms through the external chat API: arm~A pinned the
target shelf, arm~B left the library unpinned, and arm~C pinned it with a
hybrid-retrieval directive. An in-corpus refusal fails the answer gate; an
earlier marker-only gate had counted refusals that repeated question keywords,
so the rule was corrected before the reported tally.

One streaming campaign and its non-streaming replication were run; per-arm
records are in the supplementary material. Arms A and C returned answers
containing the gold identifiers for both in-corpus questions, and all three
arms reported not-found for the out-of-corpus probe. Mean cost was \$0.182
(A), \$0.300 (B) and \$0.219 (C); a retrieval-only comparison returned the
gold in 6/6 cells.

The campaign also surfaced a transport failure: arm~B falsely refused the
computer-science question in three independent trials (two false refusals and
one hang). The 131-document shelf catalog returned by the librarian's listing
tool measures 74.9\,KB, above the agent engine's tool-output budget, so only a
2\,KB preview reached the model and it never saw the gold entry. Shelves of 53
and 75 documents stay under the budget and succeed, and a scripted lexical
scan over the same catalog answers the question in 25.0\,s and 10.2\,s with
both gold hits. The failure is a transport limit, not a ranking error: the
enforcement layer that honesty requires has transport constraints of its own
(Section~\ref{sec:discussion}).

\textbf{The repair and re-verification.} A 2026-10-13 change added
server-side character budgets, pagination and grouped catalog views. The
131-document shelf was represented by a 571-character grouping view; the
previously failing query was rerun through the same public API and passed the
campaign's answer gate (53.5\,s, nine turns). Two further live queries
exercised pagination and an unsupported cooking question, returning a sourced
answer (98.5\,s, nine turns) and a not-found report after a catalog scan
(39.9\,s, five turns).
These selected reruns show the tested paths completed after the repair; they do
not establish general transport reliability or semantic faithfulness.

\textbf{An adversarial honesty battery (2026-10-13).} Eighteen arms (three
lanes $\times$ six questions through the public API; archived per-arm records)
were scored against ground truth verified \emph{before} the run. One question
has its gold in the library; the five verified-absent ones are two cooking
questions, a same-word different-sense trap, a fine-tuning topic whose
neighbours are near-misses, and a fabricated protocol name. All five return
explicit not-found reports listing the scanned scope and their nearest
near-misses, and zero of the eighteen answers fabricate a citation. On the
fine-tuning question the librarian lane refuses after judging six near-miss
documents, while the hybrid lane returns a body-level applied-usage document
and states the coverage boundary inside the answer; both are honest, and a
binary gate cannot score the second. Two arms that hit a tool-mounting race
reported ``tools unavailable, nothing fabricated'' and were re-run.

\textbf{A second-corpus replication of the honesty contracts.} The same
contracts carry to the arXiv grid: every gold was present in the substrate its
arm searched, all 30 cells answer, and no answerable question is falsely
refused. An archived contrast over unverified three-chunk lists qualified most
answerable questions even where its list contained the gold; it differs in
prompt and granularity, so the contrast is across delivery configurations, not
an attribution to the gate. Platform answers cost \$0.79 each against
\$0.05--0.08 for baseline generation; per-arm records are in the supplement.

\subsection{E6: When the verifier fails}
\label{sec:e6}
\label{sec:inflation}\label{sec:eval-verify}   %% compatibility aliases (n2_related.tex:110)

\textbf{Same-domain score inflation.}
Across sixteen hybrid tool runs, 191 candidate segments have recorded
scores: twelve fused candidates per question except Q14, where eleven have
scores. Every recorded score is at least 0.589, above the 0.5 threshold. The
fusion log contains one additional Q14 candidate without a corresponding score;
its status is unknown, so it is not counted as a threshold rejection. The 17
in-pool gold documents (Q16's gold never entered its pool) have median score
0.88, versus 0.86 for 174 non-gold candidates, a difference not distinguishable
by a two-sided Mann--Whitney test ($p=0.26$; Figure~\ref{fig:inflation}). Five golds rank in the judge-score
top three and nine rank eighth or lower. On these logged pools, judge-score
re-ranking lowers Hit@5 to 0.4375 (7/16; 0.44 in Table~\ref{tab:retrieval});
the derived replay retaining fusion order among recorded survivors matches
fusion-only at 0.9375 (Section~\ref{sec:e4}). Figure~\ref{fig:anatomy}
dissects one query (Q2) in which the induced ordering demotes the gold from
fusion rank~1 to rank~8, outside the answer's read window. These document-ranking results
do not establish claim-level evidence accuracy.

\begin{figure}[!t]
\centering
\includegraphics[width=\columnwidth]{fig4_inflation}
\caption{Recorded Laya scores for 191 candidates from sixteen hybrid runs:
17 in-pool golds and 174 non-golds. All recorded values exceed the dashed
0.5 threshold; one additional Q14 fusion candidate has no recorded score and
its status is unknown. Group medians (0.88 gold, 0.86 non-gold) are not
distinguishable by a two-sided Mann--Whitney test ($p=0.26$). Horizontal
jitter is for legibility.}
\label{fig:inflation}
\end{figure}

\textbf{The verdict is a model \cite{laya}, and a second model fails the
same way.}
The same 191 logged (query, candidate) pairs, replayed rather than
re-retrieved, went through a 330M-parameter natural-language-inference
checkpoint with premises truncated to 1{,}600 characters (59 of 191 pairs at
the cap) (\path{paper-kbs/experiments/results/exp7_second_signal.json}). It
scores below the verdict (Hit@5 0.3125, MRR 0.1375) with inverted
separation, gold median 0.0113 against non-gold 0.05285 ($p = 0.120$).
Truncation is not the cause (six of ten context-fitting golds still score
below 0.01), nor domain: unrelated topics score corpus documents up to
0.9973, so an NLI threshold would abstain on nothing. A span-level replay inverts harder: over the 191 pairs and
3{,}489 span inferences at roughly 320 characters per span
(\path{paper-kbs/experiments/results/exp9_span_nli.json}), max-pooling
gives 0.4728 for gold against 0.91855 for non-gold ($p = 0.0074$), Hit@5
0.1875; rank fusion repairs neither signal (Hit@5 0.3125, MRR 0.111458).
Replacing the judge checkpoint is not the repair.

\textbf{What the failure tracks.}
None of these alternatives reaches the verdict's quality, ruling out the
checkpoint as sole cause; the second corpus shows the same gate losing
no gold from the top five there (Section~\ref{sec:e4}), so the collapse tracks
confuser density within one domain. That probe moved domain, language and corpus size
together with the confuser clusters --- an association confounded by design,
not an elimination
\cite{zheng-llmjudge,panickssery-selfpref,lightman-verify,yin-knowwhat}.
The verdict is not usable as a ranker on these pools. As a filter, the
recorded scores show only the narrow margin reported in
Section~\ref{sec:e4},
and no answer-level test of a higher cut has been run.



\begin{figure*}[t]
\centering
\includegraphics[width=0.78\textwidth]{fig8_anatomy}
\caption{Anatomy of one real query (Q2; single logged QDCVR-Hybrid call).
Each line is one of the 12 fused candidates; the green band is the top-5
window the answer agent reads in full. (a)~The shipped re-ranking: the
judge scores five extruder-PLC telemetry reports $0.887$--$0.926$ and the
gold root-cause report $0.846$, demoting it from fusion rank~1 to
rank~8 --- outside the read window. (b)~The same call with the verdicts
used only as a filter: all 12 pass, the fusion order stands, and the gold
is the first document read. Same pool, same scores, same verdicts; only
the role of the induced ordering differs.}
\label{fig:anatomy}
\end{figure*}



\subsection{E7: Non-functional behaviour}
\label{sec:e7}
The 27-cell stability campaign completed without answer errors (three tasks
$\times$ three retrieval modes $\times$ three rounds;
\path{review/stability-multiround-20261013/results}), with wall-clock spread
14.9--182.0\,s and answers staying on the same evidence. A concurrency
sweep on the same instance (90/180/270 requests at 5/15/30 clients;
supplementary material) recorded \emph{p50} rising from 5.2
to 1577\,ms, with 159 of 270 vector-only requests completing within 30\,s and
the remaining 111 (41\%) hitting the client timeout; the sweep reports no HTTP
errors and the timeouts are a capacity limit, not a correctness failure. A
later cache repair lowered the 30-client read-ladder \emph{p50} from 1577 to
65.8\,ms and repeated-query \emph{p50} from 3743 to 2.1\,ms; distinct
queries remained near 4--5 requests per second under a process-wide lock.
These are single-instance capacity observations, not validated throughput.
Concurrent write phases reported no lost updates, but raw counts and
crash-recovery tests are unavailable, so durability under interruption is not
claimed.


\subsection{E8: Ablations of the verification gate and the search scope}
\label{sec:e8}

Two bounded ablations probe the content gate of Section~\ref{sec:gate} and
the content-routed partition of Section~\ref{sec:org-placement} on the second
corpus (ten questions over five libraries and 322 stored parts). The gate
contrast uses a reconstructed frozen-candidate protocol because the planned
server switch was absent; the partition contrast compares search scopes with
the gold library supplied as a diagnostic condition. These are within-setup
diagnostics, not an end-to-end causal estimate of the three-contract system.
Both yield limited or null evidence; eight questions have a gold-matchable
outcome.

In the gate ablation, three arms shared one candidate pool (cap 12), one
4{,}000-character evidence pack and one grader
(\path{paper-kbs/experiments/results/exp11_gate_ablation.json}): no gate,
the gate as a filter, and a diagnostic arm receiving the judge's own
segment-level pack. Gold was packed at rank 1 in all eight
gold-answerable questions in all three arms, and on nine of ten questions
the gated arms received exactly the ungated arm's documents.
In this reconstructed setup, all returned scored survivors carry judge
provenance; that is an interface property, not evidence that the judge improved
answer quality. The candidate set and budget were held fixed, but downstream
LLM grades varied in both directions (QK01
$0\to5$ and QK03 $3\to0$ under the same twelve-document, 4{,}000-character
pack; sign test $p=1.0$, $n=10$). The only document-level pack shortened by
the gate was QK09 (12 to 4 documents), without changing its grade. The
segment-granularity arm scored 0.375 on the same subset, losing two answers
kept by the document-level arm (QK01, QK07) and gaining one (QK06). These
small-sample results do not establish an answer-quality benefit from the gate. Four of the eight gold-answerable questions (QK02,
QK04, QK05, QK08) scored zero in every arm, and two others scored partial
credit in one arm each. Both
non-gold questions --- an unanswerable and an out-of-corpus probe --- were
answered correctly as abstentions in every arm, the same layer at which the
industrial corpus locates honest abstention (Section~\ref{sec:e5}).

The search-scope diagnostic
(\path{paper-kbs/experiments/results/exp12_partition_ablation.json}) varies
what the retriever can see. With the gold library supplied as the scope,
Hit@5 is 1.0 and the gold ranks first; a deliberately different library gives
Hit@5 0.0 while still returning candidates. Searching all five libraries
matches the gold-pinned result in this ten-question setup. The catalog route
reaches Hit@5 1.0 with mean gold rank 1.75 and selects the correct library
first for six of eight answerable questions. These results illustrate the
consequence of scope choice under the tested filename convention; they do not
independently measure the accuracy of the ingest agent's placement decision.
All 322 stored parts carry an acquisition prefix
(\texttt{\{domain\}\_\_\{arxiv\_id\}\_\_\{slug\}}), so name-based routing
cannot serve as independent placement ground truth; the membership
measurement of Section~\ref{sec:e1} is the only placement-correctness figure
in this paper that avoids this confound, and it comes from the cross-lingual
corpus rather than from this one.

Both ablations are single-corpus, single-engine, ten-question diagnostics; the
gate ablation's control is fusion-ordered, so only its within-run contrast is
interpretable. Two of thirty cells were rerun after authentication failures.
