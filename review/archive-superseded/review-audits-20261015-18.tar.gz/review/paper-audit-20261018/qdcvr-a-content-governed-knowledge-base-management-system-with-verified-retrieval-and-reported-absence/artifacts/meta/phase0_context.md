# Phase 0: Automated Audit Results

**File**: `D:\codes\ClaudeGPT\rag_project\rag-knowledge\paper-kbs\tex\journal_20p\main_20p.tex` | **Language**: en | **Mode**: quick-audit
**Venue**: kbs
**Generated**: 2026-10-18T12:25:13.479981

## Issue Summary (548 total)
- Critical: 2
- Major: 3
- Minor: 543

## Issues by Module

### BIB

| # | Line | Severity | Priority | Issue |
|---|------|----------|----------|-------|
| 1 | — | Minor | P2 | Check: D:\codes\ClaudeGPT\rag_project\rag-knowledge\paper-kbs\tex\journal_20p\refs_new_verified.bib |
| 2 | — | Minor | P2 | WARNING |
| 3 | — | Minor | P2 | entries: 19 |
| 4 | — | Minor | P2 | entries: 19 |
| 5 | — | Minor | P2 | @barredo-arrieta-xai-2020: [IEEE] 12 authors listed; style uses et al. after 6. Ensure bibliography style handles truncation. |
| 6 | — | Minor | P2 | Check: D:\codes\ClaudeGPT\rag_project\rag-knowledge\paper-kbs\tex\journal_20p\refs.bib |
| 7 | — | Minor | P2 | FAIL |
| 8 | — | Minor | P2 | entries: 35 |
| 9 | — | Minor | P2 | entries: 34 |
| 10 | — | Minor | P2 | @rag-lewis: [IEEE] 12 authors listed; style uses et al. after 6. Ensure bibliography style handles truncation. |
| 11 | — | Minor | P2 | @rag-lewis: [IEEE] DOI recommended for inproceedings entries. |
| 12 | — | Minor | P2 | @dpr: Missing required field 'author' |
| 13 | — | Minor | P2 | @selfrag: [IEEE] DOI recommended for inproceedings entries. |
| 14 | — | Minor | P2 | @crag: [IEEE] Missing recommended field 'volume' for article |
| 15 | — | Minor | P2 | @crag: [IEEE] Missing recommended field 'pages' for article |
| 16 | — | Minor | P2 | @flare: [IEEE] 9 authors listed; style uses et al. after 6. Ensure bibliography style handles truncation. |
| 17 | — | Minor | P2 | @graphrag: [IEEE] Missing recommended field 'volume' for article |
| 18 | — | Minor | P2 | @graphrag: [IEEE] Missing recommended field 'pages' for article |
| 19 | — | Minor | P2 | @graphrag: [IEEE] 10 authors listed; style uses et al. after 6. Ensure bibliography style handles truncation. |
| 20 | — | Minor | P2 | @graphrag: [IEEE] DOI recommended for article entries. |
| 21 | — | Minor | P2 | @siren: [IEEE] Missing recommended field 'volume' for article |
| 22 | — | Minor | P2 | @siren: [IEEE] Missing recommended field 'pages' for article |
| 23 | — | Minor | P2 | @siren: [IEEE] 16 authors listed; style uses et al. after 6. Ensure bibliography style handles truncation. |
| 24 | — | Minor | P2 | @siren: [IEEE] DOI recommended for article entries. |
| 25 | — | Minor | P2 | @mineru: [IEEE] Missing recommended field 'volume' for article |
| 26 | — | Minor | P2 | @mineru: [IEEE] Missing recommended field 'pages' for article |
| 27 | — | Minor | P2 | @mineru: [IEEE] 18 authors listed; style uses et al. after 6. Ensure bibliography style handles truncation. |
| 28 | — | Minor | P2 | @deepread: [IEEE] Missing recommended field 'volume' for article |
| 29 | — | Minor | P2 | @deepread: [IEEE] Missing recommended field 'pages' for article |
| 30 | — | Minor | P2 | @cyberbot: [IEEE] 10 authors listed; style uses et al. after 6. Ensure bibliography style handles truncation. |
| 31 | — | Minor | P2 | @react-yao: [IEEE] 7 authors listed; style uses et al. after 6. Ensure bibliography style handles truncation. |
| 32 | — | Minor | P2 | @toolformer: [IEEE] 9 authors listed; style uses et al. after 6. Ensure bibliography style handles truncation. |
| 33 | — | Minor | P2 | @singh-agentic-rag: [IEEE] Missing recommended field 'volume' for article |
| 34 | — | Minor | P2 | @singh-agentic-rag: [IEEE] Missing recommended field 'pages' for article |
| 35 | — | Minor | P2 | @qdcvr-demo: [IEEE] DOI recommended for inproceedings entries. |
| 36 | — | Minor | P2 | @sun-urara: [IEEE] 8 authors listed; style uses et al. after 6. Ensure bibliography style handles truncation. |
| 37 | — | Minor | P2 | @gao-ragsurvey: [IEEE] Missing recommended field 'volume' for article |
| 38 | — | Minor | P2 | @gao-ragsurvey: [IEEE] Missing recommended field 'pages' for article |
| 39 | — | Minor | P2 | 5 entries missing DOI/URL (Use --online-check to export list) |
| 40 | — | Minor | P2 | AI-generated citations have ~40% error rate. Verify entries without DOI/URL using Semantic Scholar API or CrossRef. See references/citations/verification.md for verification workflow. |
| 41 | — | Minor | P3 | [Script] checker exited 1 |

### CITATIONS

| # | Line | Severity | Priority | Issue |
|---|------|----------|----------|-------|
| 1 | — | Minor | P2 | No citation stacking issues found. |

### DEAI

| # | Line | Severity | Priority | Issue |
|---|------|----------|----------|-------|
| 1 | — | Minor | P2 | Use --analyze for full analysis |

### EXPERIMENT

| # | Line | Severity | Priority | Issue |
|---|------|----------|----------|-------|
| 1 | — | Major | P1 | (n7_implementation.tex:33) : Performance claim lacks an explicit baseline or comparator. |
| 2 | — | Critical | P0 | (n7_implementation.tex:35) : Conclusion overreaches the reported evidence; avoid universal or guarantee-style claims. |
| 3 | — | Minor | P2 | (n7_implementation.tex:1) : No ablation or component-level evidence is mentioned; verify that contribution attribution is covered. |
| 4 | — | Minor | P2 | (n7_implementation.tex:1) : No statistical significance, variance, or confidence information is mentioned. |
| 5 | — | Major | P1 | (n9_discussion.tex:1) : Discussion may lack depth: low ratio of explanatory/attribution language (3/71 lines). Add causal analysis explaining why results occur. |
| 6 | — | Minor | P2 | (n11_conclusion.tex:1) : Conclusion lacks implications or broader impact statement. |
| 7 | — | Minor | P2 | (n11_conclusion.tex:1) : Conclusion lacks explicit summary of core findings. |

### FIGURES

| # | Line | Severity | Priority | Issue |
|---|------|----------|----------|-------|
| 1 | — | Minor | P2 | figures in D:\codes\ClaudeGPT\rag_project\rag-knowledge\paper-kbs\tex\journal_20p\main_20p.tex... |
| 2 | — | Minor | P2 | 8 figures. |
| 3 | — | Minor | P2 | n3_overview.tex:76: fig1_architecture |
| 4 | — | Minor | P2 | n6_retrieval.tex:96: fig2_lanes |
| 5 | — | Minor | P2 | n8b_eval.tex:229: fig6_margin_variants |
| 6 | — | Minor | P2 | n8b_eval.tex:273: fig3_retrieval |
| 7 | — | Minor | P2 | n8c_eval.tex:107: fig11_three_arms |
| 8 | — | Minor | P2 | n8c_eval.tex:152: fig7_ood |
| 9 | — | Minor | P2 | n8c_eval.tex:259: fig4_inflation |
| 10 | — | Minor | P2 | n8c_eval.tex:303: fig8_anatomy |
| 11 | — | Minor | P2 | All figures passed check. |

### FORMAT

| # | Line | Severity | Priority | Issue |
|---|------|----------|----------|-------|
| 1 | — | Minor | P2 | ============================================================ |
| 2 | — | Minor | P2 | Format Check Report |
| 3 | — | Minor | P2 | ============================================================ |
| 4 | — | Minor | P2 | D:\codes\ClaudeGPT\rag_project\rag-knowledge\paper-kbs\tex\journal_20p\main_20p.tex |
| 5 | — | Minor | P2 | WARNING |
| 6 | — | Minor | P2 | Found 209 issues |
| 7 | — | Minor | P2 | Found |
| 8 | — | Minor | P2 | (34 issues) |
| 9 | — | Minor | P2 | 98: Wrong length of dash may have been used. |
| 10 | — | Minor | P2 | 24: Wrong length of dash may have been used. |
| 11 | — | Minor | P2 | 32: Wrong length of dash may have been used. |
| 12 | — | Minor | P2 | 32: Wrong length of dash may have been used. |
| 13 | — | Minor | P2 | 69: Wrong length of dash may have been used. |
| 14 | — | Minor | P2 | ... and 29 more |
| 15 | — | Minor | P2 | (2 issues) |
| 16 | — | Minor | P2 | 54: Use either `` or '' as an alternative to `"'. |
| 17 | — | Minor | P2 | 54: Use either `` or '' as an alternative to `"'. |
| 18 | — | Minor | P2 | (173 issues) |
| 19 | — | Minor | P2 | 72: Intersentence spacing (`\@') should perhaps be used. |
| 20 | — | Minor | P2 | 111: Command terminated with space. |
| 21 | — | Minor | P2 | 111: Command terminated with space. |
| 22 | — | Minor | P2 | 111: Command terminated with space. |
| 23 | — | Minor | P2 | 112: Command terminated with space. |
| 24 | — | Minor | P2 | ... and 168 more |
| 25 | — | Minor | P2 | ============================================================ |

### GRAMMAR

| # | Line | Severity | Priority | Issue |
|---|------|----------|----------|-------|
| 1 | — | Minor | P2 | [Script]: goal=grammar strength=minimal |
| 2 | — | Minor | P2 | No rule-based issues detected in selected scope. |

### LOGIC

| # | Line | Severity | Priority | Issue |
|---|------|----------|----------|-------|
| 1 | — | Critical | P0 | Section not found: methods (available: introduction, related, experiment, experiment_2, discussion, conclusion, abstract) |
| 2 | — | Major | P1 | REVIEW (n2_related.tex:104-114) : No research gap derivation found at end of Related Work |

### PRESUBMISSION

| # | Line | Severity | Priority | Issue |
|---|------|----------|----------|-------|
| 1 | 82 | Minor | P2 | [G2] Long paragraph detected (253 words, 12 sentences); split or add a clearer topic sentence. |

### SENTENCES

| # | Line | Severity | Priority | Issue |
|---|------|----------|----------|-------|
| 1 | — | Minor | P2 | [Script]: goal=grammar strength=minimal |
| 2 | — | Minor | P2 | SENTENCE (n1_intro.tex:4, 44 words, 4 clauses)  [Script] |
| 3 | — | Minor | P2 | A document collection becomes a knowledge base only when three things hold: its documents are parsed and admitted reliably, they are organized so that the right material can be found, and the system can answer a question with a citation whose source is traceable. |
| 4 | — | Minor | P2 | A document collection becomes a knowledge base only when three things hold: its documents are parsed and admitted reliably. they are organized so that the right material can be found. and the system can answer a question with a citation whose source is traceable.. |
| 5 | — | Minor | P2 | Sentence exceeds complexity threshold, split for readability. Applying the split needs --strength moderate or higher. |
| 6 | — | Minor | P2 | none (split proposal only; source not rewritten) |
| 7 | — | Minor | P2 | none |
| 8 | — | Minor | P2 | Check: NEEDS-LLM |
| 9 | — | Minor | P2 | Flags:    not-assessed |
| 10 | — | Minor | P2 | SENTENCE (n1_intro.tex:47, 24 words, 4 clauses)  [Script] |
| 11 | — | Minor | P2 | The platform integrates document parsing, content-informed organization, lifecycle management, operational experiences, multi-lane retrieval and a Model Context Protocol (MCP) server with 95 registered tools . |
| 12 | — | Minor | P2 | The platform integrates document parsing. content-informed organization. lifecycle management. operational experiences. multi-lane retrieval and a Model Context Protocol (MCP) server with 95 registered tools .. |
| 13 | — | Minor | P2 | Sentence exceeds complexity threshold, split for readability. Applying the split needs --strength moderate or higher. |
| 14 | — | Minor | P2 | none (split proposal only; source not rewritten) |
| 15 | — | Minor | P2 | none |
| 16 | — | Minor | P2 | Check: NEEDS-LLM |
| 17 | — | Minor | P2 | Flags:    not-assessed |
| 18 | — | Minor | P2 | SENTENCE (n1_intro.tex:54, 32 words, 4 clauses)  [Script] |
| 19 | — | Minor | P2 | \noindent\textbf{Contributions.} \begin{enumerate} \item A self-hosted knowledge-base management system that links quality-gated acquisition, content-informed placement, three-source consistency and lifecycle operations, with an invoked server-side evidence gate on the query path. |
| 20 | — | Minor | P2 | \noindent\textbf{Contributions.} \begin{enumerate} \item A self-hosted knowledge-base management system that links quality-gated acquisition. content-informed placement. three-source consistency and lifecycle operations. with an invoked server-side evidence gate on the query path.. |
| 21 | — | Minor | P2 | Sentence exceeds complexity threshold, split for readability. Applying the split needs --strength moderate or higher. |
| 22 | — | Minor | P2 | none (split proposal only; source not rewritten) |
| 23 | — | Minor | P2 | none |
| 24 | — | Minor | P2 | Check: NEEDS-LLM |
| 25 | — | Minor | P2 | Flags:    not-assessed |
| 26 | — | Minor | P2 | SENTENCE (n1_intro.tex:54, 39 words, 5 clauses)  [Script] |
| 27 | — | Minor | P2 | \item An answer-level evaluation over ten questions crossed with three retrieval interfaces in two 30-cell grids (original and common-substrate), reported per question: gold-identifier presence, strict and alias-aware keyword coverage, recognized citation markers, and abstention on verified-absent questions (Section~ , Table~ ). |
| 28 | — | Minor | P2 | \item An answer-level evaluation over ten questions crossed with three retrieval interfaces in two 30-cell grids (original and common-substrate). reported per question: gold-identifier presence. strict and alias-aware keyword coverage. recognized citation markers. and abstention on verified-absent questions (Section~. Table~ ).. |
| 29 | — | Minor | P2 | Sentence exceeds complexity threshold, split for readability. Applying the split needs --strength moderate or higher. |
| 30 | — | Minor | P2 | none (split proposal only; source not rewritten) |
| 31 | — | Minor | P2 | none |
| 32 | — | Minor | P2 | Check: NEEDS-LLM |
| 33 | — | Minor | P2 | Flags:    not-assessed |
| 34 | — | Minor | P2 | SENTENCE (n1_intro.tex:54, 45 words, 4 clauses)  [Script] |
| 35 | — | Minor | P2 | Ordering candidates by the verifier score lowers Hit@5 from 0.94 to 0.44, while retaining fusion order among recorded survivors restores 0.94; all 191 recorded scores exceed the configured threshold, so the loss is attributable to the induced ordering, not to filtering. |
| 36 | — | Minor | P2 | Ordering candidates by the verifier score lowers Hit@5 from 0.94 to 0.44. while retaining fusion order among recorded survivors restores 0.94; all 191 recorded scores exceed the configured threshold. so the loss is attributable to the induced ordering. not to filtering.. |
| 37 | — | Minor | P2 | Sentence exceeds complexity threshold, split for readability. Applying the split needs --strength moderate or higher. |
| 38 | — | Minor | P2 | none (split proposal only; source not rewritten) |
| 39 | — | Minor | P2 | none |
| 40 | — | Minor | P2 | Check: NEEDS-LLM |
| 41 | — | Minor | P2 | Flags:    not-assessed |
| 42 | — | Minor | P2 | SENTENCE (n1_intro.tex:86, 91 words, 6 clauses)  [Script] |
| 43 | — | Minor | P2 | Five questions structure the design-to-evidence sequence, ordered by the weight of the answer rather than by the pipeline: how the management layer behaves on demonstration and public collections, covering parsing, admission, placement and lifecycle (RQ1); what answer quality the end-to-end workflow reaches on a fixed question set, measured per question and per interface (RQ2); how the tested retrieval configurations compare on document recall and evidence markers (RQ3); whether a verifier score should order candidates or only filter them (RQ4); and what abstention, cost and execution-reliability observations arise in end-to-end trials (RQ5). |
| 44 | — | Minor | P2 | Five questions structure the design-to-evidence sequence. ordered by the weight of the answer rather than by the pipeline: how the management layer behaves on demonstration and public collections. covering parsing. admission. placement and lifecycle (RQ1); what answer quality the end-to-end workflow reaches on a fixed question set. measured per question and per interface (RQ2); how the tested retrieval configurations compare on document recall and evidence markers (RQ3); whether a verifier score should order candidates or only filter them (RQ4); and what abstention. cost and execution-reliability observations arise in end-to-end trials (RQ5).. |
| 45 | — | Minor | P2 | Sentence exceeds complexity threshold, split for readability. Applying the split needs --strength moderate or higher. |
| 46 | — | Minor | P2 | none (split proposal only; source not rewritten) |
| 47 | — | Minor | P2 | none |
| 48 | — | Minor | P2 | Check: NEEDS-LLM |
| 49 | — | Minor | P2 | Flags:    not-assessed |
| 50 | — | Minor | P2 | SENTENCE (n2_related.tex:4, 29 words, 4 clauses)  [Script] |
| 51 | — | Minor | P2 | \subsection{Knowledge management and document acquisition} Public knowledge bases organize facts under explicit ontologies \citep{auer-dbpedia-kb-2007,hoffart-yago2-kb-2013}, whereas enterprise content management emphasizes governance over organizational documents \citep{paivarinta-ecm-2005,tyrvaainen-ecm-2006}. |
| 52 | — | Minor | P2 | \subsection{Knowledge management and document acquisition} Public knowledge bases organize facts under explicit ontologies \citep{auer-dbpedia-kb-2007. hoffart-yago2-kb-2013}. whereas enterprise content management emphasizes governance over organizational documents \citep{paivarinta-ecm-2005. tyrvaainen-ecm-2006}.. |
| 53 | — | Minor | P2 | Sentence exceeds complexity threshold, split for readability. Applying the split needs --strength moderate or higher. |
| 54 | — | Minor | P2 | none (split proposal only; source not rewritten) |
| 55 | — | Minor | P2 | none |
| 56 | — | Minor | P2 | Check: NEEDS-LLM |
| 57 | — | Minor | P2 | Flags:    not-assessed |
| 58 | — | Minor | P2 | SENTENCE (n2_related.tex:4, 28 words, 6 clauses)  [Script] |
| 59 | — | Minor | P2 | Research on organizational knowledge explains how tacit experience becomes shareable \citep{nonaka-seci-1994,nonaka-seci-ba-2000}; adjacent work studies metadata quality, tagging, human review and auditability \citep{park-metadata-quality-2009,golder-tagging-2006,mosqueira-rey-hitl-2022,barredo-arrieta-xai-2020}. |
| 60 | — | Minor | P2 | Research on organizational knowledge explains how tacit experience becomes shareable \citep{nonaka-seci-1994. nonaka-seci-ba-2000}; adjacent work studies metadata quality. tagging. human review and auditability \citep{park-metadata-quality-2009. golder-tagging-2006. mosqueira-rey-hitl-2022. barredo-arrieta-xai-2020}.. |
| 61 | — | Minor | P2 | Sentence exceeds complexity threshold, split for readability. Applying the split needs --strength moderate or higher. |
| 62 | — | Minor | P2 | none (split proposal only; source not rewritten) |
| 63 | — | Minor | P2 | none |
| 64 | — | Minor | P2 | Check: NEEDS-LLM |
| 65 | — | Minor | P2 | Flags:    not-assessed |
| 66 | — | Minor | P2 | SENTENCE (n2_related.tex:4, 18 words, 4 clauses)  [Script] |
| 67 | — | Minor | P2 | Document-AI methods, including layout-aware analysis and MinerU, recover text and structure from complex documents \citep{zhong-publaynet-layout-2019,huang-layoutlmv3-docai-2022,mineru}. |
| 68 | — | Minor | P2 | Document-AI methods. including layout-aware analysis and MinerU. recover text and structure from complex documents \citep{zhong-publaynet-layout-2019. huang-layoutlmv3-docai-2022. mineru}.. |
| 69 | — | Minor | P2 | Sentence exceeds complexity threshold, split for readability. Applying the split needs --strength moderate or higher. |
| 70 | — | Minor | P2 | none (split proposal only; source not rewritten) |
| 71 | — | Minor | P2 | none |
| 72 | — | Minor | P2 | Check: NEEDS-LLM |
| 73 | — | Minor | P2 | Flags:    not-assessed |
| 74 | — | Minor | P2 | SENTENCE (n2_related.tex:45, 18 words, 4 clauses)  [Script] |
| 75 | — | Minor | P2 | Other work studies selective prediction under domain shift, ontology-grounded retrieval and citation verification \citep{kamath,cyberbot,liu-verifiability,gao-citations}. |
| 76 | — | Minor | P2 | Other work studies selective prediction under domain shift. ontology-grounded retrieval and citation verification \citep{kamath. cyberbot. liu-verifiability. gao-citations}.. |
| 77 | — | Minor | P2 | Sentence exceeds complexity threshold, split for readability. Applying the split needs --strength moderate or higher. |
| 78 | — | Minor | P2 | none (split proposal only; source not rewritten) |
| 79 | — | Minor | P2 | none |
| 80 | — | Minor | P2 | Check: NEEDS-LLM |
| 81 | — | Minor | P2 | Flags:    not-assessed |
| 82 | — | Minor | P2 | SENTENCE (n2_related.tex:55, 24 words, 4 clauses)  [Script] |
| 83 | — | Minor | P2 | The LLM-as-a-judge literature documents preference bias, imperfect agreement, listwise instability and self-preference \citep{zheng-llmjudge,sun-urara,panickssery-selfpref}; verifier gaming is an additional concern \citep{lightman-verify}. |
| 84 | — | Minor | P2 | The LLM-as-a-judge literature documents preference bias. imperfect agreement. listwise instability and self-preference \citep{zheng-llmjudge. sun-urara. panickssery-selfpref}; verifier gaming is an additional concern \citep{lightman-verify}.. |
| 85 | — | Minor | P2 | Sentence exceeds complexity threshold, split for readability. Applying the split needs --strength moderate or higher. |
| 86 | — | Minor | P2 | none (split proposal only; source not rewritten) |
| 87 | — | Minor | P2 | none |
| 88 | — | Minor | P2 | Check: NEEDS-LLM |
| 89 | — | Minor | P2 | Flags:    not-assessed |
| 90 | — | Minor | P2 | SENTENCE (n2_related.tex:63, 54 words, 5 clauses)  [Script] |
| 91 | — | Minor | P2 | The gap this study addresses is one of integration and of role separation rather than of missing capabilities: QDCVR examines how acquisition checks, content-informed placement, retrieval and answer-time evidence inspection interact in one knowledge-base workflow, reports where implementation and transport boundaries constrain that workflow, and measures separately the two roles a verifier can play. |
| 92 | — | Minor | P2 | The gap this study addresses is one of integration and of role separation rather than of missing capabilities: QDCVR examines how acquisition checks. content-informed placement. retrieval and answer-time evidence inspection interact in one knowledge-base workflow. reports where implementation and transport boundaries constrain that workflow. and measures separately the two roles a verifier can play.. |
| 93 | — | Minor | P2 | Sentence exceeds complexity threshold, split for readability. Applying the split needs --strength moderate or higher. |
| 94 | — | Minor | P2 | none (split proposal only; source not rewritten) |
| 95 | — | Minor | P2 | none |
| 96 | — | Minor | P2 | Check: NEEDS-LLM |
| 97 | — | Minor | P2 | Flags:    not-assessed |
| 98 | — | Minor | P2 | SENTENCE (n2_related.tex:76, 46 words, 5 clauses)  [Script] |
| 99 | — | Minor | P2 | Its contribution is a knowledge-base management workflow that owns the chain from parse admission to answer citation, a per-question account of the answers that chain produces, and a same-pool diagnostic showing that ordering by the verifier score, not threshold filtering, is where the measurable loss sits. |
| 100 | — | Minor | P2 | Its contribution is a knowledge-base management workflow that owns the chain from parse admission to answer citation. a per-question account of the answers that chain produces. and a same-pool diagnostic showing that ordering by the verifier score. not threshold filtering. is where the measurable loss sits.. |
| 101 | — | Minor | P2 | Sentence exceeds complexity threshold, split for readability. Applying the split needs --strength moderate or higher. |
| 102 | — | Minor | P2 | none (split proposal only; source not rewritten) |
| 103 | — | Minor | P2 | none |
| 104 | — | Minor | P2 | Check: NEEDS-LLM |
| 105 | — | Minor | P2 | Flags:    not-assessed |
| 106 | — | Minor | P2 | SENTENCE (n2_related.tex:99, 284 words, 20 clauses)  [Script] |
| 107 | — | Minor | P2 | \begin{tabular}{@{}>{\raggedright\arraybackslash}p{0.145\textwidth}>{\raggedright\arraybackslash}p{0.285\textwidth}>{\raggedright\arraybackslash}p{0.24\textwidth}>{\raggedright\arraybackslash}p{0.24\textwidth}@{}} \toprule Strand & Representative work & What it optimizes & What it leaves to the deployment\\ \midrule Knowledge management & Public knowledge bases \citep{auer-dbpedia-kb-2007,hoffart-yago2-kb-2013}; enterprise content management \citep{paivarinta-ecm-2005,tyrvaainen-ecm-2006} & An explicit ontology, or governance over a curated collection & Whether an answer drawn from that collection is supported by the text it cites\\ Document AI & Layout-aware extraction \citep{zhong-publaynet-layout-2019,huang-layoutlmv3-docai-2022}; MinerU \citep{mineru} & Recovery of text, tables and formulas from difficult layouts & Whether what was recovered is complete enough to index, and where it is then stored\\ Retrieval & Dense \citep{dpr}, lexical \citep{bm25} and hybrid ranking \citep{rrf-cormack,bge-m3} & Rank quality over a corpus that is assumed indexed & Whether a top-ranked candidate contains evidence for the claim it is used to support\\ Graph-structured organization & GraphRAG \citep{graphrag}, LightRAG \citep{lightrag}, RAPTOR \citep{raptor} & Multi-hop and hierarchical relationships between documents & Evidentiary status: a graph edge is a navigation fact, not evidence\\ Self-reflective generation & Self-RAG \citep{selfrag}, CRAG \citep{crag}, FLARE \citep{flare}; judge-based verification \citep{zheng-llmjudge,lightman-verify} & Evidence assessment or retrieval correction in generation workflows & How verification and abstention interact with knowledge-base acquisition and organization in a knowledge-base workflow\\ Agentic tool use & ReAct \citep{react-yao}, MCP \citep{mcp}, DeepRead \citep{deepread} & Access to retrieval tools behind a stable interface & Whether configured retrieval budgets and failure states are exposed and checked in a particular deployment\\ \midrule QDCVR (this work) & Sections~ --  & An integration of content-informed placement, indexed-state checks, an invoked server-side evidence gate and agent answer reporting & Claims beyond the measured corpora and configurations, bounded in Section~ \\ \bottomrule \end{tabular} \end{table*} |
| 108 | — | Minor | P2 | \begin{tabular}{@{}>{\raggedright\arraybackslash}p{0.145\textwidth}>{\raggedright\arraybackslash}p{0.285\textwidth}>{\raggedright\arraybackslash}p{0.24\textwidth}>{\raggedright\arraybackslash}p{0.24\textwidth}@{}} \toprule Strand & Representative work & What it optimizes & What it leaves to the deployment\\ \midrule Knowledge management & Public knowledge bases \citep{auer-dbpedia-kb-2007. hoffart-yago2-kb-2013}; enterprise content management \citep{paivarinta-ecm-2005. tyrvaainen-ecm-2006} & An explicit ontology. or governance over a curated collection & Whether an answer drawn from that collection is supported by the text it cites\\ Document AI & Layout-aware extraction \citep{zhong-publaynet-layout-2019. huang-layoutlmv3-docai-2022}; MinerU \citep{mineru} & Recovery of text. tables and formulas from difficult layouts & Whether what was recovered is complete enough to index. and where it is then stored\\ Retrieval & Dense \citep{dpr}. lexical \citep{bm25} and hybrid ranking \citep{rrf-cormack. bge-m3} & Rank quality over a corpus that is assumed indexed & Whether a top-ranked candidate contains evidence for the claim it is used to support\\ Graph-structured organization & GraphRAG \citep{graphrag}. LightRAG \citep{lightrag}. RAPTOR \citep{raptor} & Multi-hop and hierarchical relationships between documents & Evidentiary status: a graph edge is a navigation fact. not evidence\\ Self-reflective generation & Self-RAG \citep{selfrag}. CRAG \citep{crag}. FLARE \citep{flare}; judge-based verification \citep{zheng-llmjudge. lightman-verify} & Evidence assessment or retrieval correction in generation workflows & How verification and abstention interact with knowledge-base acquisition and organization in a knowledge-base workflow\\ Agentic tool use & ReAct \citep{react-yao}. MCP \citep{mcp}. DeepRead \citep{deepread} & Access to retrieval tools behind a stable interface & Whether configured retrieval budgets and failure states are exposed and checked in a particular deployment\\ \midrule QDCVR (this work) & Sections~ --  & An integration of content-informed placement. indexed-state checks. an invoked server-side evidence gate and agent answer reporting & Claims beyond the measured corpora and configurations. bounded in Section~ \\ \bottomrule \end{tabular} \end{table*}. |
| 109 | — | Minor | P2 | Sentence exceeds complexity threshold, split for readability. Applying the split needs --strength moderate or higher. |
| 110 | — | Minor | P2 | none (split proposal only; source not rewritten) |
| 111 | — | Minor | P2 | none |
| 112 | — | Minor | P2 | Check: NEEDS-LLM |
| 113 | — | Minor | P2 | Flags:    not-assessed |
| 114 | — | Minor | P2 | SENTENCE (n7_implementation.tex:8, 42 words, 10 clauses)  [Script] |
| 115 | — | Minor | P2 | The platform exposes 95 MCP tools across twelve functional groups, including parsing, search, content verification, indexing, tags, the document graph and operational experience, plus persona distillation, which shares the same storage, catalog and gate but lies outside the scope of this evaluation. |
| 116 | — | Minor | P2 | The platform exposes 95 MCP tools across twelve functional groups. including parsing. search. content verification. indexing. tags. the document graph and operational experience. plus persona distillation. which shares the same storage. catalog and gate but lies outside the scope of this evaluation.. |
| 117 | — | Minor | P2 | Sentence exceeds complexity threshold, split for readability. Applying the split needs --strength moderate or higher. |
| 118 | — | Minor | P2 | none (split proposal only; source not rewritten) |
| 119 | — | Minor | P2 | none |
| 120 | — | Minor | P2 | Check: NEEDS-LLM |
| 121 | — | Minor | P2 | Flags:    not-assessed |
| 122 | — | Minor | P2 | SENTENCE (n8a_eval.tex:4, 40 words, 5 clauses)  [Script] |
| 123 | — | Minor | P2 | Sections --  cover the query path: retrieval quality (Section~ ), answer quality per question and abstention (Section~ , the paper's end-to-end evidence), a deployment-layer replication through the public API (Section~ ), verifier failure (Section~ ), non-functional behavior (Section~ ) and the gate and search-scope ablations (Section~ ). |
| 124 | — | Minor | P2 | Sections --  cover the query path: retrieval quality (Section~ ). answer quality per question and abstention (Section~. the paper's end-to-end evidence). a deployment-layer replication through the public API (Section~ ). verifier failure (Section~ ). non-functional behavior (Section~ ) and the gate and search-scope ablations (Section~ ).. |
| 125 | — | Minor | P2 | Sentence exceeds complexity threshold, split for readability. Applying the split needs --strength moderate or higher. |
| 126 | — | Minor | P2 | none (split proposal only; source not rewritten) |
| 127 | — | Minor | P2 | none |
| 128 | — | Minor | P2 | Check: NEEDS-LLM |
| 129 | — | Minor | P2 | Flags:    not-assessed |
| 130 | — | Minor | P2 | SENTENCE (n8a_eval.tex:22, 28 words, 4 clauses)  [Script] |
| 131 | — | Minor | P2 | (iii)~\emph{Cross-lingual ingestion corpus}: 400 Wikipedia pages per language (English, Chinese, Japanese), 40 extractive cloze queries each with verbatim in-page answers; ingestion only, no retrieval-quality numbers reported. |
| 132 | — | Minor | P2 | (iii)~\emph{Cross-lingual ingestion corpus}: 400 Wikipedia pages per language (English. Chinese. Japanese). 40 extractive cloze queries each with verbatim in-page answers; ingestion only. no retrieval-quality numbers reported.. |
| 133 | — | Minor | P2 | Sentence exceeds complexity threshold, split for readability. Applying the split needs --strength moderate or higher. |
| 134 | — | Minor | P2 | none (split proposal only; source not rewritten) |
| 135 | — | Minor | P2 | none |
| 136 | — | Minor | P2 | Check: NEEDS-LLM |
| 137 | — | Minor | P2 | Flags:    not-assessed |
| 138 | — | Minor | P2 | SENTENCE (n8a_eval.tex:64, 69 words, 6 clauses)  [Script] |
| 139 | — | Minor | P2 | \textbf{Controls.} The deterministic retrieval lanes were re-run and compared field by field, latency excluded; the 27-cell stability suite (Section~ ) and the eighteen-arm honesty battery (Section~ ) carry repeats, whereas the 30-cell answer grid of Section~  is a single run per arm on one model, recorded in the run timeline as claude-opus-4-8[1m] with seed~0 and harness prompt v4-neutral, and is reported as such, as is its controlled replication. |
| 140 | — | Minor | P2 | \textbf{Controls.} The deterministic retrieval lanes were re-run and compared field by field. latency excluded; the 27-cell stability suite (Section~ ) and the eighteen-arm honesty battery (Section~ ) carry repeats. whereas the 30-cell answer grid of Section~  is a single run per arm on one model. recorded in the run timeline as claude-opus-4-8[1m] with seed~0 and harness prompt v4-neutral. and is reported as such. as is its controlled replication.. |
| 141 | — | Minor | P2 | Sentence exceeds complexity threshold, split for readability. Applying the split needs --strength moderate or higher. |
| 142 | — | Minor | P2 | none (split proposal only; source not rewritten) |
| 143 | — | Minor | P2 | none |
| 144 | — | Minor | P2 | Check: NEEDS-LLM |
| 145 | — | Minor | P2 | Flags:    not-assessed |
| 146 | — | Minor | P2 | SENTENCE (n8a_eval.tex:81, 19 words, 4 clauses)  [Script] |
| 147 | — | Minor | P2 | Each row names the function, the test and its scale, the observed outcome, and the subsection that reports it. |
| 148 | — | Minor | P2 | Each row names the function. the test and its scale. the observed outcome. and the subsection that reports it.. |
| 149 | — | Minor | P2 | Sentence exceeds complexity threshold, split for readability. Applying the split needs --strength moderate or higher. |
| 150 | — | Minor | P2 | none (split proposal only; source not rewritten) |
| 151 | — | Minor | P2 | none |
| 152 | — | Minor | P2 | Check: NEEDS-LLM |
| 153 | — | Minor | P2 | Flags:    not-assessed |
| 154 | — | Minor | P2 | SENTENCE (n8a_eval.tex:91, 283 words, 22 clauses)  [Script] |
| 155 | — | Minor | P2 | \begin{tabular}{@{}>{\raggedright\arraybackslash}p{0.115\textwidth}>{\raggedright\arraybackslash}p{0.265\textwidth}>{\raggedright\arraybackslash}p{0.39\textwidth}>{\raggedright\arraybackslash}p{0.10\textwidth}@{}} \toprule Function & Test and scale & Observed outcome & Where\\ \midrule Parse and ingest & 100-paper campaign; nine checks per paper & nine checks per paper, all pass; 91 names in the state file, 79 retrievable at evaluation, 21 unattributable (twelve recorded plus nine unrecorded) & E1\\ Parse quality & 50-paper, 26-domain campaign & 50/50 parsed and verified, all probes ok; 202 tags; 41 tag flags negative without blocking ingestion & E1\\ Structural split & 50 papers at the 30{,}000-character tier & 165 documents (9 whole, 156 parts) in 2{,}672\,s; storage 50/50; descriptions and tags 165/165 & E1\\ Near-duplicate review & 322-document corpus, 0.90 threshold & 35 candidate groups (0.90--0.975), zero true duplicates, nothing deleted & E2\\ Content placement & 100 papers into five libraries; 400 pages per language & 322 stored parts; membership 0.875 (en) and 1.0 (zh, ja) & E1--E2\\ Three-source consistency & Full corpus and 33-document spot check & 322/322 content and 33/33 storage; one rename defect (18 vs 9 chunks) until force re-index & E2\\ Lifecycle operations & 16 scenarios on two disposable libraries & create, move, delete and forced re-index pass; two failures (task status, update check) & E2\\ Sub-library hierarchy & Three-level disposable fixture & create, parent-to-child move, listing, reading and judging all pass & E2\\ Tags and graph & 316-tag registry; 658-node graph & 165 documents pass the tag check in 47.6\,s; four tag edges on one document move 4{,}675 to 4{,}679 & E2\\ Experience store & One small knowledge base; one end-to-end scenario & 13 candidate drafts; one lesson retrieved first at 0.711; approval path unexercised & E3\\ \bottomrule \end{tabular} \end{table*} |
| 156 | — | Minor | P2 | \begin{tabular}{@{}>{\raggedright\arraybackslash}p{0.115\textwidth}>{\raggedright\arraybackslash}p{0.265\textwidth}>{\raggedright\arraybackslash}p{0.39\textwidth}>{\raggedright\arraybackslash}p{0.10\textwidth}@{}} \toprule Function & Test and scale & Observed outcome & Where\\ \midrule Parse and ingest & 100-paper campaign; nine checks per paper & nine checks per paper. all pass; 91 names in the state file. 79 retrievable at evaluation. 21 unattributable (twelve recorded plus nine unrecorded) & E1\\ Parse quality & 50-paper. 26-domain campaign & 50/50 parsed and verified. all probes ok; 202 tags; 41 tag flags negative without blocking ingestion & E1\\ Structural split & 50 papers at the 30{. }000-character tier & 165 documents (9 whole. 156 parts) in 2{. }672\. s; storage 50/50; descriptions and tags 165/165 & E1\\ Near-duplicate review & 322-document corpus. 0.90 threshold & 35 candidate groups (0.90--0.975). zero true duplicates. nothing deleted & E2\\ Content placement & 100 papers into five libraries; 400 pages per language & 322 stored parts; membership 0.875 (en) and 1.0 (zh. ja) & E1--E2\\ Three-source consistency & Full corpus and 33-document spot check & 322/322 content and 33/33 storage; one rename defect (18 vs 9 chunks) until force re-index & E2\\ Lifecycle operations & 16 scenarios on two disposable libraries & create. move. delete and forced re-index pass; two failures (task status. update check) & E2\\ Sub-library hierarchy & Three-level disposable fixture & create. parent-to-child move. listing. reading and judging all pass & E2\\ Tags and graph & 316-tag registry; 658-node graph & 165 documents pass the tag check in 47.6\. s; four tag edges on one document move 4{. }675 to 4{. }679 & E2\\ Experience store & One small knowledge base; one end-to-end scenario & 13 candidate drafts; one lesson retrieved first at 0.711; approval path unexercised & E3\\ \bottomrule \end{tabular} \end{table*}. |
| 157 | — | Minor | P2 | Sentence exceeds complexity threshold, split for readability. Applying the split needs --strength moderate or higher. |
| 158 | — | Minor | P2 | none (split proposal only; source not rewritten) |
| 159 | — | Minor | P2 | none |
| 160 | — | Minor | P2 | Check: NEEDS-LLM |
| 161 | — | Minor | P2 | Flags:    not-assessed |
| 162 | — | Minor | P2 | SENTENCE (n8a_eval.tex:134, 39 words, 5 clauses)  [Script] |
| 163 | — | Minor | P2 | A second 50-paper, 26-domain campaign parsed and verified every paper, indexed them in batch, reported all probes ok, and left 41 of 50 documents with a negative tag flag even though verification passed, so tag-quality failures never blocked ingestion. |
| 164 | — | Minor | P2 | A second 50-paper. 26-domain campaign parsed and verified every paper. indexed them in batch. reported all probes ok. and left 41 of 50 documents with a negative tag flag even though verification passed. so tag-quality failures never blocked ingestion.. |
| 165 | — | Minor | P2 | Sentence exceeds complexity threshold, split for readability. Applying the split needs --strength moderate or higher. |
| 166 | — | Minor | P2 | none (split proposal only; source not rewritten) |
| 167 | — | Minor | P2 | none |
| 168 | — | Minor | P2 | Check: NEEDS-LLM |
| 169 | — | Minor | P2 | Flags:    not-assessed |
| 170 | — | Minor | P2 | SENTENCE (n8a_eval.tex:177, 33 words, 5 clauses)  [Script] |
| 171 | — | Minor | P2 | The tag registry held 316 tags; the tag-quality check passed 165 documents with zero failures in 47.6\,s, and orphan tags accumulate (test tags, section titles), for which a dry-run detector exists. |
| 172 | — | Minor | P2 | The tag registry held 316 tags; the tag-quality check passed 165 documents with zero failures in 47.6\. s. and orphan tags accumulate (test tags. section titles). for which a dry-run detector exists.. |
| 173 | — | Minor | P2 | Sentence exceeds complexity threshold, split for readability. Applying the split needs --strength moderate or higher. |
| 174 | — | Minor | P2 | none (split proposal only; source not rewritten) |
| 175 | — | Minor | P2 | none |
| 176 | — | Minor | P2 | Check: NEEDS-LLM |
| 177 | — | Minor | P2 | Flags:    not-assessed |
| 178 | — | Minor | P2 | SENTENCE (n8b_eval.tex:9, 107 words, 6 clauses)  [Script] |
| 179 | — | Minor | P2 | Three case measurements exist: an extraction campaign over one small knowledge base produced thirteen candidate drafts (archived \path{experience_smoke.json} in the 2026-10-13 batch tarball; \texttt{extract\_candidates}~13, \texttt{drafts\_created}~13); one end-to-end scenario was sedimented into one experience (\texttt{exp-d6f4d47ae3d6}) that a later global experience search returned first, at local similarity 0.711 (archived scenario A6 of the 2026-10-12 full-test campaign); and the draft-approval path was never exercised, because the draft pool was empty (\texttt{count}~0) and \path{experience_draft_read} and \path{experience_draft_approve} could not run; the heuristic extraction path had run only in dry-run mode, returning a dump the quality gate would reject. |
| 180 | — | Minor | P2 | Three case measurements exist: an extraction campaign over one small knowledge base produced thirteen candidate drafts (archived \path{experience_smoke.json} in the 2026-10-13 batch tarball; \texttt{extract\_candidates}~13. \texttt{drafts\_created}~13); one end-to-end scenario was sedimented into one experience (\texttt{exp-d6f4d47ae3d6}) that a later global experience search returned first. at local similarity 0.711 (archived scenario A6 of the 2026-10-12 full-test campaign); and the draft-approval path was never exercised. because the draft pool was empty (\texttt{count}~0) and \path{experience_draft_read} and \path{experience_draft_approve} could not run; the heuristic extraction path had run only in dry-run mode. returning a dump the quality gate would reject.. |
| 181 | — | Minor | P2 | Sentence exceeds complexity threshold, split for readability. Applying the split needs --strength moderate or higher. |
| 182 | — | Minor | P2 | none (split proposal only; source not rewritten) |
| 183 | — | Minor | P2 | none |
| 184 | — | Minor | P2 | Check: NEEDS-LLM |
| 185 | — | Minor | P2 | Flags:    not-assessed |
| 186 | — | Minor | P2 | SENTENCE (n8b_eval.tex:32, 78 words, 5 clauses)  [Script] |
| 187 | — | Minor | P2 | Five were measured through their own tool-layer entry points: \emph{Dense} via \texttt{kb\_search\_vector} with BGE-M3  ; \emph{Graph} via \texttt{kb\_graph\_search}, a keyword match over node names, paths and tags in the document graph; \emph{Two-stage} via \texttt{kb\_search\_two\_stage} (Section~ ); and the hybrid rows via \texttt{kb\_hybrid\_search}, an earlier server-side single-call composition of the vector, catalog and judging tools, with the gate off (\emph{Fusion-only}) and on (\emph{QDCVR-Hybrid}). |
| 188 | — | Minor | P2 | Five were measured through their own tool-layer entry points: \emph{Dense} via \texttt{kb\_search\_vector} with BGE-M3  ; \emph{Graph} via \texttt{kb\_graph\_search}. a keyword match over node names. paths and tags in the document graph; \emph{Two-stage} via \texttt{kb\_search\_two\_stage} (Section~ ); and the hybrid rows via \texttt{kb\_hybrid\_search}. an earlier server-side single-call composition of the vector. catalog and judging tools. with the gate off (\emph{Fusion-only}) and on (\emph{QDCVR-Hybrid}).. |
| 189 | — | Minor | P2 | Sentence exceeds complexity threshold, split for readability. Applying the split needs --strength moderate or higher. |
| 190 | — | Minor | P2 | none (split proposal only; source not rewritten) |
| 191 | — | Minor | P2 | none |
| 192 | — | Minor | P2 | Check: NEEDS-LLM |
| 193 | — | Minor | P2 | Flags:    not-assessed |
| 194 | — | Minor | P2 | SENTENCE (n8b_eval.tex:32, 42 words, 5 clauses)  [Script] |
| 195 | — | Minor | P2 | \emph{BM25} runs in process over the fetched full texts (jieba tokenizer,  ,  ), and \emph{RRF} fuses that ranking with the dense one at ; neither is the platform's keyword tool, so the millisecond latencies are in-process measurements rather than a server round trip. |
| 196 | — | Minor | P2 | \emph{BM25} runs in process over the fetched full texts (jieba tokenizer. ). and \emph{RRF} fuses that ranking with the dense one at ; neither is the platform's keyword tool. so the millisecond latencies are in-process measurements rather than a server round trip.. |
| 197 | — | Minor | P2 | Sentence exceeds complexity threshold, split for readability. Applying the split needs --strength moderate or higher. |
| 198 | — | Minor | P2 | none (split proposal only; source not rewritten) |
| 199 | — | Minor | P2 | none |
| 200 | — | Minor | P2 | Check: NEEDS-LLM |
| 201 | — | Minor | P2 | Flags:    not-assessed |
| 202 | — | Minor | P2 | SENTENCE (n8b_eval.tex:68, 194 words, 20 clauses)  [Script] |
| 203 | — | Minor | P2 | \resizebox{\textwidth}{!}{% \footnotesize \begin{tabular}{lcccccc} \toprule Method & Hit@5 & Recall@5 & MRR@5 & Paraphrase Hit@5 & Latency (mean) & Latency (median) \\ \midrule BM25                  & 1.00 & 1.00 & 0.958 & 0.88 & 0.9\,ms    & 1\,ms \\ Dense (BGE-M3)        & 0.94 & 0.94 & 0.856 & 0.94 & 18\,ms     & 17\,ms \\ RRF (BM25 Dense)   & 1.00 & 1.00 & 0.927 & 0.88 & 11\,ms     & 9\,ms \\ Graph (Neo4j)         & 0.56 & 0.53 & 0.562 & 0.56 & 68\,ms     & 68\,ms \\ Two-stage             & 1.00 & 0.97 & 0.927 & 0.94 & 77\,ms     & 40\,ms \\ Fusion-only           & 0.94 & 0.94 & 0.856 & 0.94 & 62\,ms     & 66\,ms \\ QDCVR-Hybrid          & 0.44 & 0.41 & 0.226 & 0.50 & 542\,ms    & 582\,ms \\ \midrule \multicolumn{7}{l}{\emph{Derived (offline, same logged hybrid pools):}}\\ \quad Judge-as-filter  & 0.94 & 0.94 & 0.856 & 0.94 & \multicolumn{2}{l}{ 542\,ms / 582\,ms} \\ \quad RRF-fuse & 0.88 & 0.88 & 0.606 & 0.88 & \multicolumn{2}{l}{(same single call)} \\ \bottomrule \end{tabular}} \par\smallskip \raggedright\small \,Derived rows replay the QDCVR-Hybrid run's own logged 12-candidate pools and judge scores, so they reuse that call's latency; the judge executes once either way. |
| 204 | — | Minor | P2 | \resizebox{\textwidth}{!}{% \footnotesize \begin{tabular}{lcccccc} \toprule Method & Hit@5 & Recall@5 & MRR@5 & Paraphrase Hit@5 & Latency (mean) & Latency (median) \\ \midrule BM25                  & 1.00 & 1.00 & 0.958 & 0.88 & 0.9\. ms    & 1\. ms \\ Dense (BGE-M3)        & 0.94 & 0.94 & 0.856 & 0.94 & 18\. ms     & 17\. ms \\ RRF (BM25 Dense)   & 1.00 & 1.00 & 0.927 & 0.88 & 11\. ms     & 9\. ms \\ Graph (Neo4j)         & 0.56 & 0.53 & 0.562 & 0.56 & 68\. ms     & 68\. ms \\ Two-stage             & 1.00 & 0.97 & 0.927 & 0.94 & 77\. ms     & 40\. ms \\ Fusion-only           & 0.94 & 0.94 & 0.856 & 0.94 & 62\. ms     & 66\. ms \\ QDCVR-Hybrid          & 0.44 & 0.41 & 0.226 & 0.50 & 542\. ms    & 582\. ms \\ \midrule \multicolumn{7}{l}{\emph{Derived (offline. same logged hybrid pools):}}\\ \quad Judge-as-filter  & 0.94 & 0.94 & 0.856 & 0.94 & \multicolumn{2}{l}{ 542\. ms / 582\. ms} \\ \quad RRF-fuse & 0.88 & 0.88 & 0.606 & 0.88 & \multicolumn{2}{l}{(same single call)} \\ \bottomrule \end{tabular}} \par\smallskip \raggedright\small \. Derived rows replay the QDCVR-Hybrid run's own logged 12-candidate pools and judge scores. so they reuse that call's latency; the judge executes once either way.. |
| 205 | — | Minor | P2 | Sentence exceeds complexity threshold, split for readability. Applying the split needs --strength moderate or higher. |
| 206 | — | Minor | P2 | none (split proposal only; source not rewritten) |
| 207 | — | Minor | P2 | none |
| 208 | — | Minor | P2 | Check: NEEDS-LLM |
| 209 | — | Minor | P2 | Flags:    not-assessed |
| 210 | — | Minor | P2 | SENTENCE (n8b_eval.tex:105, 67 words, 6 clauses)  [Script] |
| 211 | — | Minor | P2 | An earlier six-method ablation was a smoke check at  ; the scaled re-run on 2026-10-13 used ten questions (two built-in plus eight corpus golds, each verified in both substrates), crossed with the three chat-endpoint lanes (modes~A--C of Table~ ) with BM25, dense and RRF ranking, pure retrieval, no generation (\path{benchmark-suite/results/} \path{runs/run-20261013T035250Z-5f9faac/retmatrix.json}, archived as a superseded campaign in \path{superseded-20261013-batch2.tar.gz}; Table~ ). |
| 212 | — | Minor | P2 | An earlier six-method ablation was a smoke check at  ; the scaled re-run on 2026-10-13 used ten questions (two built-in plus eight corpus golds. each verified in both substrates). crossed with the three chat-endpoint lanes (modes~A--C of Table~ ) with BM25. dense and RRF ranking. pure retrieval. no generation (\path{benchmark-suite/results/} \path{runs/run-20261013T035250Z-5f9faac/retmatrix.json}. archived as a superseded campaign in \path{superseded-20261013-batch2.tar.gz}; Table~ ).. |
| 213 | — | Minor | P2 | Sentence exceeds complexity threshold, split for readability. Applying the split needs --strength moderate or higher. |
| 214 | — | Minor | P2 | none (split proposal only; source not rewritten) |
| 215 | — | Minor | P2 | none |
| 216 | — | Minor | P2 | Check: NEEDS-LLM |
| 217 | — | Minor | P2 | Flags:    not-assessed |
| 218 | — | Minor | P2 | SENTENCE (n8b_eval.tex:105, 57 words, 9 clauses)  [Script] |
| 219 | — | Minor | P2 | Document-level recall: mode~A 10/10 (mean 19.8\,s), mode~B 7/10 (14.0\,s), mode~C 9/10 (33.1\,s); BM25, dense and RRF 10/10 at  0.1\,s, so on this question set finding the gold document is not where the lanes earn their cost, and Section~  measures what they add. |
| 220 | — | Minor | P2 | Document-level recall: mode~A 10/10 (mean 19.8\. s). mode~B 7/10 (14.0\. s). mode~C 9/10 (33.1\. s); BM25. dense and RRF 10/10 at  0.1\. s. so on this question set finding the gold document is not where the lanes earn their cost. and Section~  measures what they add.. |
| 221 | — | Minor | P2 | Sentence exceeds complexity threshold, split for readability. Applying the split needs --strength moderate or higher. |
| 222 | — | Minor | P2 | none (split proposal only; source not rewritten) |
| 223 | — | Minor | P2 | none |
| 224 | — | Minor | P2 | Check: NEEDS-LLM |
| 225 | — | Minor | P2 | Flags:    not-assessed |
| 226 | — | Minor | P2 | SENTENCE (n8b_eval.tex:144, 76 words, 9 clauses)  [Script] |
| 227 | — | Minor | P2 | \centering\footnotesize \setlength{\tabcolsep}{4pt} \begin{tabular}{@{}lccc@{}} \toprule Method & Gold recall & Mean latency & Range \\ \midrule Mode A (pinned dense + judge) & 10/10 & 19.8\,s & 18--24\,s \\ Mode B (ladder)               & 7/10  & 14.0\,s & 5--20\,s \\ Mode C (hybrid)               & 9/10  & 33.1\,s & 26--44\,s \\ BM25 (corpus index)           & 10/10 &  0.05\,s & --- \\ Dense (cross-library)         & 10/10 & 0.1\,s  & --- \\ RRF (BM25 Dense)           & 10/10 &  0.05\,s & --- \\ \bottomrule \end{tabular} \end{table} |
| 228 | — | Minor | P2 | \centering\footnotesize \setlength{\tabcolsep}{4pt} \begin{tabular}{@{}lccc@{}} \toprule Method & Gold recall & Mean latency & Range \\ \midrule Mode A (pinned dense + judge) & 10/10 & 19.8\. s & 18--24\. s \\ Mode B (ladder)               & 7/10  & 14.0\. s & 5--20\. s \\ Mode C (hybrid)               & 9/10  & 33.1\. s & 26--44\. s \\ BM25 (corpus index)           & 10/10 &  0.05\. s & --- \\ Dense (cross-library)         & 10/10 & 0.1\. s  & --- \\ RRF (BM25 Dense)           & 10/10 &  0.05\. s & --- \\ \bottomrule \end{tabular} \end{table}. |
| 229 | — | Minor | P2 | Sentence exceeds complexity threshold, split for readability. Applying the split needs --strength moderate or higher. |
| 230 | — | Minor | P2 | none (split proposal only; source not rewritten) |
| 231 | — | Minor | P2 | none |
| 232 | — | Minor | P2 | Check: NEEDS-LLM |
| 233 | — | Minor | P2 | Flags:    not-assessed |
| 234 | — | Minor | P2 | SENTENCE (n8b_eval.tex:160, 36 words, 4 clauses)  [Script] |
| 235 | — | Minor | P2 | Dense retrieval with BGE-M3   misses one question (Q16), where four near-duplicate sibling reports crowd the top-5 --- a confuser-density failure, not a vocabulary one; graph search  , limited to node-name and tag matching, is the weakest standalone signal. |
| 236 | — | Minor | P2 | Dense retrieval with BGE-M3   misses one question (Q16). where four near-duplicate sibling reports crowd the top-5 --- a confuser-density failure. not a vocabulary one; graph search. limited to node-name and tag matching. is the weakest standalone signal.. |
| 237 | — | Minor | P2 | Sentence exceeds complexity threshold, split for readability. Applying the split needs --strength moderate or higher. |
| 238 | — | Minor | P2 | none (split proposal only; source not rewritten) |
| 239 | — | Minor | P2 | none |
| 240 | — | Minor | P2 | Check: NEEDS-LLM |
| 241 | — | Minor | P2 | Flags:    not-assessed |
| 242 | — | Minor | P2 | SENTENCE (n8b_eval.tex:173, 50 words, 4 clauses)  [Script] |
| 243 | — | Minor | P2 | \textbf{The measured result concerns ordering, not threshold-filter efficacy.} Three configurations use the same logged candidate pools: fusion-only keeps the original order (Hit@5 0.94), the judge-score reranker changes that order (Hit@5 0.44), and the derived filter replay retains survivors in fusion order (Hit@5 0.94). |
| 244 | — | Minor | P2 | \textbf{The measured result concerns ordering. not threshold-filter efficacy.} Three configurations use the same logged candidate pools: fusion-only keeps the original order (Hit@5 0.94). the judge-score reranker changes that order (Hit@5 0.44). and the derived filter replay retains survivors in fusion order (Hit@5 0.94).. |
| 245 | — | Minor | P2 | Sentence exceeds complexity threshold, split for readability. Applying the split needs --strength moderate or higher. |
| 246 | — | Minor | P2 | none (split proposal only; source not rewritten) |
| 247 | — | Minor | P2 | none |
| 248 | — | Minor | P2 | Check: NEEDS-LLM |
| 249 | — | Minor | P2 | Flags:    not-assessed |
| 250 | — | Minor | P2 | SENTENCE (n8b_eval.tex:173, 43 words, 4 clauses)  [Script] |
| 251 | — | Minor | P2 | On the eight questions where the derived filter and reranker differ, restoring fusion order recovers Hit@5 on all eight and loses none (exact binomial sign test, two-sided  ); Q7 moves the gold from rank three to five, while four other questions move upward. |
| 252 | — | Minor | P2 | On the eight questions where the derived filter and reranker differ. restoring fusion order recovers Hit@5 on all eight and loses none (exact binomial sign test. two-sided  ); Q7 moves the gold from rank three to five. while four other questions move upward.. |
| 253 | — | Minor | P2 | Sentence exceeds complexity threshold, split for readability. Applying the split needs --strength moderate or higher. |
| 254 | — | Minor | P2 | none (split proposal only; source not rewritten) |
| 255 | — | Minor | P2 | none |
| 256 | — | Minor | P2 | Check: NEEDS-LLM |
| 257 | — | Minor | P2 | Flags:    not-assessed |
| 258 | — | Minor | P2 | SENTENCE (n8b_eval.tex:206, 63 words, 2 clauses)  [Script] |
| 259 | — | Minor | P2 | A sweep of the recorded scores locates where filtering would begin to discriminate: cuts up to 0.70 keep every in-pool gold and about 95\% of non-golds; 0.80 keeps 16 of 17 golds while removing 21\% of non-golds; 0.85 keeps 13 of 17 and removes 40\%; at 0.88 the two retention rates converge (7 of 17 golds, 40\% of non-golds). |
| 260 | — | Minor | P2 | A sweep of the recorded scores locates where filtering would begin to discriminate: cuts up to 0.70 keep every in-pool gold and about 95\% of non-golds; 0.80 keeps 16 of 17 golds while removing 21\% of non-golds; 0.85 keeps 13 of 17 and removes 40\%; at 0.88 the two retention rates converge (7 of 17 golds. 40\% of non-golds).. |
| 261 | — | Minor | P2 | Sentence exceeds complexity threshold, split for readability. Applying the split needs --strength moderate or higher. |
| 262 | — | Minor | P2 | none (split proposal only; source not rewritten) |
| 263 | — | Minor | P2 | none |
| 264 | — | Minor | P2 | Check: NEEDS-LLM |
| 265 | — | Minor | P2 | Flags:    not-assessed |
| 266 | — | Minor | P2 | SENTENCE (n8b_eval.tex:230, 24 words, 4 clauses)  [Script] |
| 267 | — | Minor | P2 | (b)~The verdict's four roles, scored on identical candidates and identical verdict scores: fusion order, verdict as re-ranker, verdict as filter, and rank fusion. |
| 268 | — | Minor | P2 | (b)~The verdict's four roles. scored on identical candidates and identical verdict scores: fusion order. verdict as re-ranker. verdict as filter. and rank fusion.. |
| 269 | — | Minor | P2 | Sentence exceeds complexity threshold, split for readability. Applying the split needs --strength moderate or higher. |
| 270 | — | Minor | P2 | none (split proposal only; source not rewritten) |
| 271 | — | Minor | P2 | none |
| 272 | — | Minor | P2 | Check: NEEDS-LLM |
| 273 | — | Minor | P2 | Flags:    not-assessed |
| 274 | — | Minor | P2 | SENTENCE (n8b_eval.tex:252, 55 words, 5 clauses)  [Script] |
| 275 | — | Minor | P2 | \textbf{End to end, the answer grid of Section~  carries this comparison.} Its original 30 cells name the gold document in every answer, with recognized document-style markers in 9/10, 7/10 and 2/10 answers for P, F and D; its common-substrate replication gives 9/9/9, so the marker ordering is substrate-bound (Section~ ). |
| 276 | — | Minor | P2 | \textbf{End to end. the answer grid of Section~  carries this comparison.} Its original 30 cells name the gold document in every answer. with recognized document-style markers in 9/10. 7/10 and 2/10 answers for P. F and D; its common-substrate replication gives 9/9/9. so the marker ordering is substrate-bound (Section~ ).. |
| 277 | — | Minor | P2 | Sentence exceeds complexity threshold, split for readability. Applying the split needs --strength moderate or higher. |
| 278 | — | Minor | P2 | none (split proposal only; source not rewritten) |
| 279 | — | Minor | P2 | none |
| 280 | — | Minor | P2 | Check: NEEDS-LLM |
| 281 | — | Minor | P2 | Flags:    not-assessed |
| 282 | — | Minor | P2 | SENTENCE (n8b_eval.tex:274, 29 words, 5 clauses)  [Script] |
| 283 | — | Minor | P2 | On the same logged hybrid pools, verdict-score re-ranking reaches Hit@5 0.44, while a derived replay that retains fusion order among recorded survivors reaches 0.94, matching fusion-only. |
| 284 | — | Minor | P2 | On the same logged hybrid pools. verdict-score re-ranking reaches Hit@5 0.44. while a derived replay that retains fusion order among recorded survivors reaches 0.94. matching fusion-only.. |
| 285 | — | Minor | P2 | Sentence exceeds complexity threshold, split for readability. Applying the split needs --strength moderate or higher. |
| 286 | — | Minor | P2 | none (split proposal only; source not rewritten) |
| 287 | — | Minor | P2 | none |
| 288 | — | Minor | P2 | Check: NEEDS-LLM |
| 289 | — | Minor | P2 | Flags:    not-assessed |
| 290 | — | Minor | P2 | SENTENCE (n8c_eval.tex:36, 242 words, 0 clauses)  [Script] |
| 291 | — | Minor | P2 | \begin{tabular}{@{}l>{\raggedright\arraybackslash}p{0.335\textwidth}l*{9}{c}@{}} \toprule & & & \multicolumn{3}{c}{Platform (P)} & \multicolumn{3}{c}{File tools (F)} & \multicolumn{3}{c}{Dense (D)}\\ \cmidrule(lr){4-6}\cmidrule(lr){7-9}\cmidrule(lr){10-12} Q & Question (abridged) & Gold & s & a & m & s & a & m & s & a & m\\ \midrule BQ01 & Transformer attention; why recurrence is replaced & 1706.03762 & \yes & \yes & 6 & \yes & \yes & 0 & \yes & \yes & 5\\ BQ02 & NISQ definition and its central limitation & 1801.00862 & \yes & \yes & 4 & \yes & \yes & 3 & \yes & \yes & 0\\ BQ03 & MultiMedQA and Flan-PaLM on MedQA & 2212.13138 & \yes & \yes & 4 & \yes & \yes & 1 & \yes & \yes & 1\\ BQ04 & Three ontologies subdividing the Gene Ontology & 1602.01876 & \yes & \yes & 1 & \yes & \yes & 1 & \yes & \yes & 0\\ BQ05 & European growth versus Unified Growth Theory & 1512.08067 & \yes & \yes & 0 & \yes & \yes & 0 & \yes & \yes & 0\\ BQ06 & Contributions governing precipitation extremes & 1503.07557 &   & \yes & 6 & \yes & \yes & 4 & \yes & \yes & 0\\ BQ07 & MameLoshnLM and its parameter scale & 2608.05850 & \yes & \yes & 1 & \yes & \yes & 2 & \yes & \yes & 0\\ BQ08 & Oxygen redox and cathode capacity & 2408.09942 & \yes & \yes & 2 & \yes & \yes & 0 & \yes & \yes & 0\\ BQ09 & Visual SLAM in dynamic scenes (MLP-SLAM) & 2410.10669 & \yes & \yes & 2 &   & \yes & 6 & \yes & \yes & 0\\ BQ10 & Tumour control under immune evasion & 2604.01385 & \yes & \yes & 3 & \yes & \yes & 6 &   & \yes & 0\\ \midrule & \emph{All ten questions} & & 9 & 10 & 29 & 9 & 10 & 23 & 9 & 10 & 6\\ \bottomrule \end{tabular} \end{table*} |
| 292 | — | Minor | P2 | \begin{tabular}{@{}l>{\raggedright\arraybackslash}p{0.335\textwidth}l*{9}{c}@{}} \toprule & & & \multicolumn{3}{c}{Platform (P)} & \multicolumn{3}{c}{File tools (F)} & \multicolumn{3}{c}{Dense (D)}\\ \cmidrule(lr){4-6}\cmidrule(lr){7-9}\cmidrule(lr){10-12} Q & Question (abridged) & Gold & s & a & m & s & a & m & s & a & m\\ \midrule BQ01 & Transformer attention; why recurrence is replaced & 1706.03762 & \yes & \yes & 6 & \yes & \yes & 0 & \yes & \yes & 5\\ BQ02 & NISQ definition and its central limitation & 1801.00862 & \yes & \yes & 4 & \yes & \yes & 3 & \yes & \yes & 0\\ BQ03 & MultiMedQA and Flan-PaLM on MedQA & 2212.13138 & \yes & \yes & 4 & \yes & \yes & 1 & \yes & \yes & 1\\ BQ04 & Three ontologies subdividing the Gene Ontology & 1602.01876 & \yes & \yes & 1 & \yes & \yes & 1 & \yes & \yes & 0\\ BQ05 & European growth versus Unified Growth Theory & 1512.08067 & \yes & \yes & 0 & \yes & \yes & 0 & \yes & \yes & 0\\ BQ06 & Contributions governing precipitation extremes & 1503.07557 &   & \yes & 6 & \yes & \yes & 4 & \yes & \yes & 0\\ BQ07 & MameLoshnLM and its parameter scale & 2608.05850 & \yes & \yes & 1 & \yes & \yes & 2 & \yes & \yes & 0\\ BQ08 & Oxygen redox and cathode capacity & 2408.09942 & \yes & \yes & 2 & \yes & \yes & 0 & \yes & \yes & 0\\ BQ09 & Visual SLAM in dynamic scenes (MLP-SLAM) & 2410.10669 & \yes & \yes & 2 &   & \yes & 6 & \yes & \yes & 0\\ BQ10 & Tumour control under immune evasion & 2604.01385 & \yes & \yes & 3 & \yes & \yes & 6 &   & \yes & 0\\ \midrule & \emph{All ten questions} & & 9 & 10 & 29 & 9 & 10 & 23 & 9 & 10 & 6\\ \bottomrule \end{tabular} \end{table*} |
| 293 | — | Minor | P2 | Sentence exceeds complexity threshold, split for readability. Applying the split needs --strength moderate or higher. |
| 294 | — | Minor | P2 | none (split proposal only; source not rewritten) |
| 295 | — | Minor | P2 | none |
| 296 | — | Minor | P2 | Check: NEEDS-LLM |
| 297 | — | Minor | P2 | Flags:    not-assessed |
| 298 | — | Minor | P2 | SENTENCE (n8c_eval.tex:58, 45 words, 7 clauses)  [Script] |
| 299 | — | Minor | P2 | In the original grid (Table~ , \path{run-20261013T094350Z-5f9faac}), every answer names its gold document, alias-aware keyword coverage is 10/10 in every arm, strict keyword coverage is 9/10, and recognized citation-marker hits are 9/10, 7/10 and 2/10 for P, F and D. |
| 300 | — | Minor | P2 | In the original grid (Table~. \path{run-20261013T094350Z-5f9faac}). every answer names its gold document. alias-aware keyword coverage is 10/10 in every arm. strict keyword coverage is 9/10. and recognized citation-marker hits are 9/10. 7/10 and 2/10 for P. F and D.. |
| 301 | — | Minor | P2 | Sentence exceeds complexity threshold, split for readability. Applying the split needs --strength moderate or higher. |
| 302 | — | Minor | P2 | none (split proposal only; source not rewritten) |
| 303 | — | Minor | P2 | none |
| 304 | — | Minor | P2 | Check: NEEDS-LLM |
| 305 | — | Minor | P2 | Flags:    not-assessed |
| 306 | — | Minor | P2 | SENTENCE (n8c_eval.tex:58, 40 words, 6 clauses)  [Script] |
| 307 | — | Minor | P2 | In that grid gold-identifier coverage is again 10/10 in every arm, but strict coverage is 7/10, 7/10 and 8/10, alias-aware coverage 9/10, 9/10 and 10/10, and citation-marker hits 9/10 in every arm. |
| 308 | — | Minor | P2 | In that grid gold-identifier coverage is again 10/10 in every arm. but strict coverage is 7/10. 7/10 and 8/10. alias-aware coverage 9/10. 9/10 and 10/10. and citation-marker hits 9/10 in every arm.. |
| 309 | — | Minor | P2 | Sentence exceeds complexity threshold, split for readability. Applying the split needs --strength moderate or higher. |
| 310 | — | Minor | P2 | none (split proposal only; source not rewritten) |
| 311 | — | Minor | P2 | none |
| 312 | — | Minor | P2 | Check: NEEDS-LLM |
| 313 | — | Minor | P2 | Flags:    not-assessed |
| 314 | — | Minor | P2 | SENTENCE (n8c_eval.tex:83, 46 words, 4 clauses)  [Script] |
| 315 | — | Minor | P2 | The strict misses differ between grids: the original misses BQ06 in P (a Chinese answer that the declared aliases cover), BQ09 in F and BQ10 in D; the replication misses BQ06 in all three arms, BQ08 and BQ09 in P and F, and BQ10 in D. |
| 316 | — | Minor | P2 | The strict misses differ between grids: the original misses BQ06 in P (a Chinese answer that the declared aliases cover). BQ09 in F and BQ10 in D; the replication misses BQ06 in all three arms. BQ08 and BQ09 in P and F. and BQ10 in D.. |
| 317 | — | Minor | P2 | Sentence exceeds complexity threshold, split for readability. Applying the split needs --strength moderate or higher. |
| 318 | — | Minor | P2 | none (split proposal only; source not rewritten) |
| 319 | — | Minor | P2 | none |
| 320 | — | Minor | P2 | Check: NEEDS-LLM |
| 321 | — | Minor | P2 | Flags:    not-assessed |
| 322 | — | Minor | P2 | SENTENCE (n8c_eval.tex:133, 58 words, 5 clauses)  [Script] |
| 323 | — | Minor | P2 | \textbf{Abstention is a property of the reading-and-answering layer, not of a threshold.} Three out-of-corpus questions produced three explicit not-found reports (47.9, 73.3 and 113.5\,s wall clock; turns not recorded for this probe family; \path{paper-kbs/experiments/results/exp8b_absent_agent.json}), each enumerating the scope it searched (five libraries, 42 documents of the industrial corpus). |
| 324 | — | Minor | P2 | \textbf{Abstention is a property of the reading-and-answering layer. not of a threshold.} Three out-of-corpus questions produced three explicit not-found reports (47.9. 73.3 and 113.5\. s wall clock; turns not recorded for this probe family; \path{paper-kbs/experiments/results/exp8b_absent_agent.json}). each enumerating the scope it searched (five libraries. 42 documents of the industrial corpus).. |
| 325 | — | Minor | P2 | Sentence exceeds complexity threshold, split for readability. Applying the split needs --strength moderate or higher. |
| 326 | — | Minor | P2 | none (split proposal only; source not rewritten) |
| 327 | — | Minor | P2 | none |
| 328 | — | Minor | P2 | Check: NEEDS-LLM |
| 329 | — | Minor | P2 | Flags:    not-assessed |
| 330 | — | Minor | P2 | SENTENCE (n8c_eval.tex:191, 36 words, 4 clauses)  [Script] |
| 331 | — | Minor | P2 | The 131-document shelf catalog returned by the librarian's listing tool measures 74.9\,KB, above the agent engine's tool-output budget, so only a 2\,KB preview reached the model and it never saw the gold entry. |
| 332 | — | Minor | P2 | The 131-document shelf catalog returned by the librarian's listing tool measures 74.9\. KB. above the agent engine's tool-output budget. so only a 2\. KB preview reached the model and it never saw the gold entry.. |
| 333 | — | Minor | P2 | Sentence exceeds complexity threshold, split for readability. Applying the split needs --strength moderate or higher. |
| 334 | — | Minor | P2 | none (split proposal only; source not rewritten) |
| 335 | — | Minor | P2 | none |
| 336 | — | Minor | P2 | Check: NEEDS-LLM |
| 337 | — | Minor | P2 | Flags:    not-assessed |
| 338 | — | Minor | P2 | SENTENCE (n8c_eval.tex:202, 33 words, 5 clauses)  [Script] |
| 339 | — | Minor | P2 | Two further live queries exercised pagination and an unsupported cooking question, returning a sourced answer (98.5\,s, nine turns) and a not-found report after a catalog scan (39.9\,s, five turns). |
| 340 | — | Minor | P2 | Two further live queries exercised pagination and an unsupported cooking question. returning a sourced answer (98.5\. s. nine turns) and a not-found report after a catalog scan (39.9\. s. five turns).. |
| 341 | — | Minor | P2 | Sentence exceeds complexity threshold, split for readability. Applying the split needs --strength moderate or higher. |
| 342 | — | Minor | P2 | none (split proposal only; source not rewritten) |
| 343 | — | Minor | P2 | none |
| 344 | — | Minor | P2 | Check: NEEDS-LLM |
| 345 | — | Minor | P2 | Flags:    not-assessed |
| 346 | — | Minor | P2 | SENTENCE (n8c_eval.tex:269, 51 words, 5 clauses)  [Script] |
| 347 | — | Minor | P2 | \textbf{The verdict is a model  , and a second model fails the same way.} The same 191 logged (query, candidate) pairs, replayed rather than re-retrieved, went through a 330M-parameter natural-language-inference checkpoint with premises truncated to 1{,}600 characters (59 of 191 pairs at the cap) (\path{paper-kbs/experiments/results/exp7_second_signal.json}). |
| 348 | — | Minor | P2 | \textbf{The verdict is a model. and a second model fails the same way.} The same 191 logged (query. candidate) pairs. replayed rather than re-retrieved. went through a 330M-parameter natural-language-inference checkpoint with premises truncated to 1{. }600 characters (59 of 191 pairs at the cap) (\path{paper-kbs/experiments/results/exp7_second_signal.json}).. |
| 349 | — | Minor | P2 | Sentence exceeds complexity threshold, split for readability. Applying the split needs --strength moderate or higher. |
| 350 | — | Minor | P2 | none (split proposal only; source not rewritten) |
| 351 | — | Minor | P2 | none |
| 352 | — | Minor | P2 | Check: NEEDS-LLM |
| 353 | — | Minor | P2 | Flags:    not-assessed |
| 354 | — | Minor | P2 | SENTENCE (n8c_eval.tex:269, 53 words, 4 clauses)  [Script] |
| 355 | — | Minor | P2 | A span-level replay inverts harder: over the 191 pairs and 3{,}489 span inferences at roughly 320 characters per span (\path{paper-kbs/experiments/results/exp9_span_nli.json}), max-pooling gives 0.4728 for gold against 0.91855 for non-gold ( ), Hit@5 0.1875; rank fusion repairs neither signal (Hit@5 0.3125, MRR 0.111458). |
| 356 | — | Minor | P2 | A span-level replay inverts harder: over the 191 pairs and 3{. }489 span inferences at roughly 320 characters per span (\path{paper-kbs/experiments/results/exp9_span_nli.json}). max-pooling gives 0.4728 for gold against 0.91855 for non-gold ( ). Hit@5 0.1875; rank fusion repairs neither signal (Hit@5 0.3125. MRR 0.111458).. |
| 357 | — | Minor | P2 | Sentence exceeds complexity threshold, split for readability. Applying the split needs --strength moderate or higher. |
| 358 | — | Minor | P2 | none (split proposal only; source not rewritten) |
| 359 | — | Minor | P2 | none |
| 360 | — | Minor | P2 | Check: NEEDS-LLM |
| 361 | — | Minor | P2 | Flags:    not-assessed |
| 362 | — | Minor | P2 | SENTENCE (n8c_eval.tex:320, 64 words, 4 clauses)  [Script] |
| 363 | — | Minor | P2 | A concurrency sweep on the same instance (90/180/270 requests at 5/15/30 clients; supplementary material) recorded \emph{p50} rising from 5.2 to 1577\,ms, with 159 of 270 vector-only requests completing within 30\,s and the remaining 111 (41\%) hitting the client timeout; the sweep reports no HTTP errors and the timeouts are a capacity limit, not a correctness failure. |
| 364 | — | Minor | P2 | A concurrency sweep on the same instance (90/180/270 requests at 5/15/30 clients; supplementary material) recorded \emph{p50} rising from 5.2 to 1577\. ms. with 159 of 270 vector-only requests completing within 30\. s and the remaining 111 (41\%) hitting the client timeout; the sweep reports no HTTP errors and the timeouts are a capacity limit. not a correctness failure.. |
| 365 | — | Minor | P2 | Sentence exceeds complexity threshold, split for readability. Applying the split needs --strength moderate or higher. |
| 366 | — | Minor | P2 | none (split proposal only; source not rewritten) |
| 367 | — | Minor | P2 | none |
| 368 | — | Minor | P2 | Check: NEEDS-LLM |
| 369 | — | Minor | P2 | Flags:    not-assessed |
| 370 | — | Minor | P2 | SENTENCE (n8c_eval.tex:351, 43 words, 5 clauses)  [Script] |
| 371 | — | Minor | P2 | In the gate ablation, three arms shared one candidate pool (cap 12), one 4{,}000-character evidence pack and one grader (\path{paper-kbs/experiments/results/exp11_gate_ablation.json}): no gate, the gate as a filter, and a diagnostic arm receiving the judge's own segment-level pack. |
| 372 | — | Minor | P2 | In the gate ablation. three arms shared one candidate pool (cap 12). one 4{. }000-character evidence pack and one grader (\path{paper-kbs/experiments/results/exp11_gate_ablation.json}): no gate. the gate as a filter. and a diagnostic arm receiving the judge's own segment-level pack.. |
| 373 | — | Minor | P2 | Sentence exceeds complexity threshold, split for readability. Applying the split needs --strength moderate or higher. |
| 374 | — | Minor | P2 | none (split proposal only; source not rewritten) |
| 375 | — | Minor | P2 | none |
| 376 | — | Minor | P2 | Check: NEEDS-LLM |
| 377 | — | Minor | P2 | Flags:    not-assessed |
| 378 | — | Minor | P2 | SENTENCE (n8c_eval.tex:351, 28 words, 4 clauses)  [Script] |
| 379 | — | Minor | P2 | The candidate set and budget were held fixed, but downstream LLM grades varied in both directions (QK01 and QK03   under the same twelve-document, 4{,}000-character pack; sign test  ,  ). |
| 380 | — | Minor | P2 | The candidate set and budget were held fixed. but downstream LLM grades varied in both directions (QK01 and QK03   under the same twelve-document. 4{. }000-character pack; sign test. ).. |
| 381 | — | Minor | P2 | Sentence exceeds complexity threshold, split for readability. Applying the split needs --strength moderate or higher. |
| 382 | — | Minor | P2 | none (split proposal only; source not rewritten) |
| 383 | — | Minor | P2 | none |
| 384 | — | Minor | P2 | Check: NEEDS-LLM |
| 385 | — | Minor | P2 | Flags:    not-assessed |
| 386 | — | Minor | P2 | SENTENCE (n8c_eval.tex:351, 25 words, 4 clauses)  [Script] |
| 387 | — | Minor | P2 | Four of the eight gold-answerable questions (QK02, QK04, QK05, QK08) scored zero in every arm, and two others scored partial credit in one arm each. |
| 388 | — | Minor | P2 | Four of the eight gold-answerable questions (QK02. QK04. QK05. QK08) scored zero in every arm. and two others scored partial credit in one arm each.. |
| 389 | — | Minor | P2 | Sentence exceeds complexity threshold, split for readability. Applying the split needs --strength moderate or higher. |
| 390 | — | Minor | P2 | none (split proposal only; source not rewritten) |
| 391 | — | Minor | P2 | none |
| 392 | — | Minor | P2 | Check: NEEDS-LLM |
| 393 | — | Minor | P2 | Flags:    not-assessed |
| 394 | — | Minor | P2 | SENTENCE (n9_discussion.tex:16, 49 words, 5 clauses)  [Script] |
| 395 | — | Minor | P2 | The second corpus does not reproduce the collapse, so the strongest supported claim is that ranking by these checkpoints should not replace fusion order under the tested confuser density; whether confuser density itself is the cause remains an association, because the probe moved domain, language and corpus size together. |
| 396 | — | Minor | P2 | The second corpus does not reproduce the collapse. so the strongest supported claim is that ranking by these checkpoints should not replace fusion order under the tested confuser density; whether confuser density itself is the cause remains an association. because the probe moved domain. language and corpus size together.. |
| 397 | — | Minor | P2 | Sentence exceeds complexity threshold, split for readability. Applying the split needs --strength moderate or higher. |
| 398 | — | Minor | P2 | none (split proposal only; source not rewritten) |
| 399 | — | Minor | P2 | none |
| 400 | — | Minor | P2 | Check: NEEDS-LLM |
| 401 | — | Minor | P2 | Flags:    not-assessed |
| 402 | — | Minor | P2 | SENTENCE (n9_discussion.tex:33, 47 words, 4 clauses)  [Script] |
| 403 | — | Minor | P2 | In this system, the answer workflow instructs the agent to report the searched scope and say not-found when its completed evidence review finds no support; the retrieval threshold never played that role, since the graded probes retained 10 to 12 of their 12 candidates at every tier. |
| 404 | — | Minor | P2 | In this system. the answer workflow instructs the agent to report the searched scope and say not-found when its completed evidence review finds no support; the retrieval threshold never played that role. since the graded probes retained 10 to 12 of their 12 candidates at every tier.. |
| 405 | — | Minor | P2 | Sentence exceeds complexity threshold, split for readability. Applying the split needs --strength moderate or higher. |
| 406 | — | Minor | P2 | none (split proposal only; source not rewritten) |
| 407 | — | Minor | P2 | none |
| 408 | — | Minor | P2 | Check: NEEDS-LLM |
| 409 | — | Minor | P2 | Flags:    not-assessed |
| 410 | — | Minor | P2 | SENTENCE (n9_discussion.tex:68, 19 words, 4 clauses)  [Script] |
| 411 | — | Minor | P2 | More broadly, parsers, registries, indices and answer workflows benefit from post-conditions that can be checked independently of success messages. |
| 412 | — | Minor | P2 | More broadly. parsers. registries. indices and answer workflows benefit from post-conditions that can be checked independently of success messages.. |
| 413 | — | Minor | P2 | Sentence exceeds complexity threshold, split for readability. Applying the split needs --strength moderate or higher. |
| 414 | — | Minor | P2 | none (split proposal only; source not rewritten) |
| 415 | — | Minor | P2 | none |
| 416 | — | Minor | P2 | Check: NEEDS-LLM |
| 417 | — | Minor | P2 | Flags:    not-assessed |
| 418 | — | Minor | P2 | SENTENCE (n9_discussion.tex:68, 40 words, 7 clauses)  [Script] |
| 419 | — | Minor | P2 | Larger independent question sets, repeated agent trials, claim-level support assessments, a confuser-density-controlled verifier evaluation that holds corpus, language and question set fixed while varying near-duplicate density, operator studies of not-found reports and crash-recovery tests are needed before stronger deployment claims. |
| 420 | — | Minor | P2 | Larger independent question sets. repeated agent trials. claim-level support assessments. a confuser-density-controlled verifier evaluation that holds corpus. language and question set fixed while varying near-duplicate density. operator studies of not-found reports and crash-recovery tests are needed before stronger deployment claims.. |
| 421 | — | Minor | P2 | Sentence exceeds complexity threshold, split for readability. Applying the split needs --strength moderate or higher. |
| 422 | — | Minor | P2 | none (split proposal only; source not rewritten) |
| 423 | — | Minor | P2 | none |
| 424 | — | Minor | P2 | Check: NEEDS-LLM |
| 425 | — | Minor | P2 | Flags:    not-assessed |
| 426 | — | Minor | P2 | SENTENCE (n11_conclusion.tex:4, 34 words, 7 clauses)  [Script] |
| 427 | — | Minor | P2 | The management layer parses and admits documents through gates that fail visibly, places them by content, keeps document files, the tree registry and library metadata consistent, and audits rename, move, delete and re-index operations. |
| 428 | — | Minor | P2 | The management layer parses and admits documents through gates that fail visibly. places them by content. keeps document files. the tree registry and library metadata consistent. and audits rename. move. delete and re-index operations.. |
| 429 | — | Minor | P2 | Sentence exceeds complexity threshold, split for readability. Applying the split needs --strength moderate or higher. |
| 430 | — | Minor | P2 | none (split proposal only; source not rewritten) |
| 431 | — | Minor | P2 | none |
| 432 | — | Minor | P2 | Check: NEEDS-LLM |
| 433 | — | Minor | P2 | Flags:    not-assessed |
| 434 | — | Minor | P2 | SENTENCE (n11_conclusion.tex:27, 46 words, 4 clauses)  [Script] |
| 435 | — | Minor | P2 | On identical logged pools, ordering candidates by the verdict lowers Hit@5 from 0.94 to 0.44, while retaining fusion order among recorded survivors restores 0.94; all 191 recorded scores exceed the 0.5 threshold, and one additional fusion candidate has no recorded score. |
| 436 | — | Minor | P2 | On identical logged pools. ordering candidates by the verdict lowers Hit@5 from 0.94 to 0.44. while retaining fusion order among recorded survivors restores 0.94; all 191 recorded scores exceed the 0.5 threshold. and one additional fusion candidate has no recorded score.. |
| 437 | — | Minor | P2 | Sentence exceeds complexity threshold, split for readability. Applying the split needs --strength moderate or higher. |
| 438 | — | Minor | P2 | none (split proposal only; source not rewritten) |
| 439 | — | Minor | P2 | none |
| 440 | — | Minor | P2 | Check: NEEDS-LLM |
| 441 | — | Minor | P2 | Flags:    not-assessed |
| 442 | — | Minor | P2 | SENTENCE (n11_conclusion.tex:36, 31 words, 5 clauses)  [Script] |
| 443 | — | Minor | P2 | Next steps include independently curated questions, repeated agent trials, claim-level evidence-support evaluation, a confuser-density-controlled verifier evaluation, explicit execution-failure states for incomplete searches, transport stress tests and operator studies of not-found reports. |
| 444 | — | Minor | P2 | Next steps include independently curated questions. repeated agent trials. claim-level evidence-support evaluation. a confuser-density-controlled verifier evaluation. explicit execution-failure states for incomplete searches. transport stress tests and operator studies of not-found reports.. |
| 445 | — | Minor | P2 | Sentence exceeds complexity threshold, split for readability. Applying the split needs --strength moderate or higher. |
| 446 | — | Minor | P2 | none (split proposal only; source not rewritten) |
| 447 | — | Minor | P2 | none |
| 448 | — | Minor | P2 | Check: NEEDS-LLM |
| 449 | — | Minor | P2 | Flags:    not-assessed |
| 450 | — | Minor | P2 | SENTENCE (main_20p.tex:82, 30 words, 6 clauses)  [Script] |
| 451 | — | Minor | P2 | Its management layer parses and gates documents, splits long files, places documents by content rather than filename, and keeps files, registry and metadata consistent through rename, move, delete and re-index. |
| 452 | — | Minor | P2 | Its management layer parses and gates documents. splits long files. places documents by content rather than filename. and keeps files. registry and metadata consistent through rename. move. delete and re-index.. |
| 453 | — | Minor | P2 | Sentence exceeds complexity threshold, split for readability. Applying the split needs --strength moderate or higher. |
| 454 | — | Minor | P2 | none (split proposal only; source not rewritten) |
| 455 | — | Minor | P2 | none |
| 456 | — | Minor | P2 | Check: NEEDS-LLM |
| 457 | — | Minor | P2 | Flags:    not-assessed |

## Pre-Submission Checklist

- [x] No placeholder text (TODO, FIXME, XXX)
- [x] All figures referenced in text
- [x] All tables referenced in text
- [x] Anonymous submission (blind review check)
- [x] Consistent math notation
- [ ] Acronyms defined on first use — Potentially undefined: ['AI', 'AUTHOR', 'ACTION', 'QDCVR', 'ORCID']
