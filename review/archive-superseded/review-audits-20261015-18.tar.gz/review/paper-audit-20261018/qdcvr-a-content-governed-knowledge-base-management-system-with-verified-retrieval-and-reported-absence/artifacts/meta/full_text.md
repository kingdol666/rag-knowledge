# Full text (expanded)

## Abstract
Document collections need more than a retriever: documents must be
parsed and admitted, organized so that they can be found, and used to answer
questions whose cited evidence can be traced. We present QDCVR, a self-hosted
knowledge-base management system that treats content as the shared object
across acquisition, organization and question answering. Its management layer
parses and gates documents, splits long files, places
documents by content rather than filename, and keeps files, registry and
metadata consistent through rename, move, delete and re-index. Retrieval is one
module: three lanes share an invoked server-side content verifier, and an
answer workflow is instructed to report absence.
We evaluate the system on three corpora, one an industrial demonstration
instance. Our evaluation method combines functional audits, per-question
answer checks, abstention probes and same-pool replays.
On ten arXiv
questions crossed with three retrieval interfaces in two 30-cell grids, every
answer names its gold document and alias-aware coverage is 9-10/10; the
controlled common-substrate replication shows that strict keyword and marker
counts are substrate-bound, not interface-specific. Acquisition left 21 of 100 submissions unretrievable without a
complete failure inventory, and a reproduced catalog-transport failure was
repaired. In a same-pool replay on an industrial corpus, ordering
by the verifier score reduces Hit@5 from 0.94 to 0.44 while fusion order
restores 0.94; the scores are not usable as a ranker, and the 0.5 cut filtered
nothing. Wall-clock and cost disfavor the
platform arm. The findings indicate a bounded deployment account,
not universal retrieval superiority.

## 1 Introduction  [source: n1_intro.tex]
\section{Introduction}
\label{sec:intro}

Enterprises record regulations, failure analyses and operational lessons in
unstructured documents. A document collection becomes a knowledge base only
when three things hold: its documents are parsed and admitted reliably, they
are organized so that the right material can be found, and the system can
answer a question with a citation whose source is traceable. Answering a
question such as \emph{why did edge delamination appear in a photovoltaic
inspection?} requires the report that records the decision, the evidence
inside it and an accurate pointer to both. Retrieval-augmented generation
(RAG) addresses discovery by embedding queries and passages in a shared vector
space \cite{rag-lewis,dpr}; agentic systems extend this process by letting a
language model call retrieval tools \cite{mcp,singh-agentic-rag}. Yet semantic
similarity measures topical relatedness, not whether a passage contains
evidence for the requested claim \cite{siren,gao-ragsurvey}.

The relevant capabilities are usually treated separately. Retrieval asks
whether a relevant passage enters a ranked list. Knowledge management governs
how documents are organized and maintained. Document AI recovers text, tables
and formulas from complex layouts \cite{mineru}. In operational systems, these
operations form one dependency chain: parsing errors affect indexing, placement
limits what retrieval can see, and ranking alone cannot establish whether a
candidate supports an answer. A knowledge-base management system has to own
this chain, yet no single stage in common deployments owns the property the
user actually needs---that the sentence being cited is supported by the
document being cited.

This paper presents QDCVR (Query-Driven Content-Verified Retrieval), a
self-hosted knowledge-base management system that treats content as the
shared object across acquisition, organization and question answering. It
organizes the workflow around three design contracts:

\begin{enumerate}
\item \emph{Content informs placement.} An ingest agent uses the parsed body
to choose a library and derive descriptions or tags; server-side checks
validate storage state and consistency, not semantic routing accuracy.
\item \emph{Content informs admission.} When the retrieval workflow invokes
the server-side Laya tool, it fetches and scores candidate segments and returns
survivors with provenance; the score is an admission signal, not truth.
\item \emph{Absence is reported.} The answer workflow instructs the agent to
report the searched scope when a completed evidence review finds no support.
Tool failures and incomplete searches are execution failures, not evidence of
semantic absence.
\end{enumerate}

The platform integrates document parsing, content-informed
organization, lifecycle management, operational experiences, multi-lane
retrieval and a Model Context Protocol (MCP) server with 95 registered tools
\cite{mcp}. It runs locally and exposes retrieval functions to several agent
harnesses. Untested functions are identified rather than inferred from their
implementation.

\noindent\textbf{Contributions.}
\begin{enumerate}
\item A self-hosted knowledge-base management system that links quality-gated
acquisition, content-informed placement, three-source consistency and lifecycle
operations, with an invoked server-side evidence gate on the query path. The
management layer is described function by function, from parse admission to
lifecycle audits (Sections~\ref{sec:system}--\ref{sec:implementation}).
\item An answer-level evaluation over ten questions crossed with three
retrieval interfaces in two 30-cell grids (original and common-substrate),
reported per question: gold-identifier
presence, strict and alias-aware keyword coverage, recognized citation markers,
and abstention on verified-absent questions (Section~\ref{sec:e5},
Table~\ref{tab:e5-answers}).
\item A same-pool diagnostic that separates verifier \emph{ordering} from
verifier \emph{filtering}. Ordering candidates by the verifier score lowers
Hit@5 from 0.94 to 0.44, while retaining fusion order among recorded survivors
restores 0.94; all 191 recorded scores exceed the configured threshold, so the
loss is attributable to the induced ordering, not to filtering. A verifier
score that survives an admission filter is therefore not thereby usable as a
ranker (Sections~\ref{sec:lanes} and~\ref{sec:e4}--\ref{sec:e6}).
\end{enumerate}

A CIKM~2026 demonstration introduced the organization and retrieval layers
\cite{qdcvr-demo}. The journal extension adds acquisition and lifecycle
measurements, the operational-knowledge case study, and the verifier-placement
and transport-failure analyses. The architecture and retrieval interface build
on the demo; the contribution claimed here is the additional evidence and
failure analysis, not a wholly new system.

\subsection{Research questions and reading guide}
\label{sec:rq}

Five questions structure the design-to-evidence sequence, ordered by the
weight of the answer rather than by the pipeline: how the management layer
behaves on demonstration and public collections, covering parsing, admission, placement and
lifecycle (RQ1); what answer quality the end-to-end workflow reaches on a fixed
question set, measured per question and per interface (RQ2); how the tested
retrieval configurations compare on document recall and evidence markers
(RQ3); whether a verifier score should order candidates or only filter them
(RQ4); and what abstention, cost and execution-reliability observations arise
in end-to-end trials (RQ5).

Section~\ref{sec:related} positions the work; Sections~\ref{sec:system}--
\ref{sec:organization} describe the architecture and management functions;
Section~\ref{sec:lanes} specifies retrieval and verification;
Section~\ref{sec:implementation} covers deployment and enforcement; and
Section~\ref{sec:eval} evaluates the system, followed by implications,
limitations and conclusions in
Sections~\ref{sec:discussion}--\ref{sec:conclusion}.

## 2 Related work  [source: n2_related.tex]
\section{Related work}
\label{sec:related}

\subsection{Knowledge management and document acquisition}
Public knowledge bases organize facts under explicit ontologies
\citep{auer-dbpedia-kb-2007,hoffart-yago2-kb-2013}, whereas enterprise content
management emphasizes governance over organizational documents
\citep{paivarinta-ecm-2005,tyrvaainen-ecm-2006}. Research on organizational
knowledge explains how tacit experience becomes shareable
\citep{nonaka-seci-1994,nonaka-seci-ba-2000}; adjacent work studies metadata
quality, tagging, human review and auditability
\citep{park-metadata-quality-2009,golder-tagging-2006,mosqueira-rey-hitl-2022,barredo-arrieta-xai-2020}. These strands motivate reliable placement
and governance, but do not by themselves connect those controls to evidence-
checked answers. Document-AI methods, including layout-aware analysis and
MinerU, recover text and structure from complex documents
\citep{zhong-publaynet-layout-2019,huang-layoutlmv3-docai-2022,mineru}. Near-
duplicate detection and provenance provide complementary safeguards during
ingestion \citep{manku-near-dup-2007,missier-prov-2013,cheney-provenance-2009}.
QDCVR treats acquisition quality and traceable indexing as prerequisites for
reliable retrieval rather than as preprocessing assumptions.

\subsection{Retrieval, organization and agentic search}
RAG grounds generated responses in retrieved passages \citep{rag-lewis}; dense
retrievers learn shared query--passage representations \citep{dpr}, while BM25
remains a strong lexical baseline \citep{bm25}. Hybrid retrieval combines
sparse and dense signals, including reciprocal-rank fusion
\citep{rrf-cormack}; embedding models such as BGE-M3 support multilingual and
multi-granularity search \citep{bge-m3}. Graph-based systems organize and
retrieve structured relationships: GraphRAG adds entity-relation graphs and
community summaries \citep{graphrag}, LightRAG uses dual-level retrieval
\citep{lightrag}, and RAPTOR builds hierarchical document representations
\citep{raptor}. QDCVR uses a narrower document--library--tag graph for
navigation and candidate expansion; the graph does not establish answer
evidence on its own.

Tool-using agents extend retrieval through iterative interaction
\citep{react-yao,toolformer}. MCP standardizes access to tool servers
\citep{mcp}, while Modular RAG and agentic-retrieval surveys describe
reconfigurable retrieval pipelines and their efficiency challenges
\citep{modular-rag,singh-agentic-rag}. DeepRead demonstrates structure-aware
navigation for agentic search \citep{deepread}; QDCVR similarly exposes a
catalog-first librarian lane, alongside dense and hybrid alternatives, under
explicit call and tool policies.

\subsection{Verification, correction and abstention}
Self-RAG and CRAG integrate evidence assessment or retrieval correction into
generation \citep{selfrag,crag}; FLARE triggers retrieval during generation
\citep{flare}. Other work studies selective prediction under domain shift,
ontology-grounded retrieval and citation verification
\citep{kamath,cyberbot,liu-verifiability,gao-citations}. QDCVR externalizes
verification as a reusable server-side operation: the gate fetches document
text, judges evidence and returns provenance to the answer layer. This design
makes the verifier inspectable, but not infallible.

The LLM-as-a-judge literature documents preference bias, imperfect agreement,
listwise instability and self-preference \citep{zheng-llmjudge,sun-urara,panickssery-selfpref}; verifier gaming is an additional concern
\citep{lightman-verify}. These findings motivate separating evidence
verification from rank ordering and testing abstention at the answer layer.

\subsection{Research gap}
\label{sec:gap}

Table~\ref{tab:positioning} compares representative strands rather than every
system in the literature. Prior work already studies selective question
answering, citation verifiability and retrieval correction; the distinction
here is not that abstention or evidence checks are absent from prior research.
The gap this study addresses is one of integration and of role separation
rather than of missing capabilities: QDCVR examines how acquisition checks,
content-informed placement, retrieval and answer-time evidence inspection
interact in one knowledge-base workflow, reports where implementation
and transport boundaries constrain that workflow, and measures separately the
two roles a verifier can play. The table therefore motivates an
integration question, not a universal claim that earlier systems lack reusable
verification or inspectable evidence.

The study treats three design commitments as questions to test: whether
content-informed placement and lifecycle checks expose collection state;
whether a retrieved document should be re-ranked by a verifier or retain its
fusion order; and whether agent workflows can report absence while separating
completed negative searches from execution failures. Its contribution is a
knowledge-base management workflow that owns the chain from parse admission to
answer citation, a per-question account of the answers that chain produces,
and a same-pool diagnostic showing that ordering by the verifier score, not
threshold filtering, is where the measurable loss sits. It proposes no new
ranking algorithm and does not claim that the underlying retrieval problem is
solved.

\begin{table*}[t]
\centering
\small
\setlength{\tabcolsep}{4pt}
\renewcommand{\arraystretch}{1.18}
\caption{Positioning. Each strand addresses part of the path from stored
document to answer. QDCVR studies a knowledge-base workflow combining content-informed
acquisition and placement, server-side checks when invoked, and answer-layer
reporting; the evaluation measures selected components and boundaries in
Section~\ref{sec:eval}.}
\label{tab:positioning}
\begin{tabular}{@{}>{\raggedright\arraybackslash}p{0.145\textwidth}>{\raggedright\arraybackslash}p{0.285\textwidth}>{\raggedright\arraybackslash}p{0.24\textwidth}>{\raggedright\arraybackslash}p{0.24\textwidth}@{}}
\toprule
Strand & Representative work & What it optimizes & What it leaves to the deployment\\
\midrule
Knowledge management & Public knowledge bases \citep{auer-dbpedia-kb-2007,hoffart-yago2-kb-2013}; enterprise content management \citep{paivarinta-ecm-2005,tyrvaainen-ecm-2006} & An explicit ontology, or governance over a curated collection & Whether an answer drawn from that collection is supported by the text it cites\\
Document AI & Layout-aware extraction \citep{zhong-publaynet-layout-2019,huang-layoutlmv3-docai-2022}; MinerU \citep{mineru} & Recovery of text, tables and formulas from difficult layouts & Whether what was recovered is complete enough to index, and where it is then stored\\
Retrieval & Dense \citep{dpr}, lexical \citep{bm25} and hybrid ranking \citep{rrf-cormack,bge-m3} & Rank quality over a corpus that is assumed indexed & Whether a top-ranked candidate contains evidence for the claim it is used to support\\
Graph-structured organization & GraphRAG \citep{graphrag}, LightRAG \citep{lightrag}, RAPTOR \citep{raptor} & Multi-hop and hierarchical relationships between documents & Evidentiary status: a graph edge is a navigation fact, not evidence\\
Self-reflective generation & Self-RAG \citep{selfrag}, CRAG \citep{crag}, FLARE \citep{flare}; judge-based verification \citep{zheng-llmjudge,lightman-verify} & Evidence assessment or retrieval correction in generation workflows & How verification and abstention interact with knowledge-base acquisition and organization in a knowledge-base workflow\\
Agentic tool use & ReAct \citep{react-yao}, MCP \citep{mcp}, DeepRead \citep{deepread} & Access to retrieval tools behind a stable interface & Whether configured retrieval budgets and failure states are exposed and checked in a particular deployment\\
\midrule
QDCVR (this work) & Sections~\ref{sec:system}--\ref{sec:lanes} & An integration of content-informed placement, indexed-state checks, an invoked server-side evidence gate and agent answer reporting & Claims beyond the measured corpora and configurations, bounded in Section~\ref{sec:threats}\\
\bottomrule
\end{tabular}
\end{table*}

## 3 System overview and design principles  [source: n3_overview.tex]
\section{System overview and design principles}
\label{sec:system}

QDCVR (v2.3) is a self-hosted knowledge-base management system for converting
heterogeneous documents into searchable, governable collections. A Python
parsing service, a TypeScript web application and an MCP tool server share
local storage and retrieval engines \cite{mcp}. The design follows from the
dependency chain of Section~\ref{sec:intro}. Content decides where a document
is filed and whether a candidate is admitted; state is kept auditable through
three mutually checkable sources, namely the document files, the tree registry
and the per-library metadata; and completion is established by a retrieval
probe rather than by a success message. Each decision sits at the layer that
can enforce it, and the evaluation measures it at that layer.

\subsection{Design principles: three contracts and enforcement layers}
\label{sec:req}
\label{sec:principles}

The three contracts are hypotheses about where content should govern the
workflow, implemented at different layers: some checks are mechanically
enforced by server-side tools, whereas placement and answer abstention also
depend on the calling workflow, which is where the hypotheses are weakest. We
therefore distinguish the mechanism that executes each step from the audit or
evaluation that checks its outcome, and Section~\ref{sec:eval} reports the
evidence level each check reaches.

\begin{description}
\item[Content informs placement.] \emph{Mechanism:} an ingest agent reads the
parsed content together with the library catalogue and selects a parent or
sub-library; storage APIs validate identifiers and required fields, not the
semantic correctness of that choice. \emph{Check:} descriptions and tags are
re-read against the body, and three-source consistency is checked after
lifecycle operations (Sections~\ref{sec:acquisition} and~\ref{sec:organization}).
\item[Content informs admission.] \emph{Mechanism:} when invoked, the server-side
Laya judging tool fetches or accepts document text, scores its segments, and
returns survivors with provenance; lane workflows are instructed to treat rank
as advisory. \emph{Check:} failed fetches or scores are not admitted, and the
ablation in Section~\ref{sec:e8} tests a bounded frozen-pool contrast
(Sections~\ref{sec:lanes} and~\ref{sec:gate}).
\item[Absence is reported.] \emph{Mechanism:} the answer workflow instructs the
agent to report not-found when completed retrieval provides no supporting
evidence and to state its searched scope. This is not a server-side semantic
classifier. \emph{Check:} out-of-corpus probes and unanswerable questions were
observed as abstentions in the reported trials (Section~\ref{sec:e5}).
\end{description}

Four deployment requirements constrain the contracts: expose parsing failures;
keep document files and library records consistent; require content evidence
before a retrieved item is used to support an answer; and remain operable on
one workstation. Server-side checks cover parse, metadata and index
post-conditions, the invoked evidence gate, and endpoint tool policies. They do
not mechanically establish semantic placement accuracy or answer faithfulness.
Read as hypotheses, C1 is supported by these mechanical checks together with
one membership measurement that does not use the ingest naming convention
(Section~\ref{sec:e1}); C2's filtering role was not exercised on the
industrial corpus, and its ordering role failed there
(Sections~\ref{sec:e4}--\ref{sec:e8}); C3 is answer-layer behavior observed in
trials, not a server-side classifier (Section~\ref{sec:e5}).

\subsection{Architecture and subsystems}
\label{sec:architecture}

Fig.~\ref{fig:arch} shows the acquisition and query paths. Ingestion parses and
quality-checks documents; an agent uses the parsed content and library
catalogue to select a parent or sub-library; save and index operations then
update records and search indices. At query time, the chat endpoint supplies a
lane-specific tool policy, and the agent retrieves candidates and invokes the
gate before the answer layer returns cited evidence or not-found. The MCP
server exposes 95 registered tools. The three contracts of
Section~\ref{sec:principles} sit at different points along this path:
placement during ingestion, admission at the gate, the abstention report in
the answer layer.

\begin{figure*}[t]
\centering
\includegraphics[width=\textwidth]{fig1_architecture}
\caption{QDCVR architecture and three design commitments. During ingestion, an
agent uses document content and the catalogue to choose a library; server-side
storage and consistency checks verify structural state (C1). At query time,
the endpoint applies a tool policy and the agent may invoke the server-side
Laya evidence tool, which returns scored survivors with provenance (C2). The
answer workflow is instructed to report not-found after a completed search
finds no support (C3). These commitments span distinct enforcement layers;
the evaluation measures selected mechanisms and observed outcomes.}
\label{fig:arch}
\end{figure*}

The management path covers acquisition (Section~\ref{sec:acquisition}),
content-routed organization and lifecycle checks
(Section~\ref{sec:organization}), and the tool and runtime layer
(Section~\ref{sec:implementation}). The chat
endpoint defines pinned-search and all-library librarian policies. Hybrid is
a composed retrieval configuration, not a third built-in server policy; it
combines vector and catalog calls under an explicit directive. The document
graph supports navigation, not evidence, and the experience store uses the
same catalog and gate but was not evaluated at scale.

Five function groups cover acquisition, organization, lifecycle, query and
operational experience. Each is paired with a server-side check rather than an
operator convention, and Table~\ref{tab:functions} maps every group to its
checks and to the evaluation that exercises it.

\begin{table*}[t]
\centering
\small
\setlength{\tabcolsep}{4pt}
\caption{Management functions, the server-side check attached to each, and the
evaluation that exercises it. The check column states what the platform
verifies mechanically; semantic choices such as where a document belongs
remain workflow decisions and are measured, not enforced.}
\label{tab:functions}
\begin{tabular}{@{}>{\raggedright\arraybackslash}p{0.13\textwidth}>{\raggedright\arraybackslash}p{0.37\textwidth}>{\raggedright\arraybackslash}p{0.30\textwidth}>{\raggedright\arraybackslash}p{0.11\textwidth}@{}}
\toprule
Group & Operations & Server-side check & Evidence\\
\midrule
Acquisition & submit, parse (MinerU), quality gate, near-duplicate flag, structural split, store, index & task state, OCR/binary/heading checks, content fingerprint, split invariance, post-index probe & E1\\
Organization & create library or sub-library, content-informed placement, descriptions and tags, duplicate review & identifier and required-field validation, description/tag re-read against the body, three-source consistency & E1--E2\\
Lifecycle & move, rename, delete, force re-index, graph build & post-operation audit of registry, library metadata and vector chunks & E2\\
Query & lane selection, vector, keyword, catalog and two-stage search, gate invocation & tool allow/deny lists, timeouts and turn limits, provenance on returned survivors & E4--E8\\
Experience & extract, approve, tier, search & approval state and credibility tier before display & E3\\
\bottomrule
\end{tabular}
\end{table*}

\subsection{Data model and object lifecycle}
\label{sec:datamodel}
\label{sec:lifecycle}

Documents are stored as Markdown with extracted images. Three sources describe
library state: document files, the \texttt{.tree-fs.json} registry and each
library's \texttt{.knowledge-base.yml}. Ingestion proceeds through raw,
parsed, stored and indexed states, and is complete only after a content-derived
probe retrieves the document. Indexing is explicit and asynchronous; task
identifiers support polling, while post-operation audits detect stale indices
or disagreement among the three sources.

## 4 Knowledge acquisition  [source: n4_acquisition.tex]
\section{Knowledge acquisition: parsing, ingestion and index verification}
\label{sec:acquisition}

Acquisition determines what later retrieval can support, and it is where
content comes to govern placement. QDCVR submits PDFs,
Office files and scans to MinerU through an asynchronous parsing service
\citep{mineru}; parse tasks return identifiers that callers poll to completion,
and OCR, layout and formula-extraction failures remain visible rather than
being stored as empty documents.

An ingest follows a fixed sequence of observable stages: submit, parse, quality
verdict, duplicate decision, split, storage, indexing and a retrieval probe.
Each stage leaves a record that the next stage reads and the audit can revisit:
a parse task identifier, a quality report, a content fingerprint, a split
manifest, a storage record and a probe result. A document counts as ingested
only when a content-derived query retrieves it; an HTTP success from the save
call is not treated as success. The same path accepts scanned pages, Office
files and plain text, and a failure at one stage never silently promotes the
document to the next.

\subsection{Quality gates and ingest lifecycle}

Before storage, duplicate detection checks exact content fingerprints and
flags near-duplicates for review at a 0.90 similarity threshold. After parsing,
a quality gate checks extracted text for OCR noise, binary residue, bodyless
headings, whitespace collapse and language mismatch. The parsed result is saved
with task provenance but is not indexed by that save; direct-text documents use
the create path, which triggers background indexing. The ingestion agent
selects a library whose scope matches the parsed content's subject, not its
filename.

Documents exceeding the 30,000-character reading-context ceiling are split
at structural boundaries. The splitter targets 0.85 utilization and avoids
cuts that would divide atomic units such as equations or tables. Descriptions
and tags are derived from the body and checked against it; mismatches require
metadata correction, not document rewriting. Indexing populates vector, lexical
and graph representations separately; post-index verification checks for a
non-empty vector collection, expected chunk identifiers and graph/document
state. Ingestion also runs content-derived probes before marking an ingest
complete; API success alone is not proof of retrievability.

\subsection{Acquisition evidence and accounting limits}

The 100-paper campaign produced 322 stored parts in five libraries.
Its reconciliation is incomplete: the state file records 91 submitted names,
79 papers were retrievable at evaluation and 21 never became retrievable, and
the surviving artifacts do not enumerate attempts and failures per paper, so
the missing 21 cannot be attributed to parsing alone. Formula-dense scans and
a recovered batch-process crash were observed; neither establishes the cause
for every missing paper.

A separate cross-lingual test processed 400 Wikipedia pages per language:
ingestion success 1.0 in both rounds, membership accuracy 0.875 for English
against 1.0 for Chinese and Japanese, with the per-language storage and
self-retrieval results in Section~\ref{sec:e1}. These measurements
characterize ingestion and storage, not answer quality.

## 5 Knowledge organization and lifecycle management  [source: n5_organization.tex]
\section{Knowledge organization and lifecycle management}
\label{sec:organization}

Organization determines which candidates retrieval can see and whether the
stored state remains trustworthy. QDCVR places documents by content rather
than filename; split parts inherit the source assignment, and the catalog
exposes library and document descriptions before full bodies are read.

\subsection{Metadata, tags and duplicate review}
\label{sec:org-placement}
\label{sec:org-registries}
\label{sec:org-tags}
\label{sec:org-dedup}

Integrity checks compare the document files, the \texttt{.tree-fs.json} tree
and each library's \texttt{.knowledge-base.yml} for document existence, path
and index metadata. Tags derive from content and are checked against it.
Duplicate detection reports candidate pairs for review; deletion is not
automatic because adjacent parts may be similar while containing distinct
source sections.

The layer's operations are library and sub-library creation, placement,
description and tag edits, move, rename, delete, duplicate review and forced
re-index. Each writes the document files and both registries, so the audit can
compare the three sources afterwards. The catalog lists libraries, their
descriptions, sub-library containers and document descriptions, which lets a
reader or an agent decide where to look before opening a body. Placement is
the one operation whose semantic choice is not mechanical: the ingest agent
selects the library from the parsed content, and the platform checks the
consequences rather than the choice.

Sub-libraries are first-class tree nodes with their own descriptions and
indices. Index writes resolve the document's owning library; searching a parent
library traverses its descendants' collections. This supports hierarchical
organization without implying that child vectors are stored in the parent's
collection.

\subsection{Lifecycle operations, graph and operational knowledge}
\label{sec:org-lifecycle}
\label{sec:org-graph}
\label{sec:org-experience}

Re-indexing is explicit: a rename can leave stale vector chunks until a forced
re-index, so operation completion requires checking the resulting index, not
only the metadata record. The document graph supports navigation and candidate
expansion, not evidence. Operational lessons are stored as retrievable
documents with credibility tiers, but the available measurements are case
examples rather than a scale evaluation of distillation, approval or
credibility decay.

\subsection{Organization contract}
\label{sec:org-integrity}
\label{sec:org-summary}

The evaluation checks three-source consistency, content-derived descriptions,
regression probes and lifecycle outcomes (Section~\ref{sec:e2}). The contract
makes stale or inconsistent state detectable; it does not prevent every
failure by construction. Merge and split remain outside the controlled test
scope, so performance claims must be read within the corpus sizes reported in
the Evaluation section.

## 6 Content-verified retrieval  [source: n6_retrieval.tex]
\section{Content-verified retrieval}
\label{sec:retrieval}
\label{sec:lanes}

Retrieval is the query module of the management system: it reads the
libraries, catalog and indices that acquisition and organization maintain, and
it returns either evidence for an answer or an explicit absence report.
Search, Librarian and Hybrid lanes use different retrieval affordances but
share a server-side content-verification tool when the calling workflow invokes
it. The tool fetches referenced document text, segments it and applies a local,
query-conditioned Laya verdict on a 0--1 scale---the model card's typed
binary-output field (\texttt{noul}), the calibrated probability that a
segment answers the posed evidence question; segments meeting the configured
threshold (0.5 by default) are returned as survivors with provenance. A scored segment below the
threshold is not admitted, but tool or fetch failures are reported separately
and a partially completed call may still return successfully scored survivors.

A lane invocation runs the same five steps and differs in the tools it calls.
\begin{enumerate}
\item \emph{Rewrite.} The agent decomposes the question into a subject, an
attribute and any constraint (Lane A), or classifies it as literal or
enumerative for the scanner and semantic for the judge (Lane B).
\item \emph{Gather.} The lane collects candidates: dense top-30 above cosine
0.35 inside a pinned library (A); catalog pages followed by the scanner or the
judge (B); one server call that merges vector top-30 with catalog results (C).
\item \emph{Merge and cap.} Candidates are deduplicated by library and
document, ordered with documents returned by both sources first, and capped at
twelve candidates.
\item \emph{Judge.} The gate fetches each candidate's text, splits it into
segments and scores every segment against the posed evidence question. Scored
survivors carry provenance; a fetch or tool failure is reported separately from
a low score.
\item \emph{Cut and read.} The answer step reads the first five survivors in
full. The shipped configuration orders them by verdict score; the filter replay
of Section~\ref{sec:e4} keeps the fusion order instead, and the relative margin
is evaluated there as a diagnostic rather than as a configured control.
\end{enumerate}
Exhausting a lane's call budget is intended to produce a scope and blind-spot
report. The endpoint enforces timeouts and turn limits; the per-lane budgets
are workflow instructions, not server quotas.

\subsection{Gate contract and retrieval lanes}
\label{sec:trace}
\label{sec:gate}
\label{sec:gate-primitive}
\label{sec:twostage}

The chat endpoint supplies two built-in policies. Lane A uses a wide dense search
(top 30, cosine threshold 0.35) within a pinned library and may escalate once
to the catalog ladder when no verified evidence survives. Lane B follows catalog descriptions, then
uses a deterministic scanner for literal or enumeration questions and the judge
for semantic questions. Endpoint-level timeouts and turn limits bound execution;
the lane call budgets and six-reference batching below are workflow instructions,
not independent server-enforced quotas. Exhaustion is intended to produce a
scope and blind-spot report. Lane C is a composed configuration used in
evaluation, not a third built-in server policy: it appends a hybrid directive
to the chat prompt that can call vector and catalog tools, merge up to twelve
candidates, judge them in batches of six, and return up to five survivors with
bounded evidence. Table~\ref{tab:lanes} and Fig.~\ref{fig:lanes} summarize the
policies and answer workflow.

The gate is the local Laya evidence classifier \cite{laya}, exposed as
\path{kb_laya_judge}. In reference mode, the server fetches each document,
judges its segments and returns provenance with a bounded evidence pack. The
verdict controls admission, not truth; the verifier remains subject to
calibration and transport limitations.

\begin{table*}[t]
\centering
\small
\setlength{\tabcolsep}{5pt}
\caption{Retrieval lanes as operating policies over a shared candidate and verification tool layer. Budgets describe the configured interface; latency and effectiveness are evaluated separately in Section~\ref{sec:eval}.}
\label{tab:lanes}
\begin{tabular}{@{}llll@{}}
\toprule
Lane & Retrieval affordance & Budget type & Intended terminal report \\
\midrule
Search & Pinned-library dense search & Endpoint turn limit & Answer or report not-found \\
Librarian & Catalog navigation and query-shaped scan/judging & Workflow call budget & Scope and blind spots \\
Hybrid & Agent-composed vector and catalog calls & Evaluation-specific candidate cap & Survivors for answer workflow \\
\bottomrule
\end{tabular}
\end{table*}

The two-stage tool builds a candidate pool with lexical search and optional
graph expansion, then applies dense ranking. It does not call the
content gate; a ranked chunk is not admissible evidence until verified, and a
similarity threshold is not an abstention mechanism. The 13 October catalog
incident showed that oversized tool returns can conceal documents before
reasoning begins. The tested repair adds a server-side character budget,
grouped views and pagination; its behavior is reported in the Evaluation
section.

\begin{figure*}[t]
\centering
\includegraphics[width=\textwidth]{fig2_lanes}
\caption{The three retrieval workflows can invoke the same content-verification
tool by different routes: a pinned wide dense search that may escalate once
to the catalog ladder when no survivors remain, a catalog ladder that selects a literal scanner or the judge,
and an agent-composed vector-and-catalog configuration capped at twelve
candidates in this evaluation. When invoked, the gate reads fetched text and
returns scored survivors with provenance; zero survivors or an exhausted
workflow budget is intended to elicit an explicit not-found report. Endpoint
tool and turn controls are server-side; the lane-level call sequence and
budgets are workflow instructions.}
\label{fig:lanes}
\end{figure*}

\subsection{Honest abstention}
A candidate list may contain high-similarity but unsupported documents. The
answer workflow instructs the agent to report not-found when its completed
evidence review finds no support, including the searched scope and known blind
spots, rather than falling back to parametric knowledge. This behavior was
observed in the reported trials; it is not a server-side semantic-classifier
guarantee. Timeouts, unavailable tools and incomplete searches are execution
failures, not evidence of semantic absence (Section~\ref{sec:eval}).

## 7 Agent interface and implementation  [source: n7_implementation.tex]
\section{Agent interface and implementation}
\label{sec:implementation}
\label{sec:impl}

\subsection{MCP tools and lane policy}
\label{sec:impl-tools}

The platform exposes 95 MCP tools across twelve functional groups, including
parsing, search, content verification, indexing, tags, the document graph and
operational experience, plus persona distillation, which shares the same storage,
catalog and gate but lies outside the scope of this evaluation. Retrieval lanes
receive read-oriented tool sets; administrative writes remain separate, and
long-running parse, re-index and graph operations return pollable task
identifiers.

The chat endpoint adapts multiple agent harnesses to the lane interface. The
server selects a harness and permission mode, enforces configured tool
allow/deny lists, applies endpoint timeouts and turn limits, and may register an
asynchronous task. Lane-specific retrieval sequences and call budgets are
workflow instructions; the endpoint does not enforce a separate per-lane call
quota.

\subsection{Runtime and deployment}
\label{sec:impl-runtime}

The backend uses Python 3.12 and FastAPI. ChromaDB stores cosine-space HNSW
collections with normalized BGE-M3 embeddings (1024 dimensions)
\cite{chroma,hnsw,bge-m3}; Neo4j stores the document graph \cite{neo4j};
BM25 supports lexical search \cite{bm25}; MinerU provides parsing and OCR
\cite{mineru}. The Laya verifier runs locally as a serialized worker.

The evaluation environment is one self-hosted Windows workstation with an
RTX 5060 (8 GB) used for embeddings and judging. Local execution reduces
external service dependencies but does not establish privacy, access-control or
multi-host deployment guarantees. The implementation and scripts are available
at \url{https://github.com/kingdol666/rag-knowledge}; experimental corpora
remain subject to their data-use constraints.

## 8 Evaluation (setup, E1-E2)  [source: n8a_eval.tex]
\section{Evaluation}
\label{sec:eval}

We evaluate the system on three corpora differing in origin, language
and scale, and we separate two questions: whether the management layer keeps
its collections in a usable state, and what the answers built on those
collections are worth. Sections~\ref{sec:e1}--\ref{sec:e3} cover the
management layer: acquisition and parsing, organization and three-source
consistency, and the operational-experience store. Sections
\ref{sec:e4}--\ref{sec:e8} cover the query path: retrieval quality
(Section~\ref{sec:e4}), answer quality per question and abstention
(Section~\ref{sec:e5}, the paper's end-to-end evidence), a deployment-layer
replication through the public API (Section~\ref{sec:sysarms}), verifier
failure (Section~\ref{sec:e6}), non-functional behavior (Section~\ref{sec:e7})
and the gate and search-scope ablations (Section~\ref{sec:e8}). Numbers are
reported against the corpus that produced them, never merged; the campaign
inventory and per-question tool-layer results are supplementary material.

\subsection{Experimental setup}
\label{sec:eval-setup}

\textbf{Corpora.} (i)~\emph{Industrial demonstration corpus}: five libraries
hold 42 documents prepared as a demonstration instance, not customer data; one
library contains twenty near-duplicate
equipment-telemetry reports sharing prefixes, vocabulary and structure---a
deliberate stressor for near-duplicate detection and confuser
density~\cite{manku-near-dup-2007}; sixteen gold questions and four
out-of-corpus probes ran against it. (ii)~\emph{arXiv corpus}: 100 submitted
papers spanning about 25 domains, 79 retrievable at evaluation time and routed
by content into five domain libraries holding 322 stored parts; ten gold
questions (BQ01--BQ10) target papers referenced by those papers, keyed by arXiv
identifier, and the running instance held 19 libraries. (iii)~\emph{Cross-lingual
ingestion corpus}: 400 Wikipedia pages per language (English, Chinese,
Japanese), 40 extractive cloze queries each with verbatim in-page answers;
ingestion only, no retrieval-quality numbers reported.

\textbf{Questions and gold annotations.} The sixteen industrial questions were
authored, not sampled from logs; each identifies one or two gold documents by
a unique filename fragment and one to three fact markers. Q16 includes a token
also present in its gold filename, so a filename-ranking retriever could match
it without reading content; we retain this limitation and report a sensitivity
check in Section~\ref{sec:e4}. The arXiv answer grader
checks gold-ID presence in the answer or trace plus a word-boundary keyword
rule that counts a cell as covered when it matches at least $\lceil 3n/5\rceil$
of the $n$ annotated terms; it does not assess semantic support. Citation
markers are counted separately by a deterministic pattern and do not assess
source resolution or claim-to-source entailment.

\textbf{Metric families.} Retrieval uses Hit@5, Recall@5 and MRR@5, following
passage-ranking conventions~\cite{craswell-msmarco-2021}; Hit@5 and Recall@5
are document-level over the top five returned documents, and MRR@5 is $1/r$
for the first gold at rank $r\le 5$ and zero otherwise.
nDCG@5~\cite{jarvelin-cumulated-gain-2002} was computed only inside one
exploratory arm we do not report. The end-to-end "gold-hit" measure checks
whether the answer or recorded retrieval trace contains the gold identifier;
keyword coverage is a deterministic lexical proxy. Citation counts record
whether the answer contains a part, section or table marker under the stated
pattern. These checks support traceability and marker-presence claims, not
semantic faithfulness or claim-to-source support, for which model-based
measures such as RAGAS~\cite{es-ragas-2024} or ARES~\cite{saad-falcon-ares-2024}
are designed. The third metric family covers wall-clock time, agent turns,
tool calls, cost and whether refusals were appropriate.

\textbf{Controls.} The deterministic retrieval lanes were re-run and compared
field by field, latency excluded; the 27-cell stability suite
(Section~\ref{sec:e7}) and the eighteen-arm honesty battery
(Section~\ref{sec:sysarms}) carry repeats, whereas the 30-cell answer grid of
Section~\ref{sec:e5} is a single run per arm on one model, recorded in the run
timeline as claude-opus-4-8[1m] with seed~0 and harness prompt v4-neutral, and
is reported as such, as is its controlled replication. The fixed retry
policy (one retry for
an empty zero-turn response or transient gateway timeout) fired twice,
succeeding both times. Before measurement we repaired two corpus-integrity
faults through the platform's own operations: one document missing from its
vector collection was re-indexed, and one library whose collection had been
lost was rebuilt, the same failure class that Section~\ref{sec:e2} measures. The tool-layer
retrieval lanes, grading rule, audits, duplicate adjudication and cross-lingual
ingestion pipeline are deterministic; agent lanes and text-derived results are
not.

\begin{table*}[t]
\centering
\footnotesize
\setlength{\tabcolsep}{4pt}
\caption{Functional checks on the management layer. Each row names the
function, the test and its scale, the observed outcome, and the subsection
that reports it. The numbers are those of the cited campaigns; none is
re-estimated. A passing check means the stated property was observed on the
stated scale, not that the function is exhaustively verified.}
\label{tab:kb-checks}
\begin{tabular}{@{}>{\raggedright\arraybackslash}p{0.115\textwidth}>{\raggedright\arraybackslash}p{0.265\textwidth}>{\raggedright\arraybackslash}p{0.39\textwidth}>{\raggedright\arraybackslash}p{0.10\textwidth}@{}}
\toprule
Function & Test and scale & Observed outcome & Where\\
\midrule
Parse and ingest & 100-paper campaign; nine checks per paper & nine checks per paper, all pass; 91 names in the state file, 79 retrievable at evaluation, 21 unattributable (twelve recorded plus nine unrecorded) & E1\\
Parse quality & 50-paper, 26-domain campaign & 50/50 parsed and verified, all probes ok; 202 tags; 41 tag flags negative without blocking ingestion & E1\\
Structural split & 50 papers at the 30{,}000-character tier & 165 documents (9 whole, 156 parts) in 2{,}672\,s; storage 50/50; descriptions and tags 165/165 & E1\\
Near-duplicate review & 322-document corpus, 0.90 threshold & 35 candidate groups (0.90--0.975), zero true duplicates, nothing deleted & E2\\
Content placement & 100 papers into five libraries; 400 pages per language & 322 stored parts; membership 0.875 (en) and 1.0 (zh, ja) & E1--E2\\
Three-source consistency & Full corpus and 33-document spot check & 322/322 content and 33/33 storage; one rename defect (18 vs 9 chunks) until force re-index & E2\\
Lifecycle operations & 16 scenarios on two disposable libraries & create, move, delete and forced re-index pass; two failures (task status, update check) & E2\\
Sub-library hierarchy & Three-level disposable fixture & create, parent-to-child move, listing, reading and judging all pass & E2\\
Tags and graph & 316-tag registry; 658-node graph & 165 documents pass the tag check in 47.6\,s; four tag edges on one document move 4{,}675 to 4{,}679 & E2\\
Experience store & One small knowledge base; one end-to-end scenario & 13 candidate drafts; one lesson retrieved first at 0.711; approval path unexercised & E3\\
\bottomrule
\end{tabular}
\end{table*}

\subsection{E1: Acquisition and parsing}
\label{sec:e1}

The 100 submitted papers were parsed and content-routed into five domain
libraries, producing 322 stored parts after the 30{,}000-character split. The
submission funnel does not reconcile on its face: 91 names appear in the ingest
state file and 79 papers were retrievable at evaluation, so twelve recorded
papers never became retrievable, and nine submitted papers never entered the
state file. The 21 unretrievable papers are the sum of those twelve and nine,
and neither attempts against failed papers nor per-paper parse status is
recorded, so the 21 cannot be attributed to parsing alone
\cite{missier-prov-2013}. Reported failure modes are formula-dense scans and
one tool-layer crash during batch parsing, restarted from a checkpoint.
Table~\ref{tab:kb-checks} lists every functional check with its scale and
outcome.

The cross-lingual benchmark ran twice over 400 pages per language and
reproduced round~1 bit-for-bit, with ingestion success 1.0; storage
completeness, self-retrieval Hit@1 and the membership figures are in
Table~S2. Its English membership accuracy of 0.875 is an organization
defect---the page stored in the wrong library roughly one time in eight---not
a parsing defect. Membership is scored against the benchmark's source category labels, not a
naming convention derived by the ingest agent, so it is the one
filename-independent placement measurement in this paper.

A second 50-paper, 26-domain campaign parsed and verified every paper, indexed
them in batch, reported all probes ok, and left 41 of 50 documents with a
negative tag flag even though verification passed, so tag-quality failures
never blocked ingestion.
One stage re-ran on inbox ordering, and more than 800 extracted images were
not uploaded. Descriptions and tags are checked against content before
storage~\cite{park-metadata-quality-2009}.


\subsection{E2: Organization, consistency, and management operations}
\label{sec:e2}


Organizational correctness is three-source consistency: disk files, the tree
index and per-library metadata must agree on document existence, location and
indexed content. Under that definition we found one real defect in a
disposable test library: after a rename the vector index kept the old name's
chunks---count 18 where 9 were expected, a duplicate search matching the
document against its own former path at 0.9738 similarity, a vector probe
returning every chunk twice at identical scores. Only an explicit force
re-index removed them, restoring the count to 9. The failure is invisible from
the metadata alone.

The reorganization campaign over the 322-document corpus passed its content
check on all 322 documents and its three-source consistency check on a
33-document sample, one tenth of the corpus; the duplicate review held no true
duplicate and deleted nothing. Sub-library splitting and hierarchy
creation ran on a disposable three-level fixture: creation with a parent
reference, a parent-to-sub-library move, and listing, reading and judging
through sub-library addresses all returned correct results. A parent catalog
lists its sub-libraries as container entries carrying their own descriptions,
the one-call view that ladder navigation reads.

Growing from 50 to 100 papers cost no retrieval quality: dense top-1 hits moved
from 48/50 to 49/50 and MRR from 0.98 to 1.00, recorded as a post hoc
held-within-5-pp band
$\pm$5\,pp. In the 16 lifecycle scenarios, create, move, delete and forced
re-index behaved as specified (Table~S5). Two failures remain: the task-status
tool reports \texttt{running} after \texttt{finished\_at} is written, and the
update check timed out after 30\,s while every other probe passed. Merge and
split were never exercised under controlled conditions, so we claim nothing
about them.

The tag registry held 316 tags; the tag-quality check passed 165
documents with zero failures in 47.6\,s, and orphan tags accumulate (test tags,
section titles), for which a dry-run detector exists. In one case test-library
tags leaked into the main registry, the failure mode vocabulary-based
organization is prone to~\cite{golder-tagging-2006}. The document graph is
navigation, never evidence: four tag edges on one document moved the edge count
from 4{,}675 to 4{,}679.

## 8 Evaluation (E3-E4)  [source: n8b_eval.tex]
%% n8b_eval.tex -- evaluation, middle part: E3 (operational knowledge and
%% automated distillation) and E4 (retrieval quality and the role of the
%% verdict). Compressed 2026-10-12. Labels owned here: sec:e3, sec:e4,
%% sec:eval-retrieval, tab:retrieval, tab:e4-modes, fig:retrieval,
%% fig:marginvariants.
\subsection{E3: Operational knowledge and automated distillation}
\label{sec:e3}

The experience store holds operational lessons as first-class retrievable
documents---addressed, indexed and searched as an ordinary document, with a
credibility tier deciding whether it may be shown at all
(Section~\ref{sec:org-experience}). Three case measurements exist: an
extraction campaign over one small knowledge base produced thirteen
candidate drafts (archived \path{experience_smoke.json} in the 2026-10-13
batch tarball; \texttt{extract\_candidates}~13, \texttt{drafts\_created}~13);
one end-to-end scenario was sedimented into one experience
(\texttt{exp-d6f4d47ae3d6}) that a later global experience search returned
first, at local similarity 0.711 (archived scenario A6 of the 2026-10-12
full-test campaign); and the draft-approval path was never exercised, because
the draft pool was empty (\texttt{count}~0) and \path{experience_draft_read}
and \path{experience_draft_approve} could not run; the heuristic extraction
path had run only in dry-run mode, returning a dump the quality gate would
reject. One scenario and thirteen candidates cannot support an effectiveness
claim; scheduled distillation, review and approval at scale, application
feedback and credibility decay went unexercised. What they show is narrower:
an operational lesson can travel the document path with its tier attached.

\subsection{E4: Retrieval quality and the role of the verdict}
\label{sec:e4}
\label{sec:eval-retrieval}

Nine configurations, defined here so the table reads on its own. Five were
measured through their own tool-layer entry points: \emph{Dense} via
\texttt{kb\_search\_vector} with BGE-M3 \cite{bge-m3}; \emph{Graph} via
\texttt{kb\_graph\_search}, a keyword match over node names, paths and tags in
the document graph; \emph{Two-stage} via
\texttt{kb\_search\_two\_stage} (Section~\ref{sec:twostage}); and the hybrid
rows via \texttt{kb\_hybrid\_search}, an earlier server-side single-call
composition of the vector, catalog and judging tools, with the gate off
(\emph{Fusion-only}) and on (\emph{QDCVR-Hybrid}). \emph{BM25} runs in process
over the fetched full texts (jieba tokenizer, $k_1=1.5$, $b=0.75$), and
\emph{RRF} fuses that ranking with the dense one at $k=60$
\cite{rrf-cormack}; neither is the platform's keyword tool, so the millisecond
latencies are in-process measurements rather than a server round trip. The
evaluated hybrid wrapper is no longer registered in the current tool layer,
whose hybrid lane is the composed chat configuration of
Section~\ref{sec:twostage}, so the negative ordering result below is bounded
to that retired wrapper. Two further rows are derived offline by replaying the
judged hybrid run's logged twelve-candidate pools and verdict scores:
\emph{Judge-as-filter} keeps survivors in fusion order and \emph{RRF-fuse}
fuses the fusion ranking with the judge-score ranking at $k=60$. All three
see the same candidates and scores, so the comparison is an attribution,
not a benchmark. Because every logged candidate survived the configured 0.5
threshold, the filter replay is identical to fusion order by construction and
does not test filtering.

\begin{table*}[t]
\centering
\small
\setlength{\tabcolsep}{3pt}
\caption{Tool-layer retrieval on the 42-document industrial demonstration corpus
(mean over 16 gold-annotated questions; top-5 document lists; latency per
call, warmed). The paraphrase column re-asks those sixteen questions in
different words (\protect\path{paper-kbs/experiments/results/exp6_paraphrase.json});
block~(b) repeats the Hit@5 measurement on a second corpus, the 79 retrievable
papers of the 100-paper arXiv ingestion, over ten questions.}
\label{tab:retrieval}
\resizebox{\textwidth}{!}{%
\footnotesize
\begin{tabular}{lcccccc}
\toprule
Method & Hit@5 & Recall@5 & MRR@5 & Paraphrase Hit@5 & Latency (mean) & Latency (median) \\
\midrule
BM25                  & 1.00 & 1.00 & 0.958 & 0.88 & 0.9\,ms    & 1\,ms \\
Dense (BGE-M3)        & 0.94 & 0.94 & 0.856 & 0.94 & 18\,ms     & 17\,ms \\
RRF (BM25$\|$Dense)   & 1.00 & 1.00 & 0.927 & 0.88 & 11\,ms     & 9\,ms \\
Graph (Neo4j)         & 0.56 & 0.53 & 0.562 & 0.56 & 68\,ms     & 68\,ms \\
Two-stage             & 1.00 & 0.97 & 0.927 & 0.94 & 77\,ms     & 40\,ms \\
Fusion-only           & 0.94 & 0.94 & 0.856 & 0.94 & 62\,ms     & 66\,ms \\
QDCVR-Hybrid          & 0.44 & 0.41 & 0.226 & 0.50 & 542\,ms    & 582\,ms \\
\midrule
\multicolumn{7}{l}{\emph{Derived (offline, same logged hybrid pools):}}\\
\quad Judge-as-filter$^{\dagger}$ & 0.94 & 0.94 & 0.856 & 0.94 & \multicolumn{2}{l}{$^{\dagger}$542\,ms / 582\,ms} \\
\quad RRF-fuse & 0.88 & 0.88 & 0.606 & 0.88 & \multicolumn{2}{l}{(same single call)} \\
\bottomrule
\end{tabular}}
\par\smallskip
\raggedright\small
$^{\dagger}$\,Derived rows replay the QDCVR-Hybrid run's own logged
12-candidate pools and judge scores, so they reuse that call's latency; the
judge executes once either way.

\par\smallskip
\resizebox{\textwidth}{!}{%
\begin{tabular}{@{}lcccccccc@{}}
\toprule
\multicolumn{9}{@{}l}{\textbf{(b)} Second corpus: 79 retrievable arXiv papers of the 100 submitted, ten questions}\\
\midrule
Configuration & BM25 & Dense & RRF & Graph & Two-stage & Fusion-only & QDCVR-Hybrid & Judge-as-filter \\
Hit@5 & 0.90 & 0.90 & 0.90 & 0.20 & 0.90 & 0.90 & 0.90 & 0.90 \\
\bottomrule
\end{tabular}}
\end{table*}

Table~\ref{tab:retrieval} compares the nine configurations on the sixteen
gold-annotated questions of the industrial demonstration corpus (42 documents;
\path{paper-kbs/experiments/results/exp1_retrieval.json},
\texttt{exp5\_judge\_filter.json}). The tool-layer arms retrieve and never
answer, so their latencies carry no token cost. With sixteen questions the
Wilson 95\% intervals on the headline proportions are wide (judged hybrid
$[0.23, 0.67]$; judge-as-filter $[0.72, 0.99]$; BM25 and RRF
$[0.81, 1.00]$), so the decomposition below, not the point estimates, is
the claim. An earlier six-method ablation was a smoke check at $n = 2$; the
scaled re-run on 2026-10-13 used ten questions (two built-in plus eight corpus
golds, each verified in both substrates), crossed with the three chat-endpoint
lanes (modes~A--C of
Table~\ref{tab:e4-matrix}) with BM25, dense and RRF ranking, pure retrieval,
no generation
(\path{benchmark-suite/results/}
\path{runs/run-20261013T035250Z-5f9faac/retmatrix.json}, archived as a
superseded campaign in
\path{superseded-20261013-batch2.tar.gz};
Table~\ref{tab:e4-matrix}). Document-level
recall: mode~A 10/10 (mean 19.8\,s), mode~B 7/10 (14.0\,s), mode~C 9/10
(33.1\,s); BM25, dense and RRF 10/10 at $\leq$0.1\,s, so on this question set
finding the gold document is not where the lanes earn their cost, and
Section~\ref{sec:e5} measures what they add. The three mode-B misses are
lane-diagnostic (an early-exit misfire onto a same-topic distractor family;
two description-overlap blind spots: a chunked-window and a
multiple-competing-documents question), and the hybrid lane recovers two
through its vector arm while adding one fail-closed judge loss of its own
(the QK01 gold's segments discarded). The dense baseline's first pass
searched an empty default library (zero documents on all ten questions); the
released row is a cross-library re-run, the default since removed from the
runner.

\begin{table}[t]
\caption{Six-method retrieval matrix, ten questions, pure retrieval.
Gold recall is document-level (the gold appears anywhere in the returned
set); every gold was verified to exist in both substrates
(live library for the modes, corpus index for the baselines).
Latency is mean wall clock per question.}
\label{tab:e4-matrix}
\centering\footnotesize
\setlength{\tabcolsep}{4pt}
\begin{tabular}{@{}lccc@{}}
\toprule
Method & Gold recall & Mean latency & Range \\
\midrule
Mode A (pinned dense + judge) & 10/10 & 19.8\,s & 18--24\,s \\
Mode B (ladder)               & 7/10  & 14.0\,s & 5--20\,s \\
Mode C (hybrid)               & 9/10  & 33.1\,s & 26--44\,s \\
BM25 (corpus index)           & 10/10 & $<$0.05\,s & --- \\
Dense (cross-library)         & 10/10 & 0.1\,s  & --- \\
RRF (BM25$\|$Dense)           & 10/10 & $<$0.05\,s & --- \\
\bottomrule
\end{tabular}
\end{table}

\textbf{On this corpus, lexical retrieval is strong.} BM25 \cite{bm25}
hits Hit@5 1.00 at about a millisecond per in-process call, reciprocal-rank
fusion \cite{rrf-cormack} matches it, and the two-stage BM25+graph-then-dense
pipeline reaches Recall@5 0.97 (Table~\ref{tab:retrieval}). Dense
retrieval with BGE-M3 \cite{bge-m3} misses one question (Q16), where four
near-duplicate sibling reports crowd the top-5 --- a confuser-density
failure, not a vocabulary one; graph search \cite{graphrag}, limited to
node-name and tag matching, is the weakest standalone signal. Nothing here
is a retrieval advance: three configurations tie at Hit@5 1.00, and the one
using only words leads on MRR. Q16 carries a filename token that also appears
in its gold path; excluding it leaves BM25 at 1.00 over the remaining fifteen
questions, so the tie does not depend on that leak.

\textbf{The measured result concerns ordering, not threshold-filter efficacy.}
Three configurations use the same logged candidate pools: fusion-only keeps
the original order (Hit@5 0.94), the judge-score reranker changes that order
(Hit@5 0.44), and the derived filter replay retains survivors in fusion order
(Hit@5 0.94). The filter replay matches fusion-only on Hit@5, Recall@5 and MRR;
it does not show a retrieval benefit from thresholding. All 191 recorded
segment scores exceed 0.5 (minimum 0.589); Q14 has one fused candidate without
a recorded score, whose status is unknown. We therefore conclude only that,
among the recorded scored candidates, the threshold rejected none and the
judge-induced ordering lost gold documents. On the eight questions where the
derived filter and reranker differ, restoring fusion order recovers Hit@5 on
all eight and loses none (exact binomial sign test, two-sided $p=0.008$); Q7
moves the gold from rank three to five, while four other questions move
upward. The evidence warns against using these verifier scores as a ranker on
this confuser-heavy corpus; it does not establish that the verdicts reliably
identify evidence or that filtering improves on fusion-only
(Figure~\ref{fig:marginvariants}(b)).

\textbf{A second corpus does not reproduce the Hit@5 collapse, but the ranking
effect is still visible.} Over ten
questions on the 79 retrievable papers of the 100-paper arXiv ingestion
(8{,}031 chunks logged; block~(b) of Table~\ref{tab:retrieval}), seven of
eight configurations reach Hit@5 0.90; graph search reaches 0.20. BQ03's
gold paper was not retrievable, so the observed denominator is 0.90 over all
ten questions and 1.00 over the nine with available gold. The judged ordering
keeps all nine golds inside the top five, but it demotes four of them from
rank one to rank two, and its MRR falls from 0.90 to 0.70 while the filter and
fusion rows stay at 0.90 (\texttt{exp10\_papers\_toollayer.json}). The
threshold-crossing harm therefore does not reproduce on this smaller,
less confuser-dense sample, while the ordering effect does. The graph result
is also configuration-specific: the bulk import bypassed the tagging path,
limiting what its node-name/path matching could retrieve.

\textbf{Thresholds and margins.} All 191 judged candidates from the
sixteen hybrid runs passed the configured absolute threshold of 0.5 (lowest
logged score 0.589), so at the threshold layer the gate filtered nothing on
this corpus (\texttt{exp1\_retrieval.json}). A sweep of the recorded scores
locates where filtering would begin to discriminate: cuts up to 0.70 keep
every in-pool gold and about 95\% of non-golds; 0.80 keeps 16 of 17 golds
while removing 21\% of non-golds; 0.85 keeps 13 of 17 and removes 40\%; at
0.88 the two retention rates converge (7 of 17 golds, 40\% of non-golds). The
signal is narrow and starts above the configured cut, and no answer-level test
of a higher cut was run (supplementary Table~S6). The margin sweep is a
separate diagnostic replay, not the configured control: it re-reads the logged pools
and keeps the top five candidates plus every candidate whose score lies
within a relative margin $m$ of the pool's best score. $m=0.15$ keeps 16 of
the 17 in-pool golds (Q11's gold sits deeper than 0.15 below its pool's
best) and $m=0.20$ keeps all 17; leave-one-out selection of the smallest
safe margin reaches 0.9375, missing only Q11, while a fixed $m=0.20$
reaches 1.00 (\texttt{exp6\_loo\_margin.json};
Figure~\ref{fig:marginvariants}(a) plots the sweep). Both constants are
replay parameters of this diagnostic; the calibration that would justify any
cut for deployment has not been run.

\begin{figure*}[t]
\centering
\includegraphics[width=0.78\textwidth]{fig6_margin_variants}
\caption{Two replays over the logged hybrid runs of this subsection; both
reuse recorded candidate pools and verdict scores rather than retrieving
again. (a)~A relative-margin replay: keep the top five plus every candidate
within $m$ of the pool's best score, $m$ swept 0.0--0.3; the solid curve
counts gold instances kept of the 17 that entered a pool, the grey curve the
mean candidates returned of the twelve submitted; dashed rules mark $m=0.15$
(16 of 17 golds kept) and $m=0.20$ (all 17). (b)~The verdict's four roles,
scored on identical candidates and identical verdict scores: fusion order,
verdict as re-ranker, verdict as filter, and rank fusion. Only the role
differs, which makes the panel an attribution rather than a benchmark; the
re-ranking role is the one that loses the gold.}
\label{fig:marginvariants}
\end{figure*}

\textbf{Rephrasing shows where the fragility sits.} On sixteen paraphrase
questions (\texttt{exp6\_paraphrase.json}) the judged configuration falls
to Hit@5 0.5 (MRR 0.189) while judge-as-filter and fusion-only hold at
0.9375 (MRR 0.833) and dense retrieval stays at 0.9375; BM25 falls from
1.00 to 0.875 (MRR 0.958 to 0.755). Under rewording both the lexical baseline and the judged re-ranking lose
ground while the configuration that keeps fusion order does not: the weakness
is the induced ordering, not the verdicts.

\textbf{End to end, the answer grid of Section~\ref{sec:e5} carries this
comparison.} Its original 30 cells name the gold document in every answer,
with recognized document-style markers in 9/10, 7/10 and 2/10 answers for P, F
and D; its common-substrate replication gives 9/9/9, so the marker ordering is
substrate-bound (Section~\ref{sec:e5}). Marker counts do not test whether
citations resolve or support claims; per-cell records and the replication are
in the supplementary material.


E4 establishes a bounded ordering result: on the logged industrial pools,
judge-score re-ranking lowered Hit@5, while retaining fusion order among
recorded survivors matched fusion-only. This does not establish a benefit from
threshold filtering or claim-level citation support. BM25 reaches Hit@5 1.00
on the same industrial set (Figure~\ref{fig:retrieval}), so retrieval recall is
not a demonstrated contribution here. The deployment-path question is whether
source identifiers, evidence traces and answer workflows improve auditability;
the E5 marker checks only partly address that question, and the verifier
failure analysis does not establish calibration.

\begin{figure}[t]
\centering
\includegraphics[width=\columnwidth]{fig3_retrieval}
\caption{Tool-layer retrieval over the 42-document industrial corpus (16
gold questions, top-5 document lists). BM25 reaches Hit@5 1.00. On the same
logged hybrid pools, verdict-score re-ranking reaches Hit@5 0.44, while a
derived replay that retains fusion order among recorded survivors reaches
0.94, matching fusion-only. The derived comparison diagnoses the effect of
ordering; because the 0.5 threshold rejects none of the 191 recorded scores,
it does not measure filtering benefit. Latency per call is in
Table~\ref{tab:retrieval}.}
\label{fig:retrieval}
\end{figure}


## 8 Evaluation (E5-E8)  [source: n8c_eval.tex]
% n8c_eval.tex — evaluation 8.6-8.8: E5 agent behaviour/abstention/cost,
% E6 verifier failure, E7 non-functional behaviour, E8 ablations.
% Every figure is attributed to its artifact; corpora are never mixed.
% Compressed 2026-10-12 (E7 and E8 reduced to single paragraphs; all
% floats and numbers retained). Round 2 2026-10-12: E6 prose tightened;
% floats and numbers untouched.

\subsection{E5: Answer quality, abstention and cost}
\label{sec:e5}
\label{sec:agentic}\label{sec:abstention}\label{sec:composition}\label{sec:eval-agent}
%% The four labels above are compatibility aliases: n2_related.tex:110,122,139
%% and n6_retrieval.tex:38,53-54 were written against the pre-restructure label
%% set. They all resolve to this subsection (answer quality, abstention,
%% latency composition).
%% Artifact shorthand used throughout this subsection: every path below is
%% relative to the repository root. Campaigns that were current when they were
%% written but are superseded today live in the tarballs listed under Data
%% availability (n_back.tex) and in TEST-RESULTS/ARTIFACTS.md; the
%% 30-cell grid of this subsection is current and unarchived.

\begin{table*}[t]
\centering
\footnotesize
\setlength{\tabcolsep}{3pt}
\caption{Answer quality per question and per interface in the original grid
(30 answer cells from \protect\path{run-20261013T094350Z-5f9faac}); the
controlled replication on a common substrate is reported in the text and adds
no column. Every answer passes the gold-ID
check, so coverage is 10/10 in each arm and the column is not repeated. Each
arm column gives strict keyword coverage (\yes\ or $\times$), alias-aware coverage,
and the number of recognized citation markers (m). Strict coverage is a
majority rule on the annotated terms, not an all-terms rule. Markers count
document-style syntax such as section or table locators; they do not establish
that a cited section exists or supports the sentence citing it.}
\label{tab:e5-answers}
\begin{tabular}{@{}l>{\raggedright\arraybackslash}p{0.335\textwidth}l*{9}{c}@{}}
\toprule
 & & & \multicolumn{3}{c}{Platform (P)} & \multicolumn{3}{c}{File tools (F)} & \multicolumn{3}{c}{Dense (D)}\\
\cmidrule(lr){4-6}\cmidrule(lr){7-9}\cmidrule(lr){10-12}
Q & Question (abridged) & Gold & s & a & m & s & a & m & s & a & m\\
\midrule
BQ01 & Transformer attention; why recurrence is replaced & 1706.03762 & \yes & \yes & 6 & \yes & \yes & 0 & \yes & \yes & 5\\
BQ02 & NISQ definition and its central limitation & 1801.00862 & \yes & \yes & 4 & \yes & \yes & 3 & \yes & \yes & 0\\
BQ03 & MultiMedQA and Flan-PaLM on MedQA & 2212.13138 & \yes & \yes & 4 & \yes & \yes & 1 & \yes & \yes & 1\\
BQ04 & Three ontologies subdividing the Gene Ontology & 1602.01876 & \yes & \yes & 1 & \yes & \yes & 1 & \yes & \yes & 0\\
BQ05 & European growth versus Unified Growth Theory & 1512.08067 & \yes & \yes & 0 & \yes & \yes & 0 & \yes & \yes & 0\\
BQ06 & Contributions governing precipitation extremes & 1503.07557 & $\times$ & \yes & 6 & \yes & \yes & 4 & \yes & \yes & 0\\
BQ07 & MameLoshnLM and its parameter scale & 2608.05850 & \yes & \yes & 1 & \yes & \yes & 2 & \yes & \yes & 0\\
BQ08 & Oxygen redox and cathode capacity & 2408.09942 & \yes & \yes & 2 & \yes & \yes & 0 & \yes & \yes & 0\\
BQ09 & Visual SLAM in dynamic scenes (MLP-SLAM) & 2410.10669 & \yes & \yes & 2 & $\times$ & \yes & 6 & \yes & \yes & 0\\
BQ10 & Tumour control under immune evasion & 2604.01385 & \yes & \yes & 3 & \yes & \yes & 6 & $\times$ & \yes & 0\\
\midrule
 & \emph{All ten questions} & & 9 & 10 & 29 & 9 & 10 & 23 & 9 & 10 & 6\\
\bottomrule
\end{tabular}
\end{table*}

\textbf{Answers locate the right document in all 30 cells of both grids;
keyword and marker counts depend on the substrate.}
Three arms answered ten gold questions through the public chat API on one model
(recorded in the run timeline as claude-opus-4-8[1m]) under one task contract.
In the original grid (Table~\ref{tab:e5-answers},
\path{run-20261013T094350Z-5f9faac}), every answer names its gold document,
alias-aware keyword coverage is 10/10 in every arm, strict keyword coverage is
9/10, and recognized citation-marker hits are 9/10, 7/10 and 2/10 for P, F and
D. Those arms differed in substrate: P used the default all-library scope, F
the exported file tree, and D an 800-character chunk replica. A controlled
replication then pinned all three arms to the same five domain libraries (322
stored parts): P and D search the vector collections and F reads the same
parts in full (\path{rerun5-20261017}). In that grid gold-identifier
coverage is again 10/10 in every arm, but strict coverage is 7/10, 7/10 and
8/10, alias-aware coverage 9/10, 9/10 and 10/10, and citation-marker hits
9/10 in every arm. Across the 30 paired cells the two grids agree on gold ID
in 30, alias coverage in 28, strict coverage in 25 and marker presence in 18;
all five strict disagreements favour the original grid and all nine marker
disagreements the common substrate (exact McNemar $p=0.0625$ and
$p=0.0039$). The marker contrast therefore tracks the substrate, not citation
quality; strict counts are not exchangeable between grids. We report
provenance and alias-aware coverage as the more stable measures and treat
strict and marker counts as substrate-bound; answer quality here means
provenance and lexical coverage, not semantic faithfulness.

\textbf{Per-question reading.}
In the original grid nine platform and seven file-tool answers carry a
document-style marker, while the dense arm produces eight with none; in the
replication the dense arm reads the same libraries and every arm gives nine. BQ05 carries no marker in any grid because it cites by title, a
form the deterministic pattern does not count. The strict misses differ between grids: the
original misses BQ06 in P (a Chinese answer that the declared aliases cover),
BQ09 in F and BQ10 in D; the replication misses BQ06 in all three arms, BQ08
and BQ09 in P and F, and BQ10 in D. Alias-aware coverage loses BQ08 in P and F
in the replication. Figure~\ref{fig:threearms}
shows the original grid's aggregate. Under the
pre-correction BQ06 key the platform arm scored 10/10 strict against a
mis-specified gold, and both grades are retained. A source-presence audit
found that in 29 of the original grid's 30 cells every strict keyword an
answer matched also occurs in the cited gold document (BQ06/P matched none),
and in all 30 replication cells; this is traceability, not entailment
(supplementary Tables~S7 and S8). The original grid also departed from the
stated contract in three cells: the BQ06 platform answer is not in English,
the BQ10 file-tool answer ran to 13 turns, and three platform cells invoked a
host shell outside the knowledge-base tool surface; the replication stayed
within the turn cap but one platform answer contains a short Chinese phrase
(Section~\ref{sec:threats}).

\begin{figure}[t]
\centering
\includegraphics[width=\columnwidth]{fig11_three_arms}
\caption{Answer checks for the original grid (30 cells,
\protect\path{run-20261013T094350Z-5f9faac}). Gold-identifier coverage is at
ceiling in all three arms; strict keyword coverage shows three misses, and
recognized citation markers fall from nine to seven to two answers. On a
common substrate the replication gives nine marker-bearing answers in every
arm, so this contrast is substrate-bound. The marker pattern counts
document-style syntax; it does not verify citation
resolution or claim support. Wall-clock and cost figures for these cells are
reported in the text and in the supplementary material.}
\label{fig:threearms}
\end{figure}

\textbf{Wall clock and cost.}
Arm~P averaged 52.6\,s and \$0.711 per question, against 22.2\,s/\$0.487 for
F and 24.5\,s/\$0.527 for D. These are single-run means: the platform arm is
slower and dearer in this run, and we report that as an observation about this
implementation rather than an efficiency result. Arm~F answered the same
questions by scanning the exported file tree without an index, which shows
direct scanning is viable at this corpus size but does not establish behavior
on the live 322-document collection. An archived sixteen-cell lane grid
recorded sub-second machine-side retrieval against a 36--91\,s end-to-end wall
clock, consistent with model turns dominating latency
\cite{singh-agentic-rag}; per-cell times, tool counts and costs are in the
supplementary material.

\textbf{Abstention is a property of the reading-and-answering layer, not of
a threshold.}
Three out-of-corpus questions produced three explicit not-found reports
(47.9, 73.3 and 113.5\,s wall clock; turns not recorded for this probe
family; \path{paper-kbs/experiments/results/exp8b_absent_agent.json}), each
enumerating the scope it searched (five libraries, 42 documents of the
industrial corpus). The
retrieval tools themselves never abstain: six graded probes
(\path{paper-kbs/experiments/results/exp8_graded_probes.json};
$n = 6$; three partially covered, three absent) retained 10 to 12 of their
12 candidates at every tier, with top scores up to 0.983 on absent probes
and 0.965 on partial ones, and the 0.5 threshold never fired as a refusal
(Figure~\ref{fig:ood}). The lane instructions ask the agent to abstain at the answer stage rather than
using a similarity cut-off as a refusal rule \cite{selfrag,feng-abstain,yin-knowwhat};
we report the observed behavior in these trials, not a server-enforced
abstention guarantee.

\begin{figure}[t]
\centering
\includegraphics[width=\columnwidth]{fig7_ood}
\caption{Tool-layer out-of-corpus probes
(\protect\path{paper-kbs/experiments/results/exp3_abstention.json}) retained 9--11
of the 42--43 merged candidates; dense scores also exceeded the search
threshold. Thus the retrieval threshold did not identify semantic absence in
these probes. In a separate answer-workflow probe family
(\protect\path{paper-kbs/experiments/results/exp8b_absent_agent.json}), three
completed absent queries returned natural-language not-found reports and no
fabricated citation was observed. The latter is an observation of instructed
agent behavior, not a server-side guarantee.}
\label{fig:ood}
\end{figure}

\textbf{Engines and channels.}
Across a separate 18-run task set, every run contained a gold-ID hit and no
manually identified fabricated citation. In the archived channel replay, two
channels each passed 8/9 gates and shared one false refusal after a 300\,s
vector-search stall, an execution failure rather than evidence of absence.
Per-run records are in the supplementary material, and these are observations
across engines and channels, not a one-factor estimate.

\subsection{E5b: Deployment-layer system arms through the public API (2026-10-12 campaign)}
\label{sec:sysarms}
E1--E5 exercise the platform from the operator side. Invoked as an external
caller, does it deliver the same contracts? Three questions (an English
methodology question, a Chinese clinical question and an out-of-corpus probe)
crossed three system arms through the external chat API: arm~A pinned the
target shelf, arm~B left the library unpinned, and arm~C pinned it with a
hybrid-retrieval directive. An in-corpus refusal fails the answer gate; an
earlier marker-only gate had counted refusals that repeated question keywords,
so the rule was corrected before the reported tally.

One streaming campaign and its non-streaming replication were run; per-arm
records are in the supplementary material. Arms A and C returned answers
containing the gold identifiers for both in-corpus questions, and all three
arms reported not-found for the out-of-corpus probe. Mean cost was \$0.182
(A), \$0.300 (B) and \$0.219 (C); a retrieval-only comparison returned the
gold in 6/6 cells.

The campaign also surfaced a transport failure: arm~B falsely refused the
computer-science question in three independent trials (two false refusals and
one hang). The 131-document shelf catalog returned by the librarian's listing
tool measures 74.9\,KB, above the agent engine's tool-output budget, so only a
2\,KB preview reached the model and it never saw the gold entry. Shelves of 53
and 75 documents stay under the budget and succeed, and a scripted lexical
scan over the same catalog answers the question in 25.0\,s and 10.2\,s with
both gold hits. The failure is a transport limit, not a ranking error: the
enforcement layer that honesty requires has transport constraints of its own
(Section~\ref{sec:discussion}).

\textbf{The repair and re-verification.} A 2026-10-13 change added
server-side character budgets, pagination and grouped catalog views. The
131-document shelf was represented by a 571-character grouping view; the
previously failing query was rerun through the same public API and passed the
campaign's answer gate (53.5\,s, nine turns). Two further live queries
exercised pagination and an unsupported cooking question, returning a sourced
answer (98.5\,s, nine turns) and a not-found report after a catalog scan
(39.9\,s, five turns).
These selected reruns show the tested paths completed after the repair; they do
not establish general transport reliability or semantic faithfulness.

\textbf{An adversarial honesty battery (2026-10-13).} Eighteen arms (three
lanes $\times$ six questions through the public API; archived per-arm records)
were scored against ground truth verified \emph{before} the run. One question
has its gold in the library; the five verified-absent ones are two cooking
questions, a same-word different-sense trap, a fine-tuning topic whose
neighbours are near-misses, and a fabricated protocol name. All five return
explicit not-found reports listing the scanned scope and their nearest
near-misses, and zero of the eighteen answers fabricate a citation. On the
fine-tuning question the librarian lane refuses after judging six near-miss
documents, while the hybrid lane returns a body-level applied-usage document
and states the coverage boundary inside the answer; both are honest, and a
binary gate cannot score the second. Two arms that hit a tool-mounting race
reported ``tools unavailable, nothing fabricated'' and were re-run.

\textbf{A second-corpus replication of the honesty contracts.} The same
contracts carry to the arXiv grid: every gold was present in the substrate its
arm searched, all 30 cells answer, and no answerable question is falsely
refused. An archived contrast over unverified three-chunk lists qualified most
answerable questions even where its list contained the gold; it differs in
prompt and granularity, so the contrast is across delivery configurations, not
an attribution to the gate. Platform answers cost \$0.79 each against
\$0.05--0.08 for baseline generation; per-arm records are in the supplement.

\subsection{E6: When the verifier fails}
\label{sec:e6}
\label{sec:inflation}\label{sec:eval-verify}   %% compatibility aliases (n2_related.tex:110)

\textbf{Same-domain score inflation.}
Across sixteen hybrid tool runs, 191 candidate segments have recorded
scores: twelve fused candidates per question except Q14, where eleven have
scores. Every recorded score is at least 0.589, above the 0.5 threshold. The
fusion log contains one additional Q14 candidate without a corresponding score;
its status is unknown, so it is not counted as a threshold rejection. The 17
in-pool gold documents (Q16's gold never entered its pool) have median score
0.88, versus 0.86 for 174 non-gold candidates, a difference not distinguishable
by a two-sided Mann--Whitney test ($p=0.26$; Figure~\ref{fig:inflation}). Five golds rank in the judge-score
top three and nine rank eighth or lower. On these logged pools, judge-score
re-ranking lowers Hit@5 to 0.4375 (7/16; 0.44 in Table~\ref{tab:retrieval});
the derived replay retaining fusion order among recorded survivors matches
fusion-only at 0.9375 (Section~\ref{sec:e4}). Figure~\ref{fig:anatomy}
dissects one query (Q2) in which the induced ordering demotes the gold from
fusion rank~1 to rank~8, outside the answer's read window. These document-ranking results
do not establish claim-level evidence accuracy.

\begin{figure}[!t]
\centering
\includegraphics[width=\columnwidth]{fig4_inflation}
\caption{Recorded Laya scores for 191 candidates from sixteen hybrid runs:
17 in-pool golds and 174 non-golds. All recorded values exceed the dashed
0.5 threshold; one additional Q14 fusion candidate has no recorded score and
its status is unknown. Group medians (0.88 gold, 0.86 non-gold) are not
distinguishable by a two-sided Mann--Whitney test ($p=0.26$). Horizontal
jitter is for legibility.}
\label{fig:inflation}
\end{figure}

\textbf{The verdict is a model \cite{laya}, and a second model fails the
same way.}
The same 191 logged (query, candidate) pairs, replayed rather than
re-retrieved, went through a 330M-parameter natural-language-inference
checkpoint with premises truncated to 1{,}600 characters (59 of 191 pairs at
the cap) (\path{paper-kbs/experiments/results/exp7_second_signal.json}). It
scores below the verdict (Hit@5 0.3125, MRR 0.1375) with inverted
separation, gold median 0.0113 against non-gold 0.05285 ($p = 0.120$).
Truncation is not the cause (six of ten context-fitting golds still score
below 0.01), nor domain: unrelated topics score corpus documents up to
0.9973, so an NLI threshold would abstain on nothing. A span-level replay inverts harder: over the 191 pairs and
3{,}489 span inferences at roughly 320 characters per span
(\path{paper-kbs/experiments/results/exp9_span_nli.json}), max-pooling
gives 0.4728 for gold against 0.91855 for non-gold ($p = 0.0074$), Hit@5
0.1875; rank fusion repairs neither signal (Hit@5 0.3125, MRR 0.111458).
Replacing the judge checkpoint is not the repair.

\textbf{What the failure tracks.}
None of these alternatives reaches the verdict's quality, ruling out the
checkpoint as sole cause; the second corpus shows the same gate losing
no gold from the top five there (Section~\ref{sec:e4}), so the collapse tracks
confuser density within one domain. That probe moved domain, language and corpus size
together with the confuser clusters --- an association confounded by design,
not an elimination
\cite{zheng-llmjudge,panickssery-selfpref,lightman-verify,yin-knowwhat}.
The verdict is not usable as a ranker on these pools. As a filter, the
recorded scores show only the narrow margin reported in
Section~\ref{sec:e4},
and no answer-level test of a higher cut has been run.



\begin{figure*}[t]
\centering
\includegraphics[width=0.78\textwidth]{fig8_anatomy}
\caption{Anatomy of one real query (Q2; single logged QDCVR-Hybrid call).
Each line is one of the 12 fused candidates; the green band is the top-5
window the answer agent reads in full. (a)~The shipped re-ranking: the
judge scores five extruder-PLC telemetry reports $0.887$--$0.926$ and the
gold root-cause report $0.846$, demoting it from fusion rank~1 to
rank~8 --- outside the read window. (b)~The same call with the verdicts
used only as a filter: all 12 pass, the fusion order stands, and the gold
is the first document read. Same pool, same scores, same verdicts; only
the role of the induced ordering differs.}
\label{fig:anatomy}
\end{figure*}



\subsection{E7: Non-functional behaviour}
\label{sec:e7}
The 27-cell stability campaign completed without answer errors (three tasks
$\times$ three retrieval modes $\times$ three rounds;
\path{review/stability-multiround-20261013/results}), with wall-clock spread
14.9--182.0\,s and answers staying on the same evidence. A concurrency
sweep on the same instance (90/180/270 requests at 5/15/30 clients;
supplementary material) recorded \emph{p50} rising from 5.2
to 1577\,ms, with 159 of 270 vector-only requests completing within 30\,s and
the remaining 111 (41\%) hitting the client timeout; the sweep reports no HTTP
errors and the timeouts are a capacity limit, not a correctness failure. A
later cache repair lowered the 30-client read-ladder \emph{p50} from 1577 to
65.8\,ms and repeated-query \emph{p50} from 3743 to 2.1\,ms; distinct
queries remained near 4--5 requests per second under a process-wide lock.
These are single-instance capacity observations, not validated throughput.
Concurrent write phases reported no lost updates, but raw counts and
crash-recovery tests are unavailable, so durability under interruption is not
claimed.


\subsection{E8: Ablations of the verification gate and the search scope}
\label{sec:e8}

Two bounded ablations probe the content gate of Section~\ref{sec:gate} and
the content-routed partition of Section~\ref{sec:org-placement} on the second
corpus (ten questions over five libraries and 322 stored parts). The gate
contrast uses a reconstructed frozen-candidate protocol because the planned
server switch was absent; the partition contrast compares search scopes with
the gold library supplied as a diagnostic condition. These are within-setup
diagnostics, not an end-to-end causal estimate of the three-contract system.
Both yield limited or null evidence; eight questions have a gold-matchable
outcome.

In the gate ablation, three arms shared one candidate pool (cap 12), one
4{,}000-character evidence pack and one grader
(\path{paper-kbs/experiments/results/exp11_gate_ablation.json}): no gate,
the gate as a filter, and a diagnostic arm receiving the judge's own
segment-level pack. Gold was packed at rank 1 in all eight
gold-answerable questions in all three arms, and on nine of ten questions
the gated arms received exactly the ungated arm's documents.
In this reconstructed setup, all returned scored survivors carry judge
provenance; that is an interface property, not evidence that the judge improved
answer quality. The candidate set and budget were held fixed, but downstream
LLM grades varied in both directions (QK01
$0\to5$ and QK03 $3\to0$ under the same twelve-document, 4{,}000-character
pack; sign test $p=1.0$, $n=10$). The only document-level pack shortened by
the gate was QK09 (12 to 4 documents), without changing its grade. The
segment-granularity arm scored 0.375 on the same subset, losing two answers
kept by the document-level arm (QK01, QK07) and gaining one (QK06). These
small-sample results do not establish an answer-quality benefit from the gate. Four of the eight gold-answerable questions (QK02,
QK04, QK05, QK08) scored zero in every arm, and two others scored partial
credit in one arm each. Both
non-gold questions --- an unanswerable and an out-of-corpus probe --- were
answered correctly as abstentions in every arm, the same layer at which the
industrial corpus locates honest abstention (Section~\ref{sec:e5}).

The search-scope diagnostic
(\path{paper-kbs/experiments/results/exp12_partition_ablation.json}) varies
what the retriever can see. With the gold library supplied as the scope,
Hit@5 is 1.0 and the gold ranks first; a deliberately different library gives
Hit@5 0.0 while still returning candidates. Searching all five libraries
matches the gold-pinned result in this ten-question setup. The catalog route
reaches Hit@5 1.0 with mean gold rank 1.75 and selects the correct library
first for six of eight answerable questions. These results illustrate the
consequence of scope choice under the tested filename convention; they do not
independently measure the accuracy of the ingest agent's placement decision.
All 322 stored parts carry an acquisition prefix
(\texttt{\{domain\}\_\_\{arxiv\_id\}\_\_\{slug\}}), so name-based routing
cannot serve as independent placement ground truth; the membership
measurement of Section~\ref{sec:e1} is the only placement-correctness figure
in this paper that avoids this confound, and it comes from the cross-lingual
corpus rather than from this one.

Both ablations are single-corpus, single-engine, ten-question diagnostics; the
gate ablation's control is fusion-ordered, so only its within-run contrast is
interpretable. Two of thirty cells were rerun after authentication failures.

## 9 Discussion and lessons learned  [source: n9_discussion.tex]
\section{Discussion and lessons learned}
\label{sec:discussion}

The first implication concerns what the answers are worth. On the fixed
question set the workflow locates the right document in all 30 cells of both
grids, and alias-aware keyword coverage stays at 9-10/10. Citation-marker and
strict-keyword counts are not stable across substrates: the original marker
ordering, 9/7/2, becomes 9/9/9 when every arm reads the same libraries. Across
paired cells, all five strict disagreements and all nine marker disagreements
run in one direction, so the change is a substrate effect rather than run
noise. The practical lesson is therefore narrower: judge the workflow on
provenance and coverage, and report the substrate alongside any marker or
keyword comparison. Retrieval recall alone is a weak criterion here, because every
lexical baseline reaches it on the same corpus.

The second implication concerns verifier placement, and it is the paper's main
mechanical finding: separating a content verifier's filtering role from its
ordering role is what allows the failure to be located. On identical logged
pools, re-ranking by the verdict lowers Hit@5 from 0.94 under fusion-only to
0.44. A derived replay that keeps the fusion order among scored survivors
returns the fusion-only metrics, and rephrased questions separate the roles
further: the judged configuration falls to 0.5 while both fusion-order
variants hold at 0.9375. Because all 191 recorded scores exceed the 0.5
threshold and one Q14 fused candidate has no recorded score, the comparison
diagnoses the induced ordering, not a threshold-filter benefit. A second
checkpoint and its span-level variant fail the same way on the same pools. The
second corpus does not reproduce the collapse, so the strongest supported
claim is that ranking by these checkpoints should not replace fusion order
under the tested confuser density; whether confuser density itself is the
cause remains an association, because the probe moved domain, language and
corpus size together.

The third implication concerns abstention. Similarity can retrieve related
material without answering a query. In this system, the answer workflow
instructs the agent to report the searched scope and say not-found when its
completed evidence review finds no support; the retrieval threshold never
played that role, since the graded probes retained 10 to 12 of their 12
candidates at every tier. The adversarial battery observed no fabricated
citations in eighteen final arms, but one partial answer fell outside the
binary grading scheme and each arm has a single final observation. Timeouts,
unavailable tools and incomplete searches must be reported as execution
failures, not conflated with semantic absence.

The fourth implication concerns transport. A reproduced oversized-catalog
response hid entries from the agent and led to a false refusal. Server-side
budgets, grouped views and pagination repaired the selected tested paths on
rerun. This supports the narrower point that transport limits can affect
retrieval outcomes, and that the enforcement layer honesty requires has
limits of its own.

The five research questions close at different evidence levels. RQ1 is
answered as an operational observation of the management layer, bounded by 21
papers that never became retrievable and by the use of a filename-independent
membership measurement rather than a per-document adjudication of placement.
RQ2 is answered for one corpus, one model and one question family: every
answer names its gold document, alias-aware coverage is 9-10/10, and the
citation-syntax difference between interfaces does not survive a
common-substrate replication; the checks are lexical and do not establish
semantic support. RQ3 reports tool-layer recall separately from end-to-end
source-marker checks; it does not claim similar recall in every interface or
isolate the gate's causal effect. RQ4 is answered within one corpus, one
checkpoint and one question family: on identical logged pools the tested
answer is to keep fusion order, and the comparison does not validate threshold
discrimination. RQ5 documents observed abstentions, turn-dominated latency and
a transport failure/recovery, with no broad reliability or user-utility
estimate.

More broadly, parsers, registries, indices and answer workflows benefit from
post-conditions that can be checked independently of success messages.
Catalogues and graphs support navigation but are not themselves evidence, in
keeping with provenance and auditability work in data systems
\cite{missier-prov-2013,cheney-provenance-2009}. The results remain bounded by
the tested corpora, developer-authored questions, one workstation and few
end-to-end observations. Larger independent question sets, repeated agent
trials, claim-level support assessments, a confuser-density-controlled
verifier evaluation that holds corpus, language and question set fixed while
varying near-duplicate density, operator studies of not-found reports and
crash-recovery tests are needed before stronger deployment claims.

## 10 Threats to validity  [source: n10_threats.tex]
\section{Threats to validity}
\label{sec:threats}

\noindent\textbf{Corpus and scale.} The results cover bounded demonstration and public
collections and a small arXiv-based corpus. Retrieval-only modes searched live
libraries, whereas lexical and dense baselines used a corpus index; these are
not identical retrieval substrates. The three answer arms of the original
grid also differ in substrate (default library scope, exported file tree,
800-character mirror), so that grid compares interface plus substrate; the
30-cell replication pins every arm to the same five libraries, and the marker
differences do not survive it. The three-source consistency
check is a 33-document sample, one tenth of the 322-document corpus, not a full
audit. Findings should not be generalized to larger or differently organized
collections without replication.

\noindent\textbf{Question construction and denominators.} Questions and gold
annotations were developer-authored. The two three-arm grids of
Section~\ref{sec:e5} are ten questions of one question family on one model,
each run once per arm: the platform arm's latency separation holds in both,
but the citation separation does not survive the common substrate, and the
grids cannot resolve differences smaller than one cell. The grounding reading
is at ceiling in both. Two answers in the original grid contain
an evidence-insufficiency qualifier; the grader's
\texttt{insufficient\_evidence} flag is a substring test that also fires when
the phrase appears inside a fully answering text, so we read those two flags
as measurement artifacts, not as hedges. Agent-track retrieval
hits are inferred from trace and answer, while citation checks provide the
more direct functional measure.

\noindent\textbf{Execution and grading.} The refusal battery has one final
observation per arm after rerunning two MCP-mount interruptions. Fabrication
checks were manually audited, and the binary gate required reclassification
of one body-level partial answer. Retrieval-only elapsed time is not directly
comparable to end-to-end agent latency. The E5 grader is deterministic but
lexical: its gold-ID, keyword and citation-marker checks do not establish
semantic claim support; gold-ID presence is checked in the answer or the
recorded trace, and keyword coverage passes at $\lceil 3n/5\rceil$ of the
annotated terms, so a missing term can still pass. Aliases are reported as a
separate regrade. The 30-cell grid and its controlled replication are each one run
per arm on one model, recorded as claude-opus-4-8[1m]; the paired analysis in
Section~\ref{sec:e5} bounds the stable reads. Three cells of the original grid
departed from the stated contract (Section~\ref{sec:e5}), and one platform
answer in the replication contains a short Chinese phrase. The archived pools store the survivors of each judged pool rather
than the dropped list, so the filter role cannot be re-derived beyond the
recorded scores. The BQ06 gold key was corrected to the source paper's
thermodynamic reading after inspection, and declared aliases cover known
word-form variants and Chinese renderings; the pre-correction question set and
its grade (strict 10/9/9) are retained alongside the corrected regrade (strict
9/9/9), and both sets are frozen for this submission in
\path{paper-kbs/tex/journal_20p/.frozen-experiment-sha256.txt}, so the
two-grade disclosure cannot drift after review. The
MCP lifecycle script passed its 16 direct assertions and the stdio protocol
test passed, but the lifecycle script is not pytest-collection-safe because it
calls \texttt{sys.exit} at module import.

{% keep the closing paragraph off a one-line orphan at a column foot;
% the blank line must sit inside this group so \par sees the penalty
\clubpenalty=10000
\noindent\textbf{Scope.} Tests ran on a single local workstation and one
verifier checkpoint. They do not establish generalization across model hosts,
large-scale corpora, independently authored questions, operator adoption,
adversarial access or crash-mid-write recovery. The pagination repair was
verified on selected catalog and query cases; broader transport boundary
testing remains necessary.

}


## 11 Conclusion  [source: n11_conclusion.tex]
\section{Conclusion}
\label{sec:conclusion}

QDCVR is a knowledge-base management system, and the evaluation is organized
around that claim. The management layer parses and admits documents through
gates that fail visibly, places them by content, keeps document files, the
tree registry and library metadata consistent, and audits rename, move, delete
and re-index operations. In the demonstration instance these checks hold in
place: 322 stored parts pass storage and content audits, the 50-paper campaign
parses 50/50, and sub-library creation and moves behave as specified. The same
layer also records its failures. Twenty-one of 100 submissions never became
retrievable and the surviving artifacts cannot attribute them, and one
oversized-catalog response hid entries from the agent and produced a false
refusal until a character budget and pagination repaired the tested paths.

The answer-level evaluation gives the system's end-to-end reading. Across ten
questions and three retrieval interfaces in two 30-cell grids (60 answer
cells), every answer names its gold document and alias-aware keyword coverage
is 9-10/10. Strict and
marker counts move with the substrate: the original marker ordering, 9/7/2,
becomes 9/9/9 on a common one, so these counts do not rank the interfaces.
The measures capture identifier presence and lexical or marker coverage, not
semantic support. An eighteen-arm honesty battery observed no fabricated
citations, and verified-absent questions returned explicit not-found reports;
that behavior is instructed at the answer layer, not enforced by a classifier.

The retrieval diagnostic bounds what the verifier can be used for. On
identical logged pools, ordering candidates by the verdict lowers Hit@5 from
0.94 to 0.44, while retaining fusion order among recorded survivors restores
0.94; all 191 recorded scores exceed the 0.5 threshold, and one additional
fusion candidate has no recorded score. The comparison therefore diagnoses a
harmful ordering role, not a benefit from threshold filtering. A verifier
score that is acceptable as an admission filter should not be assumed usable
as a ranker.

The contribution is a knowledge-base management workflow, a per-question
account of the answers it produces, and a same-pool diagnostic of verifier
placement, not a claim of universal retrieval or answer-quality superiority.
The results remain bounded by one workstation, one verifier checkpoint and
developer-authored questions. Next steps include independently curated
questions, repeated agent trials, claim-level evidence-support evaluation, a
confuser-density-controlled verifier evaluation, explicit execution-failure
states for incomplete searches, transport stress tests and operator studies
of not-found reports.

%% The back matter — CRediT, competing interest, funding, ethics statement,
%% data availability, acknowledgements, appendix and the mandated generative-AI
%% declaration — lives in n_back.tex, which main_20p.tex inputs immediately
%% after this file. Keeping it there gives every declaration one source of
%% truth and puts the AI declaration last before the reference list, as the
%% KBS guide requires.

## Back matter and appendix  [source: n_back.tex]
%% n_back.tex — back matter, included by main_20p.tex after n11_conclusion.tex
%% and before the bibliography. This file is the single source of truth for
%% every declaration; n11_conclusion.tex carries the Conclusion and nothing else.
%%
%% Section order follows the KBS Guide for Authors: CRediT, competing interest,
%% funding, ethics, data availability and acknowledgements after the
%% Conclusion; the appendix follows them; the mandated generative-AI
%% declaration is placed last so that it sits before the reference list, which
%% is where the guide requires it.
%%
%% AUTHOR ACTION: replace the CRediT names, confirm the funding wording, and
%% adjust or remove the acknowledgements.

\section*{CRediT authorship contribution statement}
\textbf{Author 1:} Conceptualization, Methodology, Software, Investigation,
Data curation, Writing -- original draft. \textbf{Author 2:} Validation,
Writing -- review \& editing, Supervision. %% AUTHOR ACTION: adjust.

\section*{Declaration of competing interest}
The authors declare that they have no known competing financial interests
or personal relationships that could have appeared to influence the work
reported in this paper.

\section*{Funding}
This research did not receive any specific grant from funding agencies in
the public, commercial, or not-for-profit sectors. %% AUTHOR ACTION

\section*{Ethics statement}
This article does not report studies involving human participants, human
data, or animals.

\section*{Data availability}
The platform source code, campaign logs and scripts, gold question sets,
replays and per-run JSON records cited in this paper are available at
\url{https://github.com/kingdol666/rag-knowledge} (benchmark suite:
\texttt{benchmark-suite/}; paper artifacts: \texttt{paper-kbs/}). The
evaluation inventory is indexed in \path{TEST-RESULTS/ARTIFACTS.md}. Within
\texttt{benchmark-suite/}: the end-to-end grid of Section~\ref{sec:e5} is
\path{results/runs/run-20261013T094350Z-5f9faac/}; original-annotation grades
are in \path{results/exp_r2_grade_original_revised.json}; corrected
annotations and their regrade are in
\path{data/papers/qa_questions_e5_corrected.json} and
\path{results/exp_r2_grade_corrected.json}; the grader is
\path{scripts/107_exp_grade.py}; and superseded campaigns stay in
\path{results/archive-superseded/}. Derived latency and cost statistics are in
\path{paper-kbs/tex/journal_20p/e5_numbers.json}. The corrected annotation set
is frozen for this submission (version ``2026-10-14 corrected evaluation
annotations'', frozen 2026-10-16, SHA-256
\texttt{86b07a9370984d42\ldots e62ece}), and the annotations, the
pre-correction question set and the grader are pinned together in
\path{paper-kbs/tex/journal_20p/.frozen-experiment-sha256.txt} so every
reported grade can be re-derived exactly. The supplementary material
(\path{paper-kbs/supplementary/supplementary-material.pdf}) carries the
campaign inventory, the appendix tables S1--S5 that
\ref{app:perq} cites, and the evaluation tables S6--S8. The 42-document industrial corpus is a demonstration
instance prepared for this study and is not customer data; it is not included
in the public repository, but the demonstration documents are available from
the authors on request. The headline ordering comparison does not depend on
its text: the judge-ordering row recomputes from the
released per-candidate scores in
\path{paper-kbs/experiments/results/exp1_retrieval.json}, the released gold
annotations and the grader, and the fusion lists behind the derived rows are
released for the anatomy query of Fig.~\ref{fig:anatomy} and retained per
question in the campaign records. An end-to-end re-run would additionally
require a substitute corpus; its construction recipe is documented with an
illustrative synthetic sample
(\path{paper-kbs/notes/industrial-corpus-substitute-recipe-2026-10-16.md}).

\section*{Acknowledgments}
The authors thank the maintainers of the open-source components the platform
builds on. %% AUTHOR ACTION: adjust or remove.

\appendix
\setcounter{table}{0}
\section{Supplementary tables}
\label{app:perq}

Eight tables are carried in the supplementary material
(\path{paper-kbs/supplementary/supplementary-material.pdf}) rather than in
this build: Table~S1, the stores read by the three-source checks; S2, the
cross-lingual ingestion result; S3, the sixteen gold questions with their
design intent; S4, the per-question best-gold-rank grid; S5, the
lifecycle-operation outcomes, including the two that failed; and S6--S8, the
verdict-score threshold sweep and the two source-presence audits.
The per-question grid localizes the aggregate metrics: judge-score re-ranking
misses eight golds that remain in the fusion order, the derived survivor
replay restores those ranks but inherits Q16's upstream miss, and the Q14
candidate without a recorded score remains unclassified. The S1--S5 LaTeX
sources are archived under
\path{paper-kbs/tex/journal_20p/_appendix-archived/}; S6--S8 are generated by
the scripts named in the supplement.

%% AUTHOR ACTION: confirm the service names (and add versions if the editors
%% ask) before submission. The two agent CLIs named here are the harnesses the
%% authors used on this project; repository state is not otherwise a source for
%% this declaration.
\section*{Declaration of generative AI and AI-assisted technologies in the manuscript preparation process}
During the preparation of this work the authors used the Anthropic Claude
Code and ZCode command-line coding agents in order to assist with experiment
execution, data tabulation, figure preparation and manuscript drafting. After
using these tools, the authors reviewed and edited the content as needed and
take full responsibility for the content of the publication. All experimental
numbers originate from logged runs of the system on the authors'
machine.

## Bibliography keys (refs.bib, refs_new_verified.bib)
rag-lewis; dpr; bge-m3; selfrag; crag; bm25; kamath; flare; graphrag; lightrag; raptor; siren; mineru; mcp; chroma; neo4j; deepread; cyberbot; react-yao; toolformer; rrf-cormack; singh-agentic-rag; qdcvr-demo; laya; hnsw; zheng-llmjudge; sun-urara; panickssery-selfpref; gao-ragsurvey; modular-rag; gao-citations; liu-verifiability; yin-knowwhat; feng-abstain; lightman-verify