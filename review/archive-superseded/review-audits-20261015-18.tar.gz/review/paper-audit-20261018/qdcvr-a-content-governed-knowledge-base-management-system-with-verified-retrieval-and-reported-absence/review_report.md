# Deep Review Report

**Paper**: `D:\codes\ClaudeGPT\rag_project\rag-knowledge\paper-kbs\tex\journal_20p\main_20p.tex` | **Language**: EN | **Mode**: deep-review
**Generated**: 2026-10-18 12:25 | **Venue**: kbs
**Artifacts**: `D:\codes\ClaudeGPT\rag_project\rag-knowledge\review\paper-audit-20261018\qdcvr-a-content-governed-knowledge-base-management-system-with-verified-retrieval-and-reported-absence`

## Overall Assessment

Deep review found 1 major, 0 moderate, 0 minor issues. The highest-priority concerns are: Abstract and conclusion claims need explicit evidence traceability.

- **Major**: 1
- **Moderate**: 0
- **Minor**: 0

## Academic Pre-Review Committee

### Editor (Desk Reject Screen)

## Editor Pre-Screen (1-10)

Score: 4.0/10
Verdict: Desk Reject

### Desk-Reject Triggers (if any)
- Abstract and conclusion claims need explicit evidence traceability

### Top 3 Reasons (no hedging)
1. Abstract and conclusion claims need explicit evidence traceability

### Fast Fixes (within 1-2 days)
- Clarify abstract to address abstract and conclusion claims need explicit evidence traceability.

### Reviewer 1 (Theory Contribution)

## Theory Contribution Review

### 3 Fatal Theory Holes
1. (abstract) "The findings indicate a bounded deployment account, not universal retrieval superiority." — At least one headline claim was detected. Deep review should check whether experiments and conclusion language trace back to the same bounded evidence base.

### Concrete Moves
- Tighten the paper's theoretical positioning in abstract to resolve abstract and conclusion claims need explicit evidence traceability.

### Reviewer 3 (Literature Dialogue)

## Literature Dialogue Review

### Closest Prior Work Risks
- No literature-grounding risk was surfaced by the fallback pass.

### Gap Claim Risks
- No selective-citation concern was surfaced.

### Fast Fixes
- Add one sentence identifying the closest prior work and the exact novelty delta.

### Reviewer 2 (Methodology & Transparency)

## Methodology Transparency Review (SRQR-aware)

### MUST-FIX (submission blockers)
- No methodology blocker was surfaced by the fallback pass.

### SHOULD-FIX (quality improvements)
- No secondary methodology issue was surfaced.

### SRQR Checklist Deltas
- Sampling rationale: clarify how the evidence base supports the paper's strongest claims.
- Data collection details (time/place/duration): add context when results depend on specific settings.
- Coding process (stages, coders, disagreement resolution): specify if qualitative or hybrid analysis is used.
- Saturation: state whether the evidence scope is exhaustive or bounded.
- Triangulation: explain whether multiple evidence sources were reconciled.
- Reflexivity: acknowledge researcher choices that shape interpretation.

### Reviewer 4 (Logic Chain)

## Logic Chain Review

### Breakpoints
- (abstract) "The findings indicate a bounded deployment account, not universal retrieval superiority." — At least one headline claim was detected. Deep review should check whether experiments and conclusion language trace back to the same bounded evidence base.

### Structural Fix Moves
- Add one explicit bridge sentence in abstract so the argument chain closes cleanly.

### Committee Consensus

## Committee Consensus

Overall Score: 4.0/10
Editor Verdict: Desk Reject

### Score Formula
- base 9.0
- minus 1.5 * major (1)
- minus 0.7 * moderate (0)
- minus 0.2 * minor (0)
- floor 1.0
- desk reject cap 4.0

### Top 3 Issues To Fix First
1. Abstract and conclusion claims need explicit evidence traceability

## Paper Summary

# Paper Summary: QDCVR: A content-governed knowledge-base management system with verified retrieval and reported absence

## Research Question
- Document collections need more than a retriever: documents must be parsed and admitted, organized so that they can be found, and used to answer questions whose cited evidence can be traced

## Core Thesis
- We present QDCVR, a self-hosted knowledge-base management system that treats content as the shared object across acquisition, organization and question answering.

## Headline Claims
- We present QDCVR, a self-hosted knowledge-base management system that treats content as the shared object across acquisition, organization and question answering.

## Section Map
- abstract (82-108): 245 words

## Closure Targets
- No closure target was extracted automatically.

## Major Issues

### M1: Abstract and conclusion claims need explicit evidence traceability
- **Type**: claim_accuracy
- **Source**: [LLM] via `claims_vs_evidence`
- **Confidence**: medium
- **Section**: abstract
- **Related Sections**: abstract, results, conclusion
- **Root Cause Key**: `abstract-and-conclusion-claims-need-explicit-evidence-traceability`
- **Quote Verified**: no
- **Quote**: `The findings indicate a bounded deployment account, not universal retrieval superiority.`
- **Explanation**: At least one headline claim was detected. Deep review should check whether experiments and conclusion language trace back to the same bounded evidence base.

## Phase 0 Automated Findings

### [Script] BIB

| Line | Severity | Issue |
|------|----------|-------|
| --- | Minor | Check: D:\codes\ClaudeGPT\rag_project\rag-knowledge\paper-kbs\tex\journal_20p\refs_new_verified.bib |
| --- | Minor | WARNING |
| --- | Minor | entries: 19 |
| --- | Minor | entries: 19 |
| --- | Minor | @barredo-arrieta-xai-2020: [IEEE] 12 authors listed; style uses et al. after 6. Ensure bibliography style handles truncation. |
| --- | Minor | Check: D:\codes\ClaudeGPT\rag_project\rag-knowledge\paper-kbs\tex\journal_20p\refs.bib |
| --- | Minor | FAIL |
| --- | Minor | entries: 35 |
| --- | Minor | entries: 34 |
| --- | Minor | @rag-lewis: [IEEE] 12 authors listed; style uses et al. after 6. Ensure bibliography style handles truncation. |
| --- | Minor | @rag-lewis: [IEEE] DOI recommended for inproceedings entries. |
| --- | Minor | @dpr: Missing required field 'author' |
| --- | Minor | @selfrag: [IEEE] DOI recommended for inproceedings entries. |
| --- | Minor | @crag: [IEEE] Missing recommended field 'volume' for article |
| --- | Minor | @crag: [IEEE] Missing recommended field 'pages' for article |
| --- | Minor | @flare: [IEEE] 9 authors listed; style uses et al. after 6. Ensure bibliography style handles truncation. |
| --- | Minor | @graphrag: [IEEE] Missing recommended field 'volume' for article |
| --- | Minor | @graphrag: [IEEE] Missing recommended field 'pages' for article |
| --- | Minor | @graphrag: [IEEE] 10 authors listed; style uses et al. after 6. Ensure bibliography style handles truncation. |
| --- | Minor | @graphrag: [IEEE] DOI recommended for article entries. |
| --- | Minor | @siren: [IEEE] Missing recommended field 'volume' for article |
| --- | Minor | @siren: [IEEE] Missing recommended field 'pages' for article |
| --- | Minor | @siren: [IEEE] 16 authors listed; style uses et al. after 6. Ensure bibliography style handles truncation. |
| --- | Minor | @siren: [IEEE] DOI recommended for article entries. |
| --- | Minor | @mineru: [IEEE] Missing recommended field 'volume' for article |
| --- | Minor | @mineru: [IEEE] Missing recommended field 'pages' for article |
| --- | Minor | @mineru: [IEEE] 18 authors listed; style uses et al. after 6. Ensure bibliography style handles truncation. |
| --- | Minor | @deepread: [IEEE] Missing recommended field 'volume' for article |
| --- | Minor | @deepread: [IEEE] Missing recommended field 'pages' for article |
| --- | Minor | @cyberbot: [IEEE] 10 authors listed; style uses et al. after 6. Ensure bibliography style handles truncation. |
| --- | Minor | @react-yao: [IEEE] 7 authors listed; style uses et al. after 6. Ensure bibliography style handles truncation. |
| --- | Minor | @toolformer: [IEEE] 9 authors listed; style uses et al. after 6. Ensure bibliography style handles truncation. |
| --- | Minor | @singh-agentic-rag: [IEEE] Missing recommended field 'volume' for article |
| --- | Minor | @singh-agentic-rag: [IEEE] Missing recommended field 'pages' for article |
| --- | Minor | @qdcvr-demo: [IEEE] DOI recommended for inproceedings entries. |
| --- | Minor | @sun-urara: [IEEE] 8 authors listed; style uses et al. after 6. Ensure bibliography style handles truncation. |
| --- | Minor | @gao-ragsurvey: [IEEE] Missing recommended field 'volume' for article |
| --- | Minor | @gao-ragsurvey: [IEEE] Missing recommended field 'pages' for article |
| --- | Minor | 5 entries missing DOI/URL (Use --online-check to export list) |
| --- | Minor | AI-generated citations have ~40% error rate. Verify entries without DOI/URL using Semantic Scholar API or CrossRef. See references/citations/verification.md for verification workflow. |
| --- | Minor | [Script] checker exited 1 |

### [Script] CITATIONS

| Line | Severity | Issue |
|------|----------|-------|
| --- | Minor | No citation stacking issues found. |

### [Script] DEAI

| Line | Severity | Issue |
|------|----------|-------|
| --- | Minor | Use --analyze for full analysis |

### [Script] EXPERIMENT

| Line | Severity | Issue |
|------|----------|-------|
| --- | Major | (n7_implementation.tex:33) : Performance claim lacks an explicit baseline or comparator. |
| --- | Critical | (n7_implementation.tex:35) : Conclusion overreaches the reported evidence; avoid universal or guarantee-style claims. |
| --- | Minor | (n7_implementation.tex:1) : No ablation or component-level evidence is mentioned; verify that contribution attribution is covered. |
| --- | Minor | (n7_implementation.tex:1) : No statistical significance, variance, or confidence information is mentioned. |
| --- | Major | (n9_discussion.tex:1) : Discussion may lack depth: low ratio of explanatory/attribution language (3/71 lines). Add causal analysis explaining why results occur. |
| --- | Minor | (n11_conclusion.tex:1) : Conclusion lacks implications or broader impact statement. |
| --- | Minor | (n11_conclusion.tex:1) : Conclusion lacks explicit summary of core findings. |

### [Script] FIGURES

| Line | Severity | Issue |
|------|----------|-------|
| --- | Minor | figures in D:\codes\ClaudeGPT\rag_project\rag-knowledge\paper-kbs\tex\journal_20p\main_20p.tex... |
| --- | Minor | 8 figures. |
| --- | Minor | n3_overview.tex:76: fig1_architecture |
| --- | Minor | n6_retrieval.tex:96: fig2_lanes |
| --- | Minor | n8b_eval.tex:229: fig6_margin_variants |
| --- | Minor | n8b_eval.tex:273: fig3_retrieval |
| --- | Minor | n8c_eval.tex:107: fig11_three_arms |
| --- | Minor | n8c_eval.tex:152: fig7_ood |
| --- | Minor | n8c_eval.tex:259: fig4_inflation |
| --- | Minor | n8c_eval.tex:303: fig8_anatomy |
| --- | Minor | All figures passed check. |

### [Script] FORMAT

| Line | Severity | Issue |
|------|----------|-------|
| --- | Minor | ============================================================ |
| --- | Minor | Format Check Report |
| --- | Minor | ============================================================ |
| --- | Minor | D:\codes\ClaudeGPT\rag_project\rag-knowledge\paper-kbs\tex\journal_20p\main_20p.tex |
| --- | Minor | WARNING |
| --- | Minor | Found 209 issues |
| --- | Minor | Found |
| --- | Minor | (34 issues) |
| --- | Minor | 98: Wrong length of dash may have been used. |
| --- | Minor | 24: Wrong length of dash may have been used. |
| --- | Minor | 32: Wrong length of dash may have been used. |
| --- | Minor | 32: Wrong length of dash may have been used. |
| --- | Minor | 69: Wrong length of dash may have been used. |
| --- | Minor | ... and 29 more |
| --- | Minor | (2 issues) |
| --- | Minor | 54: Use either `` or '' as an alternative to `"'. |
| --- | Minor | 54: Use either `` or '' as an alternative to `"'. |
| --- | Minor | (173 issues) |
| --- | Minor | 72: Intersentence spacing (`\@') should perhaps be used. |
| --- | Minor | 111: Command terminated with space. |
| --- | Minor | 111: Command terminated with space. |
| --- | Minor | 111: Command terminated with space. |
| --- | Minor | 112: Command terminated with space. |
| --- | Minor | ... and 168 more |
| --- | Minor | ============================================================ |

### [Script] GRAMMAR

| Line | Severity | Issue |
|------|----------|-------|
| --- | Minor | [Script]: goal=grammar strength=minimal |
| --- | Minor | No rule-based issues detected in selected scope. |

### [Script] LOGIC

| Line | Severity | Issue |
|------|----------|-------|
| --- | Critical | Section not found: methods (available: introduction, related, experiment, experiment_2, discussion, conclusion, abstract) |
| --- | Major | REVIEW (n2_related.tex:104-114) : No research gap derivation found at end of Related Work |

### [Script] PRESUBMISSION

| Line | Severity | Issue |
|------|----------|-------|
| 82 | Minor | [G2] Long paragraph detected (253 words, 12 sentences); split or add a clearer topic sentence. |

### [Script] SENTENCES

| Line | Severity | Issue |
|------|----------|-------|
| --- | Minor | [Script]: goal=grammar strength=minimal |
| --- | Minor | SENTENCE (n1_intro.tex:4, 44 words, 4 clauses)  [Script] |
| --- | Minor | A document collection becomes a knowledge base only when three things hold: its documents are parsed and admitted reliably, they are organized so that the right material can be found, and the system can answer a question with a citation whose source is traceable. |
| --- | Minor | A document collection becomes a knowledge base only when three things hold: its documents are parsed and admitted reliably. they are organized so that the right material can be found. and the system can answer a question with a citation whose source is traceable.. |
| --- | Minor | Sentence exceeds complexity threshold, split for readability. Applying the split needs --strength moderate or higher. |
| --- | Minor | none (split proposal only; source not rewritten) |
| --- | Minor | none |
| --- | Minor | Check: NEEDS-LLM |
| --- | Minor | Flags:    not-assessed |
| --- | Minor | SENTENCE (n1_intro.tex:47, 24 words, 4 clauses)  [Script] |
| --- | Minor | The platform integrates document parsing, content-informed organization, lifecycle management, operational experiences, multi-lane retrieval and a Model Context Protocol (MCP) server with 95 registered tools . |
| --- | Minor | The platform integrates document parsing. content-informed organization. lifecycle management. operational experiences. multi-lane retrieval and a Model Context Protocol (MCP) server with 95 registered tools .. |
| --- | Minor | Sentence exceeds complexity threshold, split for readability. Applying the split needs --strength moderate or higher. |
| --- | Minor | none (split proposal only; source not rewritten) |
| --- | Minor | none |
| --- | Minor | Check: NEEDS-LLM |
| --- | Minor | Flags:    not-assessed |
| --- | Minor | SENTENCE (n1_intro.tex:54, 32 words, 4 clauses)  [Script] |
| --- | Minor | \noindent\textbf{Contributions.} \begin{enumerate} \item A self-hosted knowledge-base management system that links quality-gated acquisition, content-informed placement, three-source consistency and lifecycle operations, with an invoked server-side evidence gate on the query path. |
| --- | Minor | \noindent\textbf{Contributions.} \begin{enumerate} \item A self-hosted knowledge-base management system that links quality-gated acquisition. content-informed placement. three-source consistency and lifecycle operations. with an invoked server-side evidence gate on the query path.. |
| --- | Minor | Sentence exceeds complexity threshold, split for readability. Applying the split needs --strength moderate or higher. |
| --- | Minor | none (split proposal only; source not rewritten) |
| --- | Minor | none |
| --- | Minor | Check: NEEDS-LLM |
| --- | Minor | Flags:    not-assessed |
| --- | Minor | SENTENCE (n1_intro.tex:54, 39 words, 5 clauses)  [Script] |
| --- | Minor | \item An answer-level evaluation over ten questions crossed with three retrieval interfaces in two 30-cell grids (original and common-substrate), reported per question: gold-identifier presence, strict and alias-aware keyword coverage, recognized citation markers, and abstention on verified-absent questions (Section~ , Table~ ). |
| --- | Minor | \item An answer-level evaluation over ten questions crossed with three retrieval interfaces in two 30-cell grids (original and common-substrate). reported per question: gold-identifier presence. strict and alias-aware keyword coverage. recognized citation markers. and abstention on verified-absent questions (Section~. Table~ ).. |
| --- | Minor | Sentence exceeds complexity threshold, split for readability. Applying the split needs --strength moderate or higher. |
| --- | Minor | none (split proposal only; source not rewritten) |
| --- | Minor | none |
| --- | Minor | Check: NEEDS-LLM |
| --- | Minor | Flags:    not-assessed |
| --- | Minor | SENTENCE (n1_intro.tex:54, 45 words, 4 clauses)  [Script] |
| --- | Minor | Ordering candidates by the verifier score lowers Hit@5 from 0.94 to 0.44, while retaining fusion order among recorded survivors restores 0.94; all 191 recorded scores exceed the configured threshold, so the loss is attributable to the induced ordering, not to filtering. |
| --- | Minor | Ordering candidates by the verifier score lowers Hit@5 from 0.94 to 0.44. while retaining fusion order among recorded survivors restores 0.94; all 191 recorded scores exceed the configured threshold. so the loss is attributable to the induced ordering. not to filtering.. |
| --- | Minor | Sentence exceeds complexity threshold, split for readability. Applying the split needs --strength moderate or higher. |
| --- | Minor | none (split proposal only; source not rewritten) |
| --- | Minor | none |
| --- | Minor | Check: NEEDS-LLM |
| --- | Minor | Flags:    not-assessed |
| --- | Minor | SENTENCE (n1_intro.tex:86, 91 words, 6 clauses)  [Script] |
| --- | Minor | Five questions structure the design-to-evidence sequence, ordered by the weight of the answer rather than by the pipeline: how the management layer behaves on demonstration and public collections, covering parsing, admission, placement and lifecycle (RQ1); what answer quality the end-to-end workflow reaches on a fixed question set, measured per question and per interface (RQ2); how the tested retrieval configurations compare on document recall and evidence markers (RQ3); whether a verifier score should order candidates or only filter them (RQ4); and what abstention, cost and execution-reliability observations arise in end-to-end trials (RQ5). |
| --- | Minor | Five questions structure the design-to-evidence sequence. ordered by the weight of the answer rather than by the pipeline: how the management layer behaves on demonstration and public collections. covering parsing. admission. placement and lifecycle (RQ1); what answer quality the end-to-end workflow reaches on a fixed question set. measured per question and per interface (RQ2); how the tested retrieval configurations compare on document recall and evidence markers (RQ3); whether a verifier score should order candidates or only filter them (RQ4); and what abstention. cost and execution-reliability observations arise in end-to-end trials (RQ5).. |
| --- | Minor | Sentence exceeds complexity threshold, split for readability. Applying the split needs --strength moderate or higher. |
| --- | Minor | none (split proposal only; source not rewritten) |
| --- | Minor | none |
| --- | Minor | Check: NEEDS-LLM |
| --- | Minor | Flags:    not-assessed |
| --- | Minor | SENTENCE (n2_related.tex:4, 29 words, 4 clauses)  [Script] |
| --- | Minor | \subsection{Knowledge management and document acquisition} Public knowledge bases organize facts under explicit ontologies \citep{auer-dbpedia-kb-2007,hoffart-yago2-kb-2013}, whereas enterprise content management emphasizes governance over organizational documents \citep{paivarinta-ecm-2005,tyrvaainen-ecm-2006}. |
| --- | Minor | \subsection{Knowledge management and document acquisition} Public knowledge bases organize facts under explicit ontologies \citep{auer-dbpedia-kb-2007. hoffart-yago2-kb-2013}. whereas enterprise content management emphasizes governance over organizational documents \citep{paivarinta-ecm-2005. tyrvaainen-ecm-2006}.. |
| --- | Minor | Sentence exceeds complexity threshold, split for readability. Applying the split needs --strength moderate or higher. |
| --- | Minor | none (split proposal only; source not rewritten) |
| --- | Minor | none |
| --- | Minor | Check: NEEDS-LLM |
| --- | Minor | Flags:    not-assessed |
| --- | Minor | SENTENCE (n2_related.tex:4, 28 words, 6 clauses)  [Script] |
| --- | Minor | Research on organizational knowledge explains how tacit experience becomes shareable \citep{nonaka-seci-1994,nonaka-seci-ba-2000}; adjacent work studies metadata quality, tagging, human review and auditability \citep{park-metadata-quality-2009,golder-tagging-2006,mosqueira-rey-hitl-2022,barredo-arrieta-xai-2020}. |
| --- | Minor | Research on organizational knowledge explains how tacit experience becomes shareable \citep{nonaka-seci-1994. nonaka-seci-ba-2000}; adjacent work studies metadata quality. tagging. human review and auditability \citep{park-metadata-quality-2009. golder-tagging-2006. mosqueira-rey-hitl-2022. barredo-arrieta-xai-2020}.. |
| --- | Minor | Sentence exceeds complexity threshold, split for readability. Applying the split needs --strength moderate or higher. |
| --- | Minor | none (split proposal only; source not rewritten) |
| --- | Minor | none |
| --- | Minor | Check: NEEDS-LLM |
| --- | Minor | Flags:    not-assessed |
| --- | Minor | SENTENCE (n2_related.tex:4, 18 words, 4 clauses)  [Script] |
| --- | Minor | Document-AI methods, including layout-aware analysis and MinerU, recover text and structure from complex documents \citep{zhong-publaynet-layout-2019,huang-layoutlmv3-docai-2022,mineru}. |
| --- | Minor | Document-AI methods. including layout-aware analysis and MinerU. recover text and structure from complex documents \citep{zhong-publaynet-layout-2019. huang-layoutlmv3-docai-2022. mineru}.. |
| --- | Minor | Sentence exceeds complexity threshold, split for readability. Applying the split needs --strength moderate or higher. |
| --- | Minor | none (split proposal only; source not rewritten) |
| --- | Minor | none |
| --- | Minor | Check: NEEDS-LLM |
| --- | Minor | Flags:    not-assessed |
| --- | Minor | SENTENCE (n2_related.tex:45, 18 words, 4 clauses)  [Script] |
| --- | Minor | Other work studies selective prediction under domain shift, ontology-grounded retrieval and citation verification \citep{kamath,cyberbot,liu-verifiability,gao-citations}. |
| --- | Minor | Other work studies selective prediction under domain shift. ontology-grounded retrieval and citation verification \citep{kamath. cyberbot. liu-verifiability. gao-citations}.. |
| --- | Minor | Sentence exceeds complexity threshold, split for readability. Applying the split needs --strength moderate or higher. |
| --- | Minor | none (split proposal only; source not rewritten) |
| --- | Minor | none |
| --- | Minor | Check: NEEDS-LLM |
| --- | Minor | Flags:    not-assessed |
| --- | Minor | SENTENCE (n2_related.tex:55, 24 words, 4 clauses)  [Script] |
| --- | Minor | The LLM-as-a-judge literature documents preference bias, imperfect agreement, listwise instability and self-preference \citep{zheng-llmjudge,sun-urara,panickssery-selfpref}; verifier gaming is an additional concern \citep{lightman-verify}. |
| --- | Minor | The LLM-as-a-judge literature documents preference bias. imperfect agreement. listwise instability and self-preference \citep{zheng-llmjudge. sun-urara. panickssery-selfpref}; verifier gaming is an additional concern \citep{lightman-verify}.. |
| --- | Minor | Sentence exceeds complexity threshold, split for readability. Applying the split needs --strength moderate or higher. |
| --- | Minor | none (split proposal only; source not rewritten) |
| --- | Minor | none |
| --- | Minor | Check: NEEDS-LLM |
| --- | Minor | Flags:    not-assessed |
| --- | Minor | SENTENCE (n2_related.tex:63, 54 words, 5 clauses)  [Script] |
| --- | Minor | The gap this study addresses is one of integration and of role separation rather than of missing capabilities: QDCVR examines how acquisition checks, content-informed placement, retrieval and answer-time evidence inspection interact in one knowledge-base workflow, reports where implementation and transport boundaries constrain that workflow, and measures separately the two roles a verifier can play. |
| --- | Minor | The gap this study addresses is one of integration and of role separation rather than of missing capabilities: QDCVR examines how acquisition checks. content-informed placement. retrieval and answer-time evidence inspection interact in one knowledge-base workflow. reports where implementation and transport boundaries constrain that workflow. and measures separately the two roles a verifier can play.. |
| --- | Minor | Sentence exceeds complexity threshold, split for readability. Applying the split needs --strength moderate or higher. |
| --- | Minor | none (split proposal only; source not rewritten) |
| --- | Minor | none |
| --- | Minor | Check: NEEDS-LLM |
| --- | Minor | Flags:    not-assessed |
| --- | Minor | SENTENCE (n2_related.tex:76, 46 words, 5 clauses)  [Script] |
| --- | Minor | Its contribution is a knowledge-base management workflow that owns the chain from parse admission to answer citation, a per-question account of the answers that chain produces, and a same-pool diagnostic showing that ordering by the verifier score, not threshold filtering, is where the measurable loss sits. |
| --- | Minor | Its contribution is a knowledge-base management workflow that owns the chain from parse admission to answer citation. a per-question account of the answers that chain produces. and a same-pool diagnostic showing that ordering by the verifier score. not threshold filtering. is where the measurable loss sits.. |
| --- | Minor | Sentence exceeds complexity threshold, split for readability. Applying the split needs --strength moderate or higher. |
| --- | Minor | none (split proposal only; source not rewritten) |
| --- | Minor | none |
| --- | Minor | Check: NEEDS-LLM |
| --- | Minor | Flags:    not-assessed |
| --- | Minor | SENTENCE (n2_related.tex:99, 284 words, 20 clauses)  [Script] |
| --- | Minor | \begin{tabular}{@{}>{\raggedright\arraybackslash}p{0.145\textwidth}>{\raggedright\arraybackslash}p{0.285\textwidth}>{\raggedright\arraybackslash}p{0.24\textwidth}>{\raggedright\arraybackslash}p{0.24\textwidth}@{}} \toprule Strand & Representative work & What it optimizes & What it leaves to the deployment\\ \midrule Knowledge management & Public knowledge bases \citep{auer-dbpedia-kb-2007,hoffart-yago2-kb-2013}; enterprise content management \citep{paivarinta-ecm-2005,tyrvaainen-ecm-2006} & An explicit ontology, or governance over a curated collection & Whether an answer drawn from that collection is supported by the text it cites\\ Document AI & Layout-aware extraction \citep{zhong-publaynet-layout-2019,huang-layoutlmv3-docai-2022}; MinerU \citep{mineru} & Recovery of text, tables and formulas from difficult layouts & Whether what was recovered is complete enough to index, and where it is then stored\\ Retrieval & Dense \citep{dpr}, lexical \citep{bm25} and hybrid ranking \citep{rrf-cormack,bge-m3} & Rank quality over a corpus that is assumed indexed & Whether a top-ranked candidate contains evidence for the claim it is used to support\\ Graph-structured organization & GraphRAG \citep{graphrag}, LightRAG \citep{lightrag}, RAPTOR \citep{raptor} & Multi-hop and hierarchical relationships between documents & Evidentiary status: a graph edge is a navigation fact, not evidence\\ Self-reflective generation & Self-RAG \citep{selfrag}, CRAG \citep{crag}, FLARE \citep{flare}; judge-based verification \citep{zheng-llmjudge,lightman-verify} & Evidence assessment or retrieval correction in generation workflows & How verification and abstention interact with knowledge-base acquisition and organization in a knowledge-base workflow\\ Agentic tool use & ReAct \citep{react-yao}, MCP \citep{mcp}, DeepRead \citep{deepread} & Access to retrieval tools behind a stable interface & Whether configured retrieval budgets and failure states are exposed and checked in a particular deployment\\ \midrule QDCVR (this work) & Sections~ --  & An integration of content-informed placement, indexed-state checks, an invoked server-side evidence gate and agent answer reporting & Claims beyond the measured corpora and configurations, bounded in Section~ \\ \bottomrule \end{tabular} \end{table*} |
| --- | Minor | \begin{tabular}{@{}>{\raggedright\arraybackslash}p{0.145\textwidth}>{\raggedright\arraybackslash}p{0.285\textwidth}>{\raggedright\arraybackslash}p{0.24\textwidth}>{\raggedright\arraybackslash}p{0.24\textwidth}@{}} \toprule Strand & Representative work & What it optimizes & What it leaves to the deployment\\ \midrule Knowledge management & Public knowledge bases \citep{auer-dbpedia-kb-2007. hoffart-yago2-kb-2013}; enterprise content management \citep{paivarinta-ecm-2005. tyrvaainen-ecm-2006} & An explicit ontology. or governance over a curated collection & Whether an answer drawn from that collection is supported by the text it cites\\ Document AI & Layout-aware extraction \citep{zhong-publaynet-layout-2019. huang-layoutlmv3-docai-2022}; MinerU \citep{mineru} & Recovery of text. tables and formulas from difficult layouts & Whether what was recovered is complete enough to index. and where it is then stored\\ Retrieval & Dense \citep{dpr}. lexical \citep{bm25} and hybrid ranking \citep{rrf-cormack. bge-m3} & Rank quality over a corpus that is assumed indexed & Whether a top-ranked candidate contains evidence for the claim it is used to support\\ Graph-structured organization & GraphRAG \citep{graphrag}. LightRAG \citep{lightrag}. RAPTOR \citep{raptor} & Multi-hop and hierarchical relationships between documents & Evidentiary status: a graph edge is a navigation fact. not evidence\\ Self-reflective generation & Self-RAG \citep{selfrag}. CRAG \citep{crag}. FLARE \citep{flare}; judge-based verification \citep{zheng-llmjudge. lightman-verify} & Evidence assessment or retrieval correction in generation workflows & How verification and abstention interact with knowledge-base acquisition and organization in a knowledge-base workflow\\ Agentic tool use & ReAct \citep{react-yao}. MCP \citep{mcp}. DeepRead \citep{deepread} & Access to retrieval tools behind a stable interface & Whether configured retrieval budgets and failure states are exposed and checked in a particular deployment\\ \midrule QDCVR (this work) & Sections~ --  & An integration of content-informed placement. indexed-state checks. an invoked server-side evidence gate and agent answer reporting & Claims beyond the measured corpora and configurations. bounded in Section~ \\ \bottomrule \end{tabular} \end{table*}. |
| --- | Minor | Sentence exceeds complexity threshold, split for readability. Applying the split needs --strength moderate or higher. |
| --- | Minor | none (split proposal only; source not rewritten) |
| --- | Minor | none |
| --- | Minor | Check: NEEDS-LLM |
| --- | Minor | Flags:    not-assessed |
| --- | Minor | SENTENCE (n7_implementation.tex:8, 42 words, 10 clauses)  [Script] |
| --- | Minor | The platform exposes 95 MCP tools across twelve functional groups, including parsing, search, content verification, indexing, tags, the document graph and operational experience, plus persona distillation, which shares the same storage, catalog and gate but lies outside the scope of this evaluation. |
| --- | Minor | The platform exposes 95 MCP tools across twelve functional groups. including parsing. search. content verification. indexing. tags. the document graph and operational experience. plus persona distillation. which shares the same storage. catalog and gate but lies outside the scope of this evaluation.. |
| --- | Minor | Sentence exceeds complexity threshold, split for readability. Applying the split needs --strength moderate or higher. |
| --- | Minor | none (split proposal only; source not rewritten) |
| --- | Minor | none |
| --- | Minor | Check: NEEDS-LLM |
| --- | Minor | Flags:    not-assessed |
| --- | Minor | SENTENCE (n8a_eval.tex:4, 40 words, 5 clauses)  [Script] |
| --- | Minor | Sections --  cover the query path: retrieval quality (Section~ ), answer quality per question and abstention (Section~ , the paper's end-to-end evidence), a deployment-layer replication through the public API (Section~ ), verifier failure (Section~ ), non-functional behavior (Section~ ) and the gate and search-scope ablations (Section~ ). |
| --- | Minor | Sections --  cover the query path: retrieval quality (Section~ ). answer quality per question and abstention (Section~. the paper's end-to-end evidence). a deployment-layer replication through the public API (Section~ ). verifier failure (Section~ ). non-functional behavior (Section~ ) and the gate and search-scope ablations (Section~ ).. |
| --- | Minor | Sentence exceeds complexity threshold, split for readability. Applying the split needs --strength moderate or higher. |
| --- | Minor | none (split proposal only; source not rewritten) |
| --- | Minor | none |
| --- | Minor | Check: NEEDS-LLM |
| --- | Minor | Flags:    not-assessed |
| --- | Minor | SENTENCE (n8a_eval.tex:22, 28 words, 4 clauses)  [Script] |
| --- | Minor | (iii)~\emph{Cross-lingual ingestion corpus}: 400 Wikipedia pages per language (English, Chinese, Japanese), 40 extractive cloze queries each with verbatim in-page answers; ingestion only, no retrieval-quality numbers reported. |
| --- | Minor | (iii)~\emph{Cross-lingual ingestion corpus}: 400 Wikipedia pages per language (English. Chinese. Japanese). 40 extractive cloze queries each with verbatim in-page answers; ingestion only. no retrieval-quality numbers reported.. |
| --- | Minor | Sentence exceeds complexity threshold, split for readability. Applying the split needs --strength moderate or higher. |
| --- | Minor | none (split proposal only; source not rewritten) |
| --- | Minor | none |
| --- | Minor | Check: NEEDS-LLM |
| --- | Minor | Flags:    not-assessed |
| --- | Minor | SENTENCE (n8a_eval.tex:64, 69 words, 6 clauses)  [Script] |
| --- | Minor | \textbf{Controls.} The deterministic retrieval lanes were re-run and compared field by field, latency excluded; the 27-cell stability suite (Section~ ) and the eighteen-arm honesty battery (Section~ ) carry repeats, whereas the 30-cell answer grid of Section~  is a single run per arm on one model, recorded in the run timeline as claude-opus-4-8[1m] with seed~0 and harness prompt v4-neutral, and is reported as such, as is its controlled replication. |
| --- | Minor | \textbf{Controls.} The deterministic retrieval lanes were re-run and compared field by field. latency excluded; the 27-cell stability suite (Section~ ) and the eighteen-arm honesty battery (Section~ ) carry repeats. whereas the 30-cell answer grid of Section~  is a single run per arm on one model. recorded in the run timeline as claude-opus-4-8[1m] with seed~0 and harness prompt v4-neutral. and is reported as such. as is its controlled replication.. |
| --- | Minor | Sentence exceeds complexity threshold, split for readability. Applying the split needs --strength moderate or higher. |
| --- | Minor | none (split proposal only; source not rewritten) |
| --- | Minor | none |
| --- | Minor | Check: NEEDS-LLM |
| --- | Minor | Flags:    not-assessed |
| --- | Minor | SENTENCE (n8a_eval.tex:81, 19 words, 4 clauses)  [Script] |
| --- | Minor | Each row names the function, the test and its scale, the observed outcome, and the subsection that reports it. |
| --- | Minor | Each row names the function. the test and its scale. the observed outcome. and the subsection that reports it.. |
| --- | Minor | Sentence exceeds complexity threshold, split for readability. Applying the split needs --strength moderate or higher. |
| --- | Minor | none (split proposal only; source not rewritten) |
| --- | Minor | none |
| --- | Minor | Check: NEEDS-LLM |
| --- | Minor | Flags:    not-assessed |
| --- | Minor | SENTENCE (n8a_eval.tex:91, 283 words, 22 clauses)  [Script] |
| --- | Minor | \begin{tabular}{@{}>{\raggedright\arraybackslash}p{0.115\textwidth}>{\raggedright\arraybackslash}p{0.265\textwidth}>{\raggedright\arraybackslash}p{0.39\textwidth}>{\raggedright\arraybackslash}p{0.10\textwidth}@{}} \toprule Function & Test and scale & Observed outcome & Where\\ \midrule Parse and ingest & 100-paper campaign; nine checks per paper & nine checks per paper, all pass; 91 names in the state file, 79 retrievable at evaluation, 21 unattributable (twelve recorded plus nine unrecorded) & E1\\ Parse quality & 50-paper, 26-domain campaign & 50/50 parsed and verified, all probes ok; 202 tags; 41 tag flags negative without blocking ingestion & E1\\ Structural split & 50 papers at the 30{,}000-character tier & 165 documents (9 whole, 156 parts) in 2{,}672\,s; storage 50/50; descriptions and tags 165/165 & E1\\ Near-duplicate review & 322-document corpus, 0.90 threshold & 35 candidate groups (0.90--0.975), zero true duplicates, nothing deleted & E2\\ Content placement & 100 papers into five libraries; 400 pages per language & 322 stored parts; membership 0.875 (en) and 1.0 (zh, ja) & E1--E2\\ Three-source consistency & Full corpus and 33-document spot check & 322/322 content and 33/33 storage; one rename defect (18 vs 9 chunks) until force re-index & E2\\ Lifecycle operations & 16 scenarios on two disposable libraries & create, move, delete and forced re-index pass; two failures (task status, update check) & E2\\ Sub-library hierarchy & Three-level disposable fixture & create, parent-to-child move, listing, reading and judging all pass & E2\\ Tags and graph & 316-tag registry; 658-node graph & 165 documents pass the tag check in 47.6\,s; four tag edges on one document move 4{,}675 to 4{,}679 & E2\\ Experience store & One small knowledge base; one end-to-end scenario & 13 candidate drafts; one lesson retrieved first at 0.711; approval path unexercised & E3\\ \bottomrule \end{tabular} \end{table*} |
| --- | Minor | \begin{tabular}{@{}>{\raggedright\arraybackslash}p{0.115\textwidth}>{\raggedright\arraybackslash}p{0.265\textwidth}>{\raggedright\arraybackslash}p{0.39\textwidth}>{\raggedright\arraybackslash}p{0.10\textwidth}@{}} \toprule Function & Test and scale & Observed outcome & Where\\ \midrule Parse and ingest & 100-paper campaign; nine checks per paper & nine checks per paper. all pass; 91 names in the state file. 79 retrievable at evaluation. 21 unattributable (twelve recorded plus nine unrecorded) & E1\\ Parse quality & 50-paper. 26-domain campaign & 50/50 parsed and verified. all probes ok; 202 tags; 41 tag flags negative without blocking ingestion & E1\\ Structural split & 50 papers at the 30{. }000-character tier & 165 documents (9 whole. 156 parts) in 2{. }672\. s; storage 50/50; descriptions and tags 165/165 & E1\\ Near-duplicate review & 322-document corpus. 0.90 threshold & 35 candidate groups (0.90--0.975). zero true duplicates. nothing deleted & E2\\ Content placement & 100 papers into five libraries; 400 pages per language & 322 stored parts; membership 0.875 (en) and 1.0 (zh. ja) & E1--E2\\ Three-source consistency & Full corpus and 33-document spot check & 322/322 content and 33/33 storage; one rename defect (18 vs 9 chunks) until force re-index & E2\\ Lifecycle operations & 16 scenarios on two disposable libraries & create. move. delete and forced re-index pass; two failures (task status. update check) & E2\\ Sub-library hierarchy & Three-level disposable fixture & create. parent-to-child move. listing. reading and judging all pass & E2\\ Tags and graph & 316-tag registry; 658-node graph & 165 documents pass the tag check in 47.6\. s; four tag edges on one document move 4{. }675 to 4{. }679 & E2\\ Experience store & One small knowledge base; one end-to-end scenario & 13 candidate drafts; one lesson retrieved first at 0.711; approval path unexercised & E3\\ \bottomrule \end{tabular} \end{table*}. |
| --- | Minor | Sentence exceeds complexity threshold, split for readability. Applying the split needs --strength moderate or higher. |
| --- | Minor | none (split proposal only; source not rewritten) |
| --- | Minor | none |
| --- | Minor | Check: NEEDS-LLM |
| --- | Minor | Flags:    not-assessed |
| --- | Minor | SENTENCE (n8a_eval.tex:134, 39 words, 5 clauses)  [Script] |
| --- | Minor | A second 50-paper, 26-domain campaign parsed and verified every paper, indexed them in batch, reported all probes ok, and left 41 of 50 documents with a negative tag flag even though verification passed, so tag-quality failures never blocked ingestion. |
| --- | Minor | A second 50-paper. 26-domain campaign parsed and verified every paper. indexed them in batch. reported all probes ok. and left 41 of 50 documents with a negative tag flag even though verification passed. so tag-quality failures never blocked ingestion.. |
| --- | Minor | Sentence exceeds complexity threshold, split for readability. Applying the split needs --strength moderate or higher. |
| --- | Minor | none (split proposal only; source not rewritten) |
| --- | Minor | none |
| --- | Minor | Check: NEEDS-LLM |
| --- | Minor | Flags:    not-assessed |
| --- | Minor | SENTENCE (n8a_eval.tex:177, 33 words, 5 clauses)  [Script] |
| --- | Minor | The tag registry held 316 tags; the tag-quality check passed 165 documents with zero failures in 47.6\,s, and orphan tags accumulate (test tags, section titles), for which a dry-run detector exists. |
| --- | Minor | The tag registry held 316 tags; the tag-quality check passed 165 documents with zero failures in 47.6\. s. and orphan tags accumulate (test tags. section titles). for which a dry-run detector exists.. |
| --- | Minor | Sentence exceeds complexity threshold, split for readability. Applying the split needs --strength moderate or higher. |
| --- | Minor | none (split proposal only; source not rewritten) |
| --- | Minor | none |
| --- | Minor | Check: NEEDS-LLM |
| --- | Minor | Flags:    not-assessed |
| --- | Minor | SENTENCE (n8b_eval.tex:9, 107 words, 6 clauses)  [Script] |
| --- | Minor | Three case measurements exist: an extraction campaign over one small knowledge base produced thirteen candidate drafts (archived \path{experience_smoke.json} in the 2026-10-13 batch tarball; \texttt{extract\_candidates}~13, \texttt{drafts\_created}~13); one end-to-end scenario was sedimented into one experience (\texttt{exp-d6f4d47ae3d6}) that a later global experience search returned first, at local similarity 0.711 (archived scenario A6 of the 2026-10-12 full-test campaign); and the draft-approval path was never exercised, because the draft pool was empty (\texttt{count}~0) and \path{experience_draft_read} and \path{experience_draft_approve} could not run; the heuristic extraction path had run only in dry-run mode, returning a dump the quality gate would reject. |
| --- | Minor | Three case measurements exist: an extraction campaign over one small knowledge base produced thirteen candidate drafts (archived \path{experience_smoke.json} in the 2026-10-13 batch tarball; \texttt{extract\_candidates}~13. \texttt{drafts\_created}~13); one end-to-end scenario was sedimented into one experience (\texttt{exp-d6f4d47ae3d6}) that a later global experience search returned first. at local similarity 0.711 (archived scenario A6 of the 2026-10-12 full-test campaign); and the draft-approval path was never exercised. because the draft pool was empty (\texttt{count}~0) and \path{experience_draft_read} and \path{experience_draft_approve} could not run; the heuristic extraction path had run only in dry-run mode. returning a dump the quality gate would reject.. |
| --- | Minor | Sentence exceeds complexity threshold, split for readability. Applying the split needs --strength moderate or higher. |
| --- | Minor | none (split proposal only; source not rewritten) |
| --- | Minor | none |
| --- | Minor | Check: NEEDS-LLM |
| --- | Minor | Flags:    not-assessed |
| --- | Minor | SENTENCE (n8b_eval.tex:32, 78 words, 5 clauses)  [Script] |
| --- | Minor | Five were measured through their own tool-layer entry points: \emph{Dense} via \texttt{kb\_search\_vector} with BGE-M3  ; \emph{Graph} via \texttt{kb\_graph\_search}, a keyword match over node names, paths and tags in the document graph; \emph{Two-stage} via \texttt{kb\_search\_two\_stage} (Section~ ); and the hybrid rows via \texttt{kb\_hybrid\_search}, an earlier server-side single-call composition of the vector, catalog and judging tools, with the gate off (\emph{Fusion-only}) and on (\emph{QDCVR-Hybrid}). |
| --- | Minor | Five were measured through their own tool-layer entry points: \emph{Dense} via \texttt{kb\_search\_vector} with BGE-M3  ; \emph{Graph} via \texttt{kb\_graph\_search}. a keyword match over node names. paths and tags in the document graph; \emph{Two-stage} via \texttt{kb\_search\_two\_stage} (Section~ ); and the hybrid rows via \texttt{kb\_hybrid\_search}. an earlier server-side single-call composition of the vector. catalog and judging tools. with the gate off (\emph{Fusion-only}) and on (\emph{QDCVR-Hybrid}).. |
| --- | Minor | Sentence exceeds complexity threshold, split for readability. Applying the split needs --strength moderate or higher. |
| --- | Minor | none (split proposal only; source not rewritten) |
| --- | Minor | none |
| --- | Minor | Check: NEEDS-LLM |
| --- | Minor | Flags:    not-assessed |
| --- | Minor | SENTENCE (n8b_eval.tex:32, 42 words, 5 clauses)  [Script] |
| --- | Minor | \emph{BM25} runs in process over the fetched full texts (jieba tokenizer,  ,  ), and \emph{RRF} fuses that ranking with the dense one at ; neither is the platform's keyword tool, so the millisecond latencies are in-process measurements rather than a server round trip. |
| --- | Minor | \emph{BM25} runs in process over the fetched full texts (jieba tokenizer. ). and \emph{RRF} fuses that ranking with the dense one at ; neither is the platform's keyword tool. so the millisecond latencies are in-process measurements rather than a server round trip.. |
| --- | Minor | Sentence exceeds complexity threshold, split for readability. Applying the split needs --strength moderate or higher. |
| --- | Minor | none (split proposal only; source not rewritten) |
| --- | Minor | none |
| --- | Minor | Check: NEEDS-LLM |
| --- | Minor | Flags:    not-assessed |
| --- | Minor | SENTENCE (n8b_eval.tex:68, 194 words, 20 clauses)  [Script] |
| --- | Minor | \resizebox{\textwidth}{!}{% \footnotesize \begin{tabular}{lcccccc} \toprule Method & Hit@5 & Recall@5 & MRR@5 & Paraphrase Hit@5 & Latency (mean) & Latency (median) \\ \midrule BM25                  & 1.00 & 1.00 & 0.958 & 0.88 & 0.9\,ms    & 1\,ms \\ Dense (BGE-M3)        & 0.94 & 0.94 & 0.856 & 0.94 & 18\,ms     & 17\,ms \\ RRF (BM25 Dense)   & 1.00 & 1.00 & 0.927 & 0.88 & 11\,ms     & 9\,ms \\ Graph (Neo4j)         & 0.56 & 0.53 & 0.562 & 0.56 & 68\,ms     & 68\,ms \\ Two-stage             & 1.00 & 0.97 & 0.927 & 0.94 & 77\,ms     & 40\,ms \\ Fusion-only           & 0.94 & 0.94 & 0.856 & 0.94 & 62\,ms     & 66\,ms \\ QDCVR-Hybrid          & 0.44 & 0.41 & 0.226 & 0.50 & 542\,ms    & 582\,ms \\ \midrule \multicolumn{7}{l}{\emph{Derived (offline, same logged hybrid pools):}}\\ \quad Judge-as-filter  & 0.94 & 0.94 & 0.856 & 0.94 & \multicolumn{2}{l}{ 542\,ms / 582\,ms} \\ \quad RRF-fuse & 0.88 & 0.88 & 0.606 & 0.88 & \multicolumn{2}{l}{(same single call)} \\ \bottomrule \end{tabular}} \par\smallskip \raggedright\small \,Derived rows replay the QDCVR-Hybrid run's own logged 12-candidate pools and judge scores, so they reuse that call's latency; the judge executes once either way. |
| --- | Minor | \resizebox{\textwidth}{!}{% \footnotesize \begin{tabular}{lcccccc} \toprule Method & Hit@5 & Recall@5 & MRR@5 & Paraphrase Hit@5 & Latency (mean) & Latency (median) \\ \midrule BM25                  & 1.00 & 1.00 & 0.958 & 0.88 & 0.9\. ms    & 1\. ms \\ Dense (BGE-M3)        & 0.94 & 0.94 & 0.856 & 0.94 & 18\. ms     & 17\. ms \\ RRF (BM25 Dense)   & 1.00 & 1.00 & 0.927 & 0.88 & 11\. ms     & 9\. ms \\ Graph (Neo4j)         & 0.56 & 0.53 & 0.562 & 0.56 & 68\. ms     & 68\. ms \\ Two-stage             & 1.00 & 0.97 & 0.927 & 0.94 & 77\. ms     & 40\. ms \\ Fusion-only           & 0.94 & 0.94 & 0.856 & 0.94 & 62\. ms     & 66\. ms \\ QDCVR-Hybrid          & 0.44 & 0.41 & 0.226 & 0.50 & 542\. ms    & 582\. ms \\ \midrule \multicolumn{7}{l}{\emph{Derived (offline. same logged hybrid pools):}}\\ \quad Judge-as-filter  & 0.94 & 0.94 & 0.856 & 0.94 & \multicolumn{2}{l}{ 542\. ms / 582\. ms} \\ \quad RRF-fuse & 0.88 & 0.88 & 0.606 & 0.88 & \multicolumn{2}{l}{(same single call)} \\ \bottomrule \end{tabular}} \par\smallskip \raggedright\small \. Derived rows replay the QDCVR-Hybrid run's own logged 12-candidate pools and judge scores. so they reuse that call's latency; the judge executes once either way.. |
| --- | Minor | Sentence exceeds complexity threshold, split for readability. Applying the split needs --strength moderate or higher. |
| --- | Minor | none (split proposal only; source not rewritten) |
| --- | Minor | none |
| --- | Minor | Check: NEEDS-LLM |
| --- | Minor | Flags:    not-assessed |
| --- | Minor | SENTENCE (n8b_eval.tex:105, 67 words, 6 clauses)  [Script] |
| --- | Minor | An earlier six-method ablation was a smoke check at  ; the scaled re-run on 2026-10-13 used ten questions (two built-in plus eight corpus golds, each verified in both substrates), crossed with the three chat-endpoint lanes (modes~A--C of Table~ ) with BM25, dense and RRF ranking, pure retrieval, no generation (\path{benchmark-suite/results/} \path{runs/run-20261013T035250Z-5f9faac/retmatrix.json}, archived as a superseded campaign in \path{superseded-20261013-batch2.tar.gz}; Table~ ). |
| --- | Minor | An earlier six-method ablation was a smoke check at  ; the scaled re-run on 2026-10-13 used ten questions (two built-in plus eight corpus golds. each verified in both substrates). crossed with the three chat-endpoint lanes (modes~A--C of Table~ ) with BM25. dense and RRF ranking. pure retrieval. no generation (\path{benchmark-suite/results/} \path{runs/run-20261013T035250Z-5f9faac/retmatrix.json}. archived as a superseded campaign in \path{superseded-20261013-batch2.tar.gz}; Table~ ).. |
| --- | Minor | Sentence exceeds complexity threshold, split for readability. Applying the split needs --strength moderate or higher. |
| --- | Minor | none (split proposal only; source not rewritten) |
| --- | Minor | none |
| --- | Minor | Check: NEEDS-LLM |
| --- | Minor | Flags:    not-assessed |
| --- | Minor | SENTENCE (n8b_eval.tex:105, 57 words, 9 clauses)  [Script] |
| --- | Minor | Document-level recall: mode~A 10/10 (mean 19.8\,s), mode~B 7/10 (14.0\,s), mode~C 9/10 (33.1\,s); BM25, dense and RRF 10/10 at  0.1\,s, so on this question set finding the gold document is not where the lanes earn their cost, and Section~  measures what they add. |
| --- | Minor | Document-level recall: mode~A 10/10 (mean 19.8\. s). mode~B 7/10 (14.0\. s). mode~C 9/10 (33.1\. s); BM25. dense and RRF 10/10 at  0.1\. s. so on this question set finding the gold document is not where the lanes earn their cost. and Section~  measures what they add.. |
| --- | Minor | Sentence exceeds complexity threshold, split for readability. Applying the split needs --strength moderate or higher. |
| --- | Minor | none (split proposal only; source not rewritten) |
| --- | Minor | none |
| --- | Minor | Check: NEEDS-LLM |
| --- | Minor | Flags:    not-assessed |
| --- | Minor | SENTENCE (n8b_eval.tex:144, 76 words, 9 clauses)  [Script] |
| --- | Minor | \centering\footnotesize \setlength{\tabcolsep}{4pt} \begin{tabular}{@{}lccc@{}} \toprule Method & Gold recall & Mean latency & Range \\ \midrule Mode A (pinned dense + judge) & 10/10 & 19.8\,s & 18--24\,s \\ Mode B (ladder)               & 7/10  & 14.0\,s & 5--20\,s \\ Mode C (hybrid)               & 9/10  & 33.1\,s & 26--44\,s \\ BM25 (corpus index)           & 10/10 &  0.05\,s & --- \\ Dense (cross-library)         & 10/10 & 0.1\,s  & --- \\ RRF (BM25 Dense)           & 10/10 &  0.05\,s & --- \\ \bottomrule \end{tabular} \end{table} |
| --- | Minor | \centering\footnotesize \setlength{\tabcolsep}{4pt} \begin{tabular}{@{}lccc@{}} \toprule Method & Gold recall & Mean latency & Range \\ \midrule Mode A (pinned dense + judge) & 10/10 & 19.8\. s & 18--24\. s \\ Mode B (ladder)               & 7/10  & 14.0\. s & 5--20\. s \\ Mode C (hybrid)               & 9/10  & 33.1\. s & 26--44\. s \\ BM25 (corpus index)           & 10/10 &  0.05\. s & --- \\ Dense (cross-library)         & 10/10 & 0.1\. s  & --- \\ RRF (BM25 Dense)           & 10/10 &  0.05\. s & --- \\ \bottomrule \end{tabular} \end{table}. |
| --- | Minor | Sentence exceeds complexity threshold, split for readability. Applying the split needs --strength moderate or higher. |
| --- | Minor | none (split proposal only; source not rewritten) |
| --- | Minor | none |
| --- | Minor | Check: NEEDS-LLM |
| --- | Minor | Flags:    not-assessed |
| --- | Minor | SENTENCE (n8b_eval.tex:160, 36 words, 4 clauses)  [Script] |
| --- | Minor | Dense retrieval with BGE-M3   misses one question (Q16), where four near-duplicate sibling reports crowd the top-5 --- a confuser-density failure, not a vocabulary one; graph search  , limited to node-name and tag matching, is the weakest standalone signal. |
| --- | Minor | Dense retrieval with BGE-M3   misses one question (Q16). where four near-duplicate sibling reports crowd the top-5 --- a confuser-density failure. not a vocabulary one; graph search. limited to node-name and tag matching. is the weakest standalone signal.. |
| --- | Minor | Sentence exceeds complexity threshold, split for readability. Applying the split needs --strength moderate or higher. |
| --- | Minor | none (split proposal only; source not rewritten) |
| --- | Minor | none |
| --- | Minor | Check: NEEDS-LLM |
| --- | Minor | Flags:    not-assessed |
| --- | Minor | SENTENCE (n8b_eval.tex:173, 50 words, 4 clauses)  [Script] |
| --- | Minor | \textbf{The measured result concerns ordering, not threshold-filter efficacy.} Three configurations use the same logged candidate pools: fusion-only keeps the original order (Hit@5 0.94), the judge-score reranker changes that order (Hit@5 0.44), and the derived filter replay retains survivors in fusion order (Hit@5 0.94). |
| --- | Minor | \textbf{The measured result concerns ordering. not threshold-filter efficacy.} Three configurations use the same logged candidate pools: fusion-only keeps the original order (Hit@5 0.94). the judge-score reranker changes that order (Hit@5 0.44). and the derived filter replay retains survivors in fusion order (Hit@5 0.94).. |
| --- | Minor | Sentence exceeds complexity threshold, split for readability. Applying the split needs --strength moderate or higher. |
| --- | Minor | none (split proposal only; source not rewritten) |
| --- | Minor | none |
| --- | Minor | Check: NEEDS-LLM |
| --- | Minor | Flags:    not-assessed |
| --- | Minor | SENTENCE (n8b_eval.tex:173, 43 words, 4 clauses)  [Script] |
| --- | Minor | On the eight questions where the derived filter and reranker differ, restoring fusion order recovers Hit@5 on all eight and loses none (exact binomial sign test, two-sided  ); Q7 moves the gold from rank three to five, while four other questions move upward. |
| --- | Minor | On the eight questions where the derived filter and reranker differ. restoring fusion order recovers Hit@5 on all eight and loses none (exact binomial sign test. two-sided  ); Q7 moves the gold from rank three to five. while four other questions move upward.. |
| --- | Minor | Sentence exceeds complexity threshold, split for readability. Applying the split needs --strength moderate or higher. |
| --- | Minor | none (split proposal only; source not rewritten) |
| --- | Minor | none |
| --- | Minor | Check: NEEDS-LLM |
| --- | Minor | Flags:    not-assessed |
| --- | Minor | SENTENCE (n8b_eval.tex:206, 63 words, 2 clauses)  [Script] |
| --- | Minor | A sweep of the recorded scores locates where filtering would begin to discriminate: cuts up to 0.70 keep every in-pool gold and about 95\% of non-golds; 0.80 keeps 16 of 17 golds while removing 21\% of non-golds; 0.85 keeps 13 of 17 and removes 40\%; at 0.88 the two retention rates converge (7 of 17 golds, 40\% of non-golds). |
| --- | Minor | A sweep of the recorded scores locates where filtering would begin to discriminate: cuts up to 0.70 keep every in-pool gold and about 95\% of non-golds; 0.80 keeps 16 of 17 golds while removing 21\% of non-golds; 0.85 keeps 13 of 17 and removes 40\%; at 0.88 the two retention rates converge (7 of 17 golds. 40\% of non-golds).. |
| --- | Minor | Sentence exceeds complexity threshold, split for readability. Applying the split needs --strength moderate or higher. |
| --- | Minor | none (split proposal only; source not rewritten) |
| --- | Minor | none |
| --- | Minor | Check: NEEDS-LLM |
| --- | Minor | Flags:    not-assessed |
| --- | Minor | SENTENCE (n8b_eval.tex:230, 24 words, 4 clauses)  [Script] |
| --- | Minor | (b)~The verdict's four roles, scored on identical candidates and identical verdict scores: fusion order, verdict as re-ranker, verdict as filter, and rank fusion. |
| --- | Minor | (b)~The verdict's four roles. scored on identical candidates and identical verdict scores: fusion order. verdict as re-ranker. verdict as filter. and rank fusion.. |
| --- | Minor | Sentence exceeds complexity threshold, split for readability. Applying the split needs --strength moderate or higher. |
| --- | Minor | none (split proposal only; source not rewritten) |
| --- | Minor | none |
| --- | Minor | Check: NEEDS-LLM |
| --- | Minor | Flags:    not-assessed |
| --- | Minor | SENTENCE (n8b_eval.tex:252, 55 words, 5 clauses)  [Script] |
| --- | Minor | \textbf{End to end, the answer grid of Section~  carries this comparison.} Its original 30 cells name the gold document in every answer, with recognized document-style markers in 9/10, 7/10 and 2/10 answers for P, F and D; its common-substrate replication gives 9/9/9, so the marker ordering is substrate-bound (Section~ ). |
| --- | Minor | \textbf{End to end. the answer grid of Section~  carries this comparison.} Its original 30 cells name the gold document in every answer. with recognized document-style markers in 9/10. 7/10 and 2/10 answers for P. F and D; its common-substrate replication gives 9/9/9. so the marker ordering is substrate-bound (Section~ ).. |
| --- | Minor | Sentence exceeds complexity threshold, split for readability. Applying the split needs --strength moderate or higher. |
| --- | Minor | none (split proposal only; source not rewritten) |
| --- | Minor | none |
| --- | Minor | Check: NEEDS-LLM |
| --- | Minor | Flags:    not-assessed |
| --- | Minor | SENTENCE (n8b_eval.tex:274, 29 words, 5 clauses)  [Script] |
| --- | Minor | On the same logged hybrid pools, verdict-score re-ranking reaches Hit@5 0.44, while a derived replay that retains fusion order among recorded survivors reaches 0.94, matching fusion-only. |
| --- | Minor | On the same logged hybrid pools. verdict-score re-ranking reaches Hit@5 0.44. while a derived replay that retains fusion order among recorded survivors reaches 0.94. matching fusion-only.. |
| --- | Minor | Sentence exceeds complexity threshold, split for readability. Applying the split needs --strength moderate or higher. |
| --- | Minor | none (split proposal only; source not rewritten) |
| --- | Minor | none |
| --- | Minor | Check: NEEDS-LLM |
| --- | Minor | Flags:    not-assessed |
| --- | Minor | SENTENCE (n8c_eval.tex:36, 242 words, 0 clauses)  [Script] |
| --- | Minor | \begin{tabular}{@{}l>{\raggedright\arraybackslash}p{0.335\textwidth}l*{9}{c}@{}} \toprule & & & \multicolumn{3}{c}{Platform (P)} & \multicolumn{3}{c}{File tools (F)} & \multicolumn{3}{c}{Dense (D)}\\ \cmidrule(lr){4-6}\cmidrule(lr){7-9}\cmidrule(lr){10-12} Q & Question (abridged) & Gold & s & a & m & s & a & m & s & a & m\\ \midrule BQ01 & Transformer attention; why recurrence is replaced & 1706.03762 & \yes & \yes & 6 & \yes & \yes & 0 & \yes & \yes & 5\\ BQ02 & NISQ definition and its central limitation & 1801.00862 & \yes & \yes & 4 & \yes & \yes & 3 & \yes & \yes & 0\\ BQ03 & MultiMedQA and Flan-PaLM on MedQA & 2212.13138 & \yes & \yes & 4 & \yes & \yes & 1 & \yes & \yes & 1\\ BQ04 & Three ontologies subdividing the Gene Ontology & 1602.01876 & \yes & \yes & 1 & \yes & \yes & 1 & \yes & \yes & 0\\ BQ05 & European growth versus Unified Growth Theory & 1512.08067 & \yes & \yes & 0 & \yes & \yes & 0 & \yes & \yes & 0\\ BQ06 & Contributions governing precipitation extremes & 1503.07557 &   & \yes & 6 & \yes & \yes & 4 & \yes & \yes & 0\\ BQ07 & MameLoshnLM and its parameter scale & 2608.05850 & \yes & \yes & 1 & \yes & \yes & 2 & \yes & \yes & 0\\ BQ08 & Oxygen redox and cathode capacity & 2408.09942 & \yes & \yes & 2 & \yes & \yes & 0 & \yes & \yes & 0\\ BQ09 & Visual SLAM in dynamic scenes (MLP-SLAM) & 2410.10669 & \yes & \yes & 2 &   & \yes & 6 & \yes & \yes & 0\\ BQ10 & Tumour control under immune evasion & 2604.01385 & \yes & \yes & 3 & \yes & \yes & 6 &   & \yes & 0\\ \midrule & \emph{All ten questions} & & 9 & 10 & 29 & 9 & 10 & 23 & 9 & 10 & 6\\ \bottomrule \end{tabular} \end{table*} |
| --- | Minor | \begin{tabular}{@{}l>{\raggedright\arraybackslash}p{0.335\textwidth}l*{9}{c}@{}} \toprule & & & \multicolumn{3}{c}{Platform (P)} & \multicolumn{3}{c}{File tools (F)} & \multicolumn{3}{c}{Dense (D)}\\ \cmidrule(lr){4-6}\cmidrule(lr){7-9}\cmidrule(lr){10-12} Q & Question (abridged) & Gold & s & a & m & s & a & m & s & a & m\\ \midrule BQ01 & Transformer attention; why recurrence is replaced & 1706.03762 & \yes & \yes & 6 & \yes & \yes & 0 & \yes & \yes & 5\\ BQ02 & NISQ definition and its central limitation & 1801.00862 & \yes & \yes & 4 & \yes & \yes & 3 & \yes & \yes & 0\\ BQ03 & MultiMedQA and Flan-PaLM on MedQA & 2212.13138 & \yes & \yes & 4 & \yes & \yes & 1 & \yes & \yes & 1\\ BQ04 & Three ontologies subdividing the Gene Ontology & 1602.01876 & \yes & \yes & 1 & \yes & \yes & 1 & \yes & \yes & 0\\ BQ05 & European growth versus Unified Growth Theory & 1512.08067 & \yes & \yes & 0 & \yes & \yes & 0 & \yes & \yes & 0\\ BQ06 & Contributions governing precipitation extremes & 1503.07557 &   & \yes & 6 & \yes & \yes & 4 & \yes & \yes & 0\\ BQ07 & MameLoshnLM and its parameter scale & 2608.05850 & \yes & \yes & 1 & \yes & \yes & 2 & \yes & \yes & 0\\ BQ08 & Oxygen redox and cathode capacity & 2408.09942 & \yes & \yes & 2 & \yes & \yes & 0 & \yes & \yes & 0\\ BQ09 & Visual SLAM in dynamic scenes (MLP-SLAM) & 2410.10669 & \yes & \yes & 2 &   & \yes & 6 & \yes & \yes & 0\\ BQ10 & Tumour control under immune evasion & 2604.01385 & \yes & \yes & 3 & \yes & \yes & 6 &   & \yes & 0\\ \midrule & \emph{All ten questions} & & 9 & 10 & 29 & 9 & 10 & 23 & 9 & 10 & 6\\ \bottomrule \end{tabular} \end{table*} |
| --- | Minor | Sentence exceeds complexity threshold, split for readability. Applying the split needs --strength moderate or higher. |
| --- | Minor | none (split proposal only; source not rewritten) |
| --- | Minor | none |
| --- | Minor | Check: NEEDS-LLM |
| --- | Minor | Flags:    not-assessed |
| --- | Minor | SENTENCE (n8c_eval.tex:58, 45 words, 7 clauses)  [Script] |
| --- | Minor | In the original grid (Table~ , \path{run-20261013T094350Z-5f9faac}), every answer names its gold document, alias-aware keyword coverage is 10/10 in every arm, strict keyword coverage is 9/10, and recognized citation-marker hits are 9/10, 7/10 and 2/10 for P, F and D. |
| --- | Minor | In the original grid (Table~. \path{run-20261013T094350Z-5f9faac}). every answer names its gold document. alias-aware keyword coverage is 10/10 in every arm. strict keyword coverage is 9/10. and recognized citation-marker hits are 9/10. 7/10 and 2/10 for P. F and D.. |
| --- | Minor | Sentence exceeds complexity threshold, split for readability. Applying the split needs --strength moderate or higher. |
| --- | Minor | none (split proposal only; source not rewritten) |
| --- | Minor | none |
| --- | Minor | Check: NEEDS-LLM |
| --- | Minor | Flags:    not-assessed |
| --- | Minor | SENTENCE (n8c_eval.tex:58, 40 words, 6 clauses)  [Script] |
| --- | Minor | In that grid gold-identifier coverage is again 10/10 in every arm, but strict coverage is 7/10, 7/10 and 8/10, alias-aware coverage 9/10, 9/10 and 10/10, and citation-marker hits 9/10 in every arm. |
| --- | Minor | In that grid gold-identifier coverage is again 10/10 in every arm. but strict coverage is 7/10. 7/10 and 8/10. alias-aware coverage 9/10. 9/10 and 10/10. and citation-marker hits 9/10 in every arm.. |
| --- | Minor | Sentence exceeds complexity threshold, split for readability. Applying the split needs --strength moderate or higher. |
| --- | Minor | none (split proposal only; source not rewritten) |
| --- | Minor | none |
| --- | Minor | Check: NEEDS-LLM |
| --- | Minor | Flags:    not-assessed |
| --- | Minor | SENTENCE (n8c_eval.tex:83, 46 words, 4 clauses)  [Script] |
| --- | Minor | The strict misses differ between grids: the original misses BQ06 in P (a Chinese answer that the declared aliases cover), BQ09 in F and BQ10 in D; the replication misses BQ06 in all three arms, BQ08 and BQ09 in P and F, and BQ10 in D. |
| --- | Minor | The strict misses differ between grids: the original misses BQ06 in P (a Chinese answer that the declared aliases cover). BQ09 in F and BQ10 in D; the replication misses BQ06 in all three arms. BQ08 and BQ09 in P and F. and BQ10 in D.. |
| --- | Minor | Sentence exceeds complexity threshold, split for readability. Applying the split needs --strength moderate or higher. |
| --- | Minor | none (split proposal only; source not rewritten) |
| --- | Minor | none |
| --- | Minor | Check: NEEDS-LLM |
| --- | Minor | Flags:    not-assessed |
| --- | Minor | SENTENCE (n8c_eval.tex:133, 58 words, 5 clauses)  [Script] |
| --- | Minor | \textbf{Abstention is a property of the reading-and-answering layer, not of a threshold.} Three out-of-corpus questions produced three explicit not-found reports (47.9, 73.3 and 113.5\,s wall clock; turns not recorded for this probe family; \path{paper-kbs/experiments/results/exp8b_absent_agent.json}), each enumerating the scope it searched (five libraries, 42 documents of the industrial corpus). |
| --- | Minor | \textbf{Abstention is a property of the reading-and-answering layer. not of a threshold.} Three out-of-corpus questions produced three explicit not-found reports (47.9. 73.3 and 113.5\. s wall clock; turns not recorded for this probe family; \path{paper-kbs/experiments/results/exp8b_absent_agent.json}). each enumerating the scope it searched (five libraries. 42 documents of the industrial corpus).. |
| --- | Minor | Sentence exceeds complexity threshold, split for readability. Applying the split needs --strength moderate or higher. |
| --- | Minor | none (split proposal only; source not rewritten) |
| --- | Minor | none |
| --- | Minor | Check: NEEDS-LLM |
| --- | Minor | Flags:    not-assessed |
| --- | Minor | SENTENCE (n8c_eval.tex:191, 36 words, 4 clauses)  [Script] |
| --- | Minor | The 131-document shelf catalog returned by the librarian's listing tool measures 74.9\,KB, above the agent engine's tool-output budget, so only a 2\,KB preview reached the model and it never saw the gold entry. |
| --- | Minor | The 131-document shelf catalog returned by the librarian's listing tool measures 74.9\. KB. above the agent engine's tool-output budget. so only a 2\. KB preview reached the model and it never saw the gold entry.. |
| --- | Minor | Sentence exceeds complexity threshold, split for readability. Applying the split needs --strength moderate or higher. |
| --- | Minor | none (split proposal only; source not rewritten) |
| --- | Minor | none |
| --- | Minor | Check: NEEDS-LLM |
| --- | Minor | Flags:    not-assessed |
| --- | Minor | SENTENCE (n8c_eval.tex:202, 33 words, 5 clauses)  [Script] |
| --- | Minor | Two further live queries exercised pagination and an unsupported cooking question, returning a sourced answer (98.5\,s, nine turns) and a not-found report after a catalog scan (39.9\,s, five turns). |
| --- | Minor | Two further live queries exercised pagination and an unsupported cooking question. returning a sourced answer (98.5\. s. nine turns) and a not-found report after a catalog scan (39.9\. s. five turns).. |
| --- | Minor | Sentence exceeds complexity threshold, split for readability. Applying the split needs --strength moderate or higher. |
| --- | Minor | none (split proposal only; source not rewritten) |
| --- | Minor | none |
| --- | Minor | Check: NEEDS-LLM |
| --- | Minor | Flags:    not-assessed |
| --- | Minor | SENTENCE (n8c_eval.tex:269, 51 words, 5 clauses)  [Script] |
| --- | Minor | \textbf{The verdict is a model  , and a second model fails the same way.} The same 191 logged (query, candidate) pairs, replayed rather than re-retrieved, went through a 330M-parameter natural-language-inference checkpoint with premises truncated to 1{,}600 characters (59 of 191 pairs at the cap) (\path{paper-kbs/experiments/results/exp7_second_signal.json}). |
| --- | Minor | \textbf{The verdict is a model. and a second model fails the same way.} The same 191 logged (query. candidate) pairs. replayed rather than re-retrieved. went through a 330M-parameter natural-language-inference checkpoint with premises truncated to 1{. }600 characters (59 of 191 pairs at the cap) (\path{paper-kbs/experiments/results/exp7_second_signal.json}).. |
| --- | Minor | Sentence exceeds complexity threshold, split for readability. Applying the split needs --strength moderate or higher. |
| --- | Minor | none (split proposal only; source not rewritten) |
| --- | Minor | none |
| --- | Minor | Check: NEEDS-LLM |
| --- | Minor | Flags:    not-assessed |
| --- | Minor | SENTENCE (n8c_eval.tex:269, 53 words, 4 clauses)  [Script] |
| --- | Minor | A span-level replay inverts harder: over the 191 pairs and 3{,}489 span inferences at roughly 320 characters per span (\path{paper-kbs/experiments/results/exp9_span_nli.json}), max-pooling gives 0.4728 for gold against 0.91855 for non-gold ( ), Hit@5 0.1875; rank fusion repairs neither signal (Hit@5 0.3125, MRR 0.111458). |
| --- | Minor | A span-level replay inverts harder: over the 191 pairs and 3{. }489 span inferences at roughly 320 characters per span (\path{paper-kbs/experiments/results/exp9_span_nli.json}). max-pooling gives 0.4728 for gold against 0.91855 for non-gold ( ). Hit@5 0.1875; rank fusion repairs neither signal (Hit@5 0.3125. MRR 0.111458).. |
| --- | Minor | Sentence exceeds complexity threshold, split for readability. Applying the split needs --strength moderate or higher. |
| --- | Minor | none (split proposal only; source not rewritten) |
| --- | Minor | none |
| --- | Minor | Check: NEEDS-LLM |
| --- | Minor | Flags:    not-assessed |
| --- | Minor | SENTENCE (n8c_eval.tex:320, 64 words, 4 clauses)  [Script] |
| --- | Minor | A concurrency sweep on the same instance (90/180/270 requests at 5/15/30 clients; supplementary material) recorded \emph{p50} rising from 5.2 to 1577\,ms, with 159 of 270 vector-only requests completing within 30\,s and the remaining 111 (41\%) hitting the client timeout; the sweep reports no HTTP errors and the timeouts are a capacity limit, not a correctness failure. |
| --- | Minor | A concurrency sweep on the same instance (90/180/270 requests at 5/15/30 clients; supplementary material) recorded \emph{p50} rising from 5.2 to 1577\. ms. with 159 of 270 vector-only requests completing within 30\. s and the remaining 111 (41\%) hitting the client timeout; the sweep reports no HTTP errors and the timeouts are a capacity limit. not a correctness failure.. |
| --- | Minor | Sentence exceeds complexity threshold, split for readability. Applying the split needs --strength moderate or higher. |
| --- | Minor | none (split proposal only; source not rewritten) |
| --- | Minor | none |
| --- | Minor | Check: NEEDS-LLM |
| --- | Minor | Flags:    not-assessed |
| --- | Minor | SENTENCE (n8c_eval.tex:351, 43 words, 5 clauses)  [Script] |
| --- | Minor | In the gate ablation, three arms shared one candidate pool (cap 12), one 4{,}000-character evidence pack and one grader (\path{paper-kbs/experiments/results/exp11_gate_ablation.json}): no gate, the gate as a filter, and a diagnostic arm receiving the judge's own segment-level pack. |
| --- | Minor | In the gate ablation. three arms shared one candidate pool (cap 12). one 4{. }000-character evidence pack and one grader (\path{paper-kbs/experiments/results/exp11_gate_ablation.json}): no gate. the gate as a filter. and a diagnostic arm receiving the judge's own segment-level pack.. |
| --- | Minor | Sentence exceeds complexity threshold, split for readability. Applying the split needs --strength moderate or higher. |
| --- | Minor | none (split proposal only; source not rewritten) |
| --- | Minor | none |
| --- | Minor | Check: NEEDS-LLM |
| --- | Minor | Flags:    not-assessed |
| --- | Minor | SENTENCE (n8c_eval.tex:351, 28 words, 4 clauses)  [Script] |
| --- | Minor | The candidate set and budget were held fixed, but downstream LLM grades varied in both directions (QK01 and QK03   under the same twelve-document, 4{,}000-character pack; sign test  ,  ). |
| --- | Minor | The candidate set and budget were held fixed. but downstream LLM grades varied in both directions (QK01 and QK03   under the same twelve-document. 4{. }000-character pack; sign test. ).. |
| --- | Minor | Sentence exceeds complexity threshold, split for readability. Applying the split needs --strength moderate or higher. |
| --- | Minor | none (split proposal only; source not rewritten) |
| --- | Minor | none |
| --- | Minor | Check: NEEDS-LLM |
| --- | Minor | Flags:    not-assessed |
| --- | Minor | SENTENCE (n8c_eval.tex:351, 25 words, 4 clauses)  [Script] |
| --- | Minor | Four of the eight gold-answerable questions (QK02, QK04, QK05, QK08) scored zero in every arm, and two others scored partial credit in one arm each. |
| --- | Minor | Four of the eight gold-answerable questions (QK02. QK04. QK05. QK08) scored zero in every arm. and two others scored partial credit in one arm each.. |
| --- | Minor | Sentence exceeds complexity threshold, split for readability. Applying the split needs --strength moderate or higher. |
| --- | Minor | none (split proposal only; source not rewritten) |
| --- | Minor | none |
| --- | Minor | Check: NEEDS-LLM |
| --- | Minor | Flags:    not-assessed |
| --- | Minor | SENTENCE (n9_discussion.tex:16, 49 words, 5 clauses)  [Script] |
| --- | Minor | The second corpus does not reproduce the collapse, so the strongest supported claim is that ranking by these checkpoints should not replace fusion order under the tested confuser density; whether confuser density itself is the cause remains an association, because the probe moved domain, language and corpus size together. |
| --- | Minor | The second corpus does not reproduce the collapse. so the strongest supported claim is that ranking by these checkpoints should not replace fusion order under the tested confuser density; whether confuser density itself is the cause remains an association. because the probe moved domain. language and corpus size together.. |
| --- | Minor | Sentence exceeds complexity threshold, split for readability. Applying the split needs --strength moderate or higher. |
| --- | Minor | none (split proposal only; source not rewritten) |
| --- | Minor | none |
| --- | Minor | Check: NEEDS-LLM |
| --- | Minor | Flags:    not-assessed |
| --- | Minor | SENTENCE (n9_discussion.tex:33, 47 words, 4 clauses)  [Script] |
| --- | Minor | In this system, the answer workflow instructs the agent to report the searched scope and say not-found when its completed evidence review finds no support; the retrieval threshold never played that role, since the graded probes retained 10 to 12 of their 12 candidates at every tier. |
| --- | Minor | In this system. the answer workflow instructs the agent to report the searched scope and say not-found when its completed evidence review finds no support; the retrieval threshold never played that role. since the graded probes retained 10 to 12 of their 12 candidates at every tier.. |
| --- | Minor | Sentence exceeds complexity threshold, split for readability. Applying the split needs --strength moderate or higher. |
| --- | Minor | none (split proposal only; source not rewritten) |
| --- | Minor | none |
| --- | Minor | Check: NEEDS-LLM |
| --- | Minor | Flags:    not-assessed |
| --- | Minor | SENTENCE (n9_discussion.tex:68, 19 words, 4 clauses)  [Script] |
| --- | Minor | More broadly, parsers, registries, indices and answer workflows benefit from post-conditions that can be checked independently of success messages. |
| --- | Minor | More broadly. parsers. registries. indices and answer workflows benefit from post-conditions that can be checked independently of success messages.. |
| --- | Minor | Sentence exceeds complexity threshold, split for readability. Applying the split needs --strength moderate or higher. |
| --- | Minor | none (split proposal only; source not rewritten) |
| --- | Minor | none |
| --- | Minor | Check: NEEDS-LLM |
| --- | Minor | Flags:    not-assessed |
| --- | Minor | SENTENCE (n9_discussion.tex:68, 40 words, 7 clauses)  [Script] |
| --- | Minor | Larger independent question sets, repeated agent trials, claim-level support assessments, a confuser-density-controlled verifier evaluation that holds corpus, language and question set fixed while varying near-duplicate density, operator studies of not-found reports and crash-recovery tests are needed before stronger deployment claims. |
| --- | Minor | Larger independent question sets. repeated agent trials. claim-level support assessments. a confuser-density-controlled verifier evaluation that holds corpus. language and question set fixed while varying near-duplicate density. operator studies of not-found reports and crash-recovery tests are needed before stronger deployment claims.. |
| --- | Minor | Sentence exceeds complexity threshold, split for readability. Applying the split needs --strength moderate or higher. |
| --- | Minor | none (split proposal only; source not rewritten) |
| --- | Minor | none |
| --- | Minor | Check: NEEDS-LLM |
| --- | Minor | Flags:    not-assessed |
| --- | Minor | SENTENCE (n11_conclusion.tex:4, 34 words, 7 clauses)  [Script] |
| --- | Minor | The management layer parses and admits documents through gates that fail visibly, places them by content, keeps document files, the tree registry and library metadata consistent, and audits rename, move, delete and re-index operations. |
| --- | Minor | The management layer parses and admits documents through gates that fail visibly. places them by content. keeps document files. the tree registry and library metadata consistent. and audits rename. move. delete and re-index operations.. |
| --- | Minor | Sentence exceeds complexity threshold, split for readability. Applying the split needs --strength moderate or higher. |
| --- | Minor | none (split proposal only; source not rewritten) |
| --- | Minor | none |
| --- | Minor | Check: NEEDS-LLM |
| --- | Minor | Flags:    not-assessed |
| --- | Minor | SENTENCE (n11_conclusion.tex:27, 46 words, 4 clauses)  [Script] |
| --- | Minor | On identical logged pools, ordering candidates by the verdict lowers Hit@5 from 0.94 to 0.44, while retaining fusion order among recorded survivors restores 0.94; all 191 recorded scores exceed the 0.5 threshold, and one additional fusion candidate has no recorded score. |
| --- | Minor | On identical logged pools. ordering candidates by the verdict lowers Hit@5 from 0.94 to 0.44. while retaining fusion order among recorded survivors restores 0.94; all 191 recorded scores exceed the 0.5 threshold. and one additional fusion candidate has no recorded score.. |
| --- | Minor | Sentence exceeds complexity threshold, split for readability. Applying the split needs --strength moderate or higher. |
| --- | Minor | none (split proposal only; source not rewritten) |
| --- | Minor | none |
| --- | Minor | Check: NEEDS-LLM |
| --- | Minor | Flags:    not-assessed |
| --- | Minor | SENTENCE (n11_conclusion.tex:36, 31 words, 5 clauses)  [Script] |
| --- | Minor | Next steps include independently curated questions, repeated agent trials, claim-level evidence-support evaluation, a confuser-density-controlled verifier evaluation, explicit execution-failure states for incomplete searches, transport stress tests and operator studies of not-found reports. |
| --- | Minor | Next steps include independently curated questions. repeated agent trials. claim-level evidence-support evaluation. a confuser-density-controlled verifier evaluation. explicit execution-failure states for incomplete searches. transport stress tests and operator studies of not-found reports.. |
| --- | Minor | Sentence exceeds complexity threshold, split for readability. Applying the split needs --strength moderate or higher. |
| --- | Minor | none (split proposal only; source not rewritten) |
| --- | Minor | none |
| --- | Minor | Check: NEEDS-LLM |
| --- | Minor | Flags:    not-assessed |
| --- | Minor | SENTENCE (main_20p.tex:82, 30 words, 6 clauses)  [Script] |
| --- | Minor | Its management layer parses and gates documents, splits long files, places documents by content rather than filename, and keeps files, registry and metadata consistent through rename, move, delete and re-index. |
| --- | Minor | Its management layer parses and gates documents. splits long files. places documents by content rather than filename. and keeps files. registry and metadata consistent through rename. move. delete and re-index.. |
| --- | Minor | Sentence exceeds complexity threshold, split for readability. Applying the split needs --strength moderate or higher. |
| --- | Minor | none (split proposal only; source not rewritten) |
| --- | Minor | none |
| --- | Minor | Check: NEEDS-LLM |
| --- | Minor | Flags:    not-assessed |

## Decision Signals

- **Committee Score**: 4.0/10
- **Editor Verdict**: Desk Reject
- **Reviewer Recommendation**: Major Revision
- **Issue Bundle**: 1 major / 0 moderate / 0 minor

## Revision Roadmap

### Priority 1 --- Must Address (Blocking)

- [ ] Abstract and conclusion claims need explicit evidence traceability ([LLM]; abstract)
