elsarticle
stfloats

fontenc
inputenc
booktabs
array
graphicx
amsmath
amssymb
xcolor
url
hyperref
xurl
caption
font=small,labelfont=bf

--

figs/
1.5em

0.90
0.85
0.08
0.75
0.90
0.75
topnumber3
bottomnumber2
totalnumber4
dbltopnumber3

7pt plus 2pt minus 2pt
9pt plus 2pt minus 2pt
7pt plus 2pt minus 2pt
7pt plus 2pt minus 2pt
9pt plus 2pt minus 2pt

Knowledge-Based Systems

document

frontmatter

QDCVR: A content-governed knowledge-base management system with
verified retrieval and reported absence

Author Namecor1
author@example.com
Co-author Name
Corresponding author.
organization=Affiliation Department, University,
City, Country, city=City, country=Country

abstract
Enterprise document collections need more than a retriever: documents must be
parsed and admitted, organized so that they can be found, and used to answer
questions whose cited evidence can be traced. We present QDCVR, a self-hosted
knowledge-base management system that treats content as the shared object
across acquisition, organization and question answering. Its management layer
parses and gates documents, splits long files at structural boundaries, places
documents by content rather than filename, and keeps files, registry and
metadata consistent through rename, move, delete and re-index. Retrieval is
one module of this system: three lanes share an invoked server-side content
verifier, and an answer workflow is instructed to report absence.
We evaluate the deployed system on three bounded corpora. On ten arXiv
questions crossed with three retrieval interfaces (30 answer cells), every
answer names its gold document, strict keyword coverage is 9/10 per interface
and alias-aware coverage 10/10, and recognized citation-marker hits are 9/10,
7/10 and 2/10. Acquisition left 21 of 100 submissions unretrievable without a
complete failure inventory, and a reproduced catalog-transport failure was
repaired and retested. In a same-pool replay on an industrial corpus, ordering
candidates by the verifier score lowers Hit@5 from 0.94 to 0.44 while fusion
order restores 0.94, so the verifier serves as an admission filter, not a
ranker. Wall-clock and cost figures do not favor the platform arm. The findings
support a bounded deployment account, not universal retrieval superiority.
abstract

keyword
Knowledge base management Document ingestion Knowledge organization 
Retrieval-augmented generation Answer quality evaluation 
Model Context Protocol
keyword

frontmatter

n1_intro
n2_related
n3_overview
n4_acquisition
n5_organization
n6_retrieval
n7_implementation
n8a_eval
n8b_eval
n8c_eval
n9_discussion
n10_threats
n11_conclusion
n_back


0.5pt plus 0.2ex
elsarticle-num
refs,refs_new_verified


document