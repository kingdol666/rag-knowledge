# Paper Summary: QDCVR: A content-governed knowledge-base management system with verified retrieval and reported absence

## Research Question
- Enterprise document collections need more than a retriever: documents must be parsed and admitted, organized so that they can be found, and used to answer questions whose cited evidence can be traced

## Core Thesis
- We present QDCVR, a self-hosted knowledge-base management system that treats content as the shared object across acquisition, organization and question answering.

## Headline Claims
- We present QDCVR, a self-hosted knowledge-base management system that treats content as the shared object across acquisition, organization and question answering.

## Section Map
- abstract (82-106): 249 words

## Closure Targets
- No closure target was extracted automatically.