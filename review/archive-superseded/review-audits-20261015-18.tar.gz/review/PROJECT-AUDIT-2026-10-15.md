# rag-knowledge 项目审计报告

**审计日期**：2026-10-15
**审计对象**：`D:/codes/ClaudeGPT/rag_project/rag-knowledge`
**审计范围**：① 项目实用性；② 自动整理入库与智能检索是否真实实现；③ 整体设计；④ 论文撰写与实现/内容的一致性
**方法**：静态代码核查（backend / kb-mcp / .claude/skills）、论文源文件比对（paper_demo 与 paper-kbs 两套）、benchmark 产物与评分脚本追溯、git 工作区状态检查

---

## 0. 结论速览

| 维度 | 结论 | 评级 |
|---|---|---|
| 工程实现真实性 | 后端核心（向量/BM25/MinerU/Neo4j/存储/MCP）**全部是真实可运行代码**，未发现桩代码 | ✅ 真实 |
| 文档自动整理入库 | **能跑通**，但"按内容归类"是 **LLM 提示词判断**，不是代码强制的确定性逻辑 | ⚠️ 真实但弱约束 |
| 智能检索 | 向量召回 + BM25 + 两阶段**真实实现**；"内容判定闸门"是**真实本地小模型**（Laya） | ✅ 真实 |
| 检索优势是否被证明 | **没有被证明**。期刊论文自认：判定闸门当**重排器**时反而**降低** Hit@5（0.94→0.44）；当过滤器时中性 | ❌ 未证实 |
| 整体设计 | 分层架构清晰、读写不对称、地址空间统一，设计水平较高 | ✅ 优秀 |
| 论文与实现一致性 | **宏观方向一致，但存在多处数字漂移、指标偏向、已弃用设计仍在主推** | ⚠️ 有实质问题 |

**一句话判断**：这是一个**真实、有工程含量、可运行**的知识库管理平台，作为"研究平台/演示系统"是成立的；但 README 与 demo 论文主推的"内容判定闸门带来检索质量提升"这一卖点，**在其自己的实验里并未得到支持，甚至方向相反**；期刊版已大幅回调口径，而 README/demo 仍停留在乐观叙事，二者已经脱节。

---

## 1. 项目整体设计

### 1.1 架构

三个服务 + 一个工具层，全部从根目录 `config.yml` 读端口与路径：

| 端口 | 服务 | 职责 |
|---:|---|---|
| 6789 | Nuxt 3 | UI + 服务端代理（浏览器不直连后端，无 CORS 面） |
| 8770 | FastAPI | 解析调度、向量、图谱、经验、SOUL |
| 动态 | MinerU OCR | 远程 API 优先，否则本地子进程 |
| 7687 | Neo4j | 文档图谱 |
| — | ChromaDB | 分块向量，每 KB 一个 collection |

**存储分层（L1–L5）**：`.tree-fs.json`（全局树）→ `.knowledge-base.yml`（每库索引）→ `.md`（正文）→ ChromaDB（向量）→ Neo4j（图）。

**设计亮点（真实存在于代码）**：
- **读写不对称**：写走 HTTP API（原子、可审计），读直读磁盘索引文件，检索零后端负载。
- **统一地址空间**：`base/document/part/section` 同时服务于组织、检索、引用 —— 这是该项目最扎实的设计思想。
- **生产级细节**：跨进程文件锁 + 原子写（`storage_reader_service.py:39`）、ChromaDB split-brain 清理、Neo4j 重试、MinerU 子进程 Job Object 生命周期绑定。

### 1.2 两个 Agent 循环

- **ORGANIZE（入库）**：PDF → MinerU 解析为结构化 Markdown → 超 30,000 字符按结构切分 → agent 读正文判定归属库 → 打标签 → 建索引。
- **RETRIEVE（检索）**：查询重写 → 逐级阶梯（L0 目录 → L1 描述 → L2 向量宽召回）→ 逐段判定闸门 → 只读存活段 → 引用作答 或 明确的 not-found 报告。

### 1.3 关键设计落差：编排靠提示词，不靠代码

`.claude/skills/knowledgebase-search/SKILL.md:32` 明确写着：

> **No orchestration scripts.** … No end-to-end runner exists or may be created.

也就是说，**"向量召回 → 判定 → librarian 回退 → not-found" 这条主流程是提示词约定**，由 agent 自觉执行；代码不会阻止 agent 跳过或违反。唯一被代码强制的环节是**判定闸门本身**（MCP 工具 `kb_laya_judge`）。

---

## 2. 实现核查：哪些是真、哪些是"名实不符"

### 2.1 真实且完整（核查通过）

| 模块 | 文件 | 证据 |
|---|---|---|
| 向量检索 | `backend/app/services/vector_service.py` | 真用 `chromadb.PersistentClient`（:53-64），真实 upsert/query |
| 嵌入模型 | `embedding_service.py` | 本地 `BAAI/bge-m3`（`sentence-transformers`，离线缓存，`models_cache/` 约 2.2GB） |
| 关键词检索 | `keyword_index_service.py` | 自研 **BM25**（jieba 分词，IDF/TF 归一化，:111-156） |
| 两阶段检索 | `two_stage_search_service.py` | Stage1 BM25+图谱扩展，Stage2 向量精排 |
| 切分 | `semantic_splitter.py` | **30,000 字符上限真实实现**（结构感知 + 字符全覆盖校验，:121/:700） |
| PDF 解析 | `mineru_service.py` + `mineru_manager.py` | 真实 MinerU HTTP 任务流 + 本地子进程 |
| 图谱 | `graph_service.py` | 真实 Neo4j Cypher（MERGE/关系/多阶段构建） |
| 存储 | `storage_reader_service.py` | 真实读写 `.tree-fs.json` / `.knowledge-base.yml`，原子写 + 文件锁 |
| MCP 服务 | `kb-mcp/server.py` | **95 个工具，其中 42 个 `kb_*`**（实测 `grep -c "^@mcp.tool()"` = 95；kb_* = 42） |

全仓扫描：`backend/app` 与 `kb-mcp` 下 **TODO / FIXME / NotImplementedError / 501 = 0**。唯一的 `mock` 是 SOUL harness 的进程内测试替身（CI 用），与 RAG 链路无关。

### 2.2 判定引擎（judgment engine）：真实，但论文描述失实

**真实的部分**：判定闸门是**真实的本地小模型**，不是 LLM API、也不是纯规则：

- 模型：`convaiinnovations/laya`（`laya` pip 包），本地检查点 `model/laya/model.safetensors`（842 MB），编码器 `answerdotai/ModernBERT-large`
- 评分：模型输出的校准概率 `noul ∈ [0,1]`，阈值默认 **0.5**，`kept = score >= threshold`（`jev_filter.py:41/:425`）
- 调用链：`kb_laya_judge`（`server.py:2862`）→ 子进程 `complete_recall.py` → `jev_filter.py`
- **fail-closed 有代码实现**：单候选出错时 `score=None, kept=False`（`jev_filter.py:430-431`）

**失实的部分**：

| 论文/README 说法 | 实现真相 | 证据 |
|---|---|---|
| "resident worker 常驻工作进程" | **每次调用新起一个 torch 子进程**，非常驻 | `server.py:2855-2857` 注释自述"each call spawns a GPU torch subprocess" |
| "50–80 ms per verdict warm" | **无任何测量**；项目自己的审计标为"纯断言"；技能文档实测 **11–15 s/批** | `benchmark-suite/scripts/165_paper_coverage_audit.py:67`；`knowledgebase-librarian/SKILL.md:23` |
| "0–8 内容评分 rubric" | **代码中不存在**。README 仍在主推，实为已被 Laya `noul`(0–1) 取代的旧设计 | `vector_jev_search.py:4` 自证"replaces the former read-content + LLM 0-8 rubric gate" |

### 2.3 内容驱动的自动归类：是 LLM 判断，不是代码

- **决策本身无代码实现**。`backend/app` 中搜索 `classify/attribution/routing` 只命中无关模块（SOUL 问答分类、OCR 引擎路由）。
- 归类是 **agent 读正文后的判断**，写在提示词里并显式标注为 🧠 judgment：
  - `knowledgebase-ingest/SKILL.md:28`："A3d KB attribution … = 🧠 judgment"
  - `knowledgebase-ingest/SKILL.md:118-126`：KB Attribution Decision Tree
  - `knowledgebase-organize/SKILL.md:76-78`：三轴相似度（tag 0.3 / entity 0.4 / domain 0.3）
- 存在的辅助脚本只做**机械校验**（切分 `split_large_doc.py`、描述审计 `audit_descriptions.py`），不做"放哪个库"的判断。

**结论**：入库"能自动跑通"，但"内容驱动"的可靠性取决于 LLM 当场表现，无确定性回退、无单元测试覆盖。

---

## 3. 论文一致性核查（重点）

仓库里其实有**两套论文 + 多个版本**，且彼此口径不一致：

| 论文 | 语料 | 主要实验 | 状态 |
|---|---|---|---|
| `paper_demo/` | 100 篇 arXiv，5 个分类库 | 3 臂 × 10 题（平台/裸agent/稠密） | CIKM '26 demo 投稿 |
| `paper-kbs/tex/journal_20p/main_20p.tex` | **三套有界语料**（含 42 篇"工业语料"） | 工具层 9 配置 + 16 端到端 + 稳健性 | KBS 期刊投稿（v2，口径已回调） |
| `paper-kbs/tex/main.md` | 同上 | 同上 | **早期可读预览，口径更激进** |

### 3.1 一致的部分

- **宏观方法描述与实现一致**：MinerU 解析、30k 切分、MCP 工具层、分层检索、fail-closed not-found —— 这些在代码里都能找到对应。
- **工具数**：`n3_overview.tex:87`、`n7_implementation.tex:9`、demo `sec2_system.tex:11` 都写 **95 工具 / 42 kb_***，与实测一致 ✅。（注：`main.md:160` 的 "97 tools" 是旧预览稿的残留，非 .tex 正文。）
- **期刊 v2 摘要已主动收紧**：明确写 "these mechanisms operate at different layers **rather than as three uniform server-enforced guarantees**"、"**does not demonstrate a threshold-filter benefit**"、"not universal retrieval superiority" —— 这是负责任的表述。

### 3.2 不一致 / 有问题的地方

**(a) README 自身矛盾，且落后于代码**

- `README.md:11` 徽章：41 个 kb_*
- `README.md:57`：42 个 kb_* / 95 总
- `README.md:335`：**94 总 / 41 kb_***（当作"当前"）
- `README.md:496` 脚注：95/42，并把 94/41 标为 superseded
- **同一份 README 里 41 与 42、94 与 95 并存。**

**(b) demo 论文的核心机制在代码中不存在**

- demo 描述的单次 `kb_hybrid_search` 服务端编排调用 —— **该工具不存在**（项目自己的实验脚本 `exp11_gate_ablation.py:788` 已记录 "kb_hybrid_search no longer exists on the live kb-mcp"）。
- 期刊 `main.md:161` 声称的 "per-lane 工具白名单强制（某 lane 物理上无法调用白名单外工具）" —— **backend 与 kb-mcp 中均无实现**；grep 只命中**认证**白名单（`auth_middleware.py`）。期刊 v2 摘要已把这条从"保证"降级为"分层机制"，属于事后修正。

**(c) demo 论文的数字已无法用当前工作区复现**

- `benchmark-suite/data/papers/qa_questions.json` **处于未提交的修改状态**（`git status` 显示 ` M`），diff 只改了 BQ06 的 gold_keywords。
- 后果：用**当前**题集重跑项目自己的 grader，**A 臂 keyword = 9/10**，而 demo 论文宏 `\NUMkwA=10` 写的是 **10/10**。
- 期刊 v2 摘要自己也承认："Under the original strict annotations, keyword coverage was **9/10 in each arm**" —— **与 demo 的 10 冲突**。

**(d) "cited" 指标天然偏向平台臂**

`scripts/107_exp_grade.py:27-41` 的 `RX_CITE` 只匹配 `part k of N` / `section|table <num>` / `§<num>`，且**只对答案文本匹配**。而平台把长文档命名为 `xxx (part 1 of 2).md` —— **A 臂 9 次命中里有 5 次仅靠自家 `(part k of N)` 命名触发**。

> 剔除 `part k of N` 后，A 臂 cited 从 9 → **4**，**反低于** B 臂（裸 agent）的 7。

也就是说，demo 的头条"cited 9/7/2 → evidence inspectability"，很大程度是**平台自身的文档命名格式**带来的，而非"平台更会引用"。脚本自己也注明 "Citation-marker presence is a **lexical proxy**, not citation correctness."

**(e) "grounded" 指标近乎恒真**

`_paper_numbers.py:196` 的 grounded = `gold_id in (answer + tool_calls + texts)`。由于**工具调用里的 doc_path 本身就含 arXiv id**，任何发生过检索的臂几乎必然 grounded → 10/10/10。脚本在 `107_exp_grade.py:233` 自认："Gold-ID coverage … is **not semantic grounding**."

**(f) 成本数字漂移**

README 与 demo 写 **$17.03**；真实 `run_manifest.json` 与逐 cell 求和均为 **$17.2454**。`verify.py` 注释自曝二者曾不一致。

**(g) 期刊自证的核心发现与 README 卖点相反**

- 期刊：判定闸门当**重排器**时 Hit@5 **0.94 → 0.44**（变差）；191 个 segment 分数**全部 > 0.5 阈值**（阈值从不区分）；same-domain evidence inflation（非金标 0.86 vs 金标 0.88，**p=0.26，无分离**）。
- README 仍写 "Vectors are fast. Content is accurate."、"A document at cosine similarity 0.95 whose content scores ≤ 4 is **discarded**" —— 把闸门当"提纯器"宣传。
- 期刊 v2 已把结论修正为"闸门的价值在**可审计性与逐引用溯源**，不在排序质量"。**README/demo 未同步这一修正。**

---

## 4. 证据链与可复现性

**值得肯定**：
- 原始 run 产物**真实**：`benchmark-suite/results/runs/run-20261013T094350Z-5f9faac/` 有 30 个真实 cell（含逐事件 timeline、工具调用、token、cost），抽查内容非占位。
- 评分**脚本化**：`scripts/107_exp_grade.py`、`161_final_evidence.py`、`_paper_numbers.py`、`TEST-RESULTS/verify.py` 四路重算，`verify.py` 是 stdlib-only 独立复算。
- 期刊实验有 23 个结果产物（`paper-kbs/experiments/results/`，含 exp1–exp12）。
- **主动披露限制**：`TEST-RESULTS/README.md` §8 写明"判分是纯正则无 LLM""成本/延迟不承诺逐字复现""语料入库不可一键重跑""这不是第三方复现"。

**可复现性缺口**：
1. 题集未提交改动 → 头条数字重算不出（见 3.2c）。
2. 期刊的**42 篇工业语料本体不在仓库内**（只有缓存 `corpus_cache.json` 与运行产物），属"deployed industrial corpus"，第三方无法重建该语料。
3. `git status` 显示 **20+ 关键文件处于未提交修改态**（含全部 skills、`kb-mcp/server.py`、`qa_questions.json`、`TEST-RESULTS/*`）—— "提交态" ≠ "当前态"。
4. README 自认 `benchmark-web/backend/results/` 的结果"no producing script"。

---

## 5. 判断与建议

### 5.1 这个项目"真正有用"吗？

**有用，但要分清用途**：
- 作为**自托管知识库管理平台**（Web UI + HTTP API + CLI + MCP 四入口，95 工具，真实的解析/向量/图谱/存储），工程完成度高，可用。
- 作为**"内容验证检索"的研究主张**，其**核心假设未被自己的实验支持**。真正的差异化是"逐引用可溯源 + 诚实的 not-found"，而非"检索更准"。

### 5.2 它能"真正实现文档自动整理入库和智能检索"吗？

- **自动入库**：✅ 流程能跑通；⚠️ 归类决策依赖 LLM 提示词，无代码强制与确定性回退。
- **智能检索**：✅ 向量 + BM25 + 两阶段真实可用；⚠️ 主流程编排是提示词，判定闸门虽真实但**收益未证实**（期刊显示当重排器时为负收益）。

### 5.3 建议（按优先级）

**P0 — 必须先修正的诚信问题**
1. 统一 README 的工具数（95/42），删除 41/94 与已弃用的 0–8 rubric 段落，或明确标注"历史设计"。
2. 决定 demo 论文 A 臂 keyword 用 9 还是 10；**把 `qa_questions.json` 的改动提交或回退**，使论文宏与产物一致。
3. README 的成本改回 $17.25（或说明口径）。

**P1 — 指标与方法**
4. "cited" 指标应剔除平台自定义的 `(part k of N)` 命名，或对三臂统一可比的引用口径；否则结论不成立。
5. "grounded" 应改为只对**答案文本**匹配 gold id（当前含工具轨迹，近乎恒真）。
6. demo 论文的"判定闸门提升质量"叙事应与期刊结论对齐：**价值在溯源，不在排序**。

**P2 — 设计与实现**
7. 把"分层检索 + not-found 契约"从提示词提升为**代码编排**（有明确的阶段状态机与预算），否则"enforced"不成立。
8. 补齐或撤回"resident worker / 50–80 ms"等无测量的性能主张。
9. 工业语料（42 篇）若能脱敏随仓库发布，会显著提升期刊实验的可复现性。

---

## 附：本次审计的关键证据索引

| 结论 | 证据位置 |
|---|---|
| 95 工具 / 42 kb_* | `kb-mcp/server.py`（`grep -c "^@mcp.tool()"`=95；kb_*=42） |
| 编排无脚本 | `.claude/skills/knowledgebase-search/SKILL.md:32` |
| 0–8 rubric 已弃用 | `.claude/skills/knowledgebase-search/scripts/vector_jev_search.py:4` |
| Laya 本地模型 | `model/laya/model.safetensors`；`.claude/skills/knowledgebase-librarian/scripts/jev_filter.py:40,124,240,425,430` |
| 判定非常驻 | `kb-mcp/server.py:2839,2855-2857` |
| "50-80ms 纯断言" | `benchmark-suite/scripts/165_paper_coverage_audit.py:67` |
| 两阶段无 LLM 判定 | `backend/app/services/two_stage_search_service.py`（无 judge 调用） |
| 归类靠提示词 | `.claude/skills/knowledgebase-ingest/SKILL.md:28,118-126` |
| cited 正则 | `benchmark-suite/scripts/107_exp_grade.py:27-41` |
| grounded 含工具轨迹 | `benchmark-suite/scripts/_paper_numbers.py:185-196` |
| 期刊 Hit@5 0.94→0.44 | `paper-kbs/tex/journal_20p/main_20p.tex`（摘要）；`paper-kbs/tex/main.md`（RQ2） |
| 题集未提交改动 | `git status` → ` M benchmark-suite/data/papers/qa_questions.json` |
| 成本 $17.2454 | `benchmark-suite/results/runs/run-20261013T094350Z-5f9faac/run_manifest.json` |
