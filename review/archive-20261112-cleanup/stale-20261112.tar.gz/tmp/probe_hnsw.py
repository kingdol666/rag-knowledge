# -*- coding: utf-8 -*-
"""Read-only QDCVR lane for the HNSW ef_search question."""
import json
import sys
from pathlib import Path

REPO = Path(r"D:\codes\ClaudeGPT\rag_project\rag-knowledge")
sys.path.insert(0, str(REPO / "benchmark-suite" / "scripts"))
from lib import McpClient  # noqa: E402

KB = "5bc21b9b-2a05-470a-9cd6-eaafedfb87a2"
c = McpClient(REPO)

try:
    st = c.call("kb_project_status")
    print("PREFLIGHT ready:", st.get("ready"), "|", st.get("summary"))

    q = "HNSW ef_search 线上推荐起步值；索引重建验收基线 baseline 与回滚线 rollback 阈值"
    print("\n=== kb_search_vector (whole library, rewritten query) ===")
    v = c.call("kb_search_vector", {
        "query": q, "kb_id": "", "top_k": 30,
        "score_threshold": 0.35, "balance_kbs": True, "slim": True,
    }, timeout=300)
    hits = v.get("results") or v.get("chunks") or []
    print("hits:", len(hits))
    seen = {}
    for h in hits:
        p = (h.get("doc_path") or h.get("path") or "").replace("\\", "/")
        s = h.get("score") or h.get("similarity") or 0
        if p not in seen or s > seen[p][0]:
            seen[p] = (s, h.get("kb_id"))
    for p, (s, kid) in sorted(seen.items(), key=lambda x: -x[1][0]):
        print(f"  {round(s,4)} | {kid} | {p}")

    for dp in ["AI 基础设施/vector-index-tuning-guide (part 1 of 2).md",
               "AI 基础设施/vector-index-tuning-guide (part 2 of 2).md"]:
        r = c.call("kb_doc_read", {"kb_id": KB, "doc_path": dp, "max_chars": 600}, timeout=120)
        txt = r.get("content") or r.get("text") or json.dumps(r, ensure_ascii=False)
        print(f"\n=== kb_doc_read {dp} (first 400 chars) ===")
        print(txt[:400].replace("\n", " / "))

    s = c.call("kb_search_stats", {"kb_id": KB})
    print("\n=== kb_search_stats ===")
    print(json.dumps(s, ensure_ascii=False)[:800])
finally:
    c.close()
