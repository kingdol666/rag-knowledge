#!/usr/bin/env python3
"""Run the real Laya Jev gate over the full wc1 manifest, sharded by kb_id.

Splits tmp/candidates-wc1.json into one slice per kb_id, runs the real
laya_sdk engine per slice (calling jev_filter.main directly with
--require-real so an unavailable engine exits non-zero), then merges all
slices into tmp/judged-wc1.json in the canonical output shape.
"""
from __future__ import annotations

import json
import pathlib
import subprocess
import sys

REPO = pathlib.Path(__file__).resolve().parents[1]
JEV = REPO / ".claude" / "skills" / "knowledgebase-librarian" / "scripts" / "jev_filter.py"
SRC = REPO / "tmp" / "candidates-wc1.json"
MERGE = REPO / "tmp" / "judged-wc1.json"
WORK = REPO / "tmp" / "wc1_shards"
PY = sys.executable


def main() -> int:
    payload = json.loads(SRC.read_text(encoding="utf-8"))
    candidates = payload["candidates"]
    shards: dict[str, list[dict]] = {}
    for cand in candidates:
        shards.setdefault(str(cand.get("kb_id") or "unknown"), []).append(cand)
    WORK.mkdir(parents=True, exist_ok=True)

    slices: list[tuple[str, pathlib.Path, pathlib.Path]] = []
    for index, (kb_id, items) in enumerate(sorted(shards.items())):
        inp = WORK / f"in-{index:02d}.json"
        outp = WORK / f"out-{index:02d}.json"
        inp.write_text(json.dumps({**payload, "candidates": items}, ensure_ascii=False),
                       encoding="utf-8")
        slices.append((kb_id, inp, outp))

    procs = []
    for index, (kb_id, inp, outp) in enumerate(slices):
        print(f"start shard {index:02d} kb={kb_id} n={len(shards[kb_id])}", flush=True)
        procs.append((index, kb_id, outp, subprocess.Popen(
            [PY, str(JEV), "--engine", "laya", "--input", str(inp),
             "--output", str(outp), "--require-real"],
            cwd=REPO)))

    scored: list[dict] = []
    survivors: list[dict] = []
    errors: list[dict] = []
    statuses: dict[str, str] = {}
    for index, kb_id, outp, proc in procs:
        code = proc.wait()
        if not outp.exists():
            print(f"shard {index:02d} kb={kb_id} exit={code} MISSING OUTPUT", flush=True)
            errors.append({"candidate_id": f"shard-{index:02d}", "error": f"no output exit={code}"})
            statuses[kb_id] = "unavailable"
            continue
        result = json.loads(outp.read_text(encoding="utf-8"))
        statuses[kb_id] = str(result.get("status"))
        scored.extend(result.get("scores") or [])
        survivors.extend(result.get("survivors") or [])
        errors.extend(result.get("errors") or [])
        print(f"shard {index:02d} kb={kb_id} exit={code} status={result.get('status')} "
              f"scored={len(result.get('scores') or [])} kept={len(result.get('survivors') or [])}",
              flush=True)

    merged = {
        "status": "ok" if not errors else "error",
        "engine": "laya",
        "backend": "laya_sdk",
        "real_engine": True,
        "real_jev": False,
        "criterion": "instance",
        "threshold": 0.5,
        "candidate_count": len(candidates),
        "scored_count": len(scored),
        "kept_count": len(survivors),
        "shard_statuses": statuses,
        "scores": scored,
        "result_list": survivors,
        "survivors": survivors,
        "errors": errors,
    }
    MERGE.write_text(json.dumps(merged, ensure_ascii=False, indent=1), encoding="utf-8")
    print(f"MERGED scored={len(scored)}/{len(candidates)} kept={len(survivors)} "
          f"errors={len(errors)} -> {MERGE}", flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
