import json
p = r"D:\codes\ClaudeGPT\rag_project\rag-knowledge\tmp\candidates-ragweak.json"
d = json.load(open(p, encoding="utf-8"))
if isinstance(d, dict):
    print("keys:", list(d.keys()))
    for k, v in d.items():
        if isinstance(v, list):
            print(f"{k}: list[{len(v)}]")
            if v and isinstance(v[0], dict):
                print("  [0] keys:", list(v[0].keys()))
        elif isinstance(v, dict):
            print(f"{k}: dict {list(v.keys())[:20]}")
        else:
            print(f"{k}: {repr(v)[:200]}")
else:
    print(type(d), len(d) if hasattr(d, "__len__") else "?")
