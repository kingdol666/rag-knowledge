﻿import json, pathlib
repo = pathlib.Path(r"D:\codes\ClaudeGPT\rag_project\rag-knowledge")
storage = repo / "storage" / "tree-file-system"
man = json.loads((repo / "tmp" / "candidates-wc1.json").read_text(encoding="utf-8"))
covered = {c["doc_path"] for c in man["candidates"]}
disk = []
for p in sorted(storage.rglob("*.md")):
    rel = p.relative_to(storage)
    if "images" in rel.parts:
        continue
    disk.append(str(rel))
missing = [d for d in disk if d not in covered]
print(f"disk_md={len(disk)} covered={len(covered)} missing={len(missing)}")
for m in missing:
    print("  MISSING:", m)
# extra docs in manifest read from disk subfolders not in MCP catalog
print("--- manifest kb dirs ---")
import collections
cnt = collections.Counter(c["doc_path"].split("\\")[0] for c in man["candidates"])
for k, v in sorted(cnt.items()):
    print(f"  {k}: {v} segments")
