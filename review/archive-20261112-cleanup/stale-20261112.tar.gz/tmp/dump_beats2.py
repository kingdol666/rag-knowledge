import json, re

p = r"D:\codes\ClaudeGPT\rag_project\rag-knowledge\tmp\judged-ragweak.json"
d = json.load(open(p, encoding="utf-8"))
surv = d["survivors"]

def part_of(doc):
    m = re.search(r"part (\d+) of 26", doc)
    return int(m.group(1)) if m else 999

by_part = {}
for r in surv:
    by_part.setdefault(part_of(r["doc_path"]), []).append(r)

out = []

# 1) full dump of every part9 survivor segment (Collins->Charlotte wording)
out.append("################ FULL DUMP part9 ################\n")
for r in sorted(by_part.get(9, []), key=lambda x: x["start_char"]):
    out.append(f"\n===== part9 L{r['start_line']}-{r['end_line']} jev={r['score']:.4f} =====\n")
    out.append(r["text"][:3000])
    out.append("\n")

# 2) scan all survivors for offer-phrases
PATS = [
    ("offer_marriage", r"offer of marriage"),
    ("make_offer", r"(make|made|making) (her|me|him) an offer|(made|make) an offer"),
    ("proposed_to", r"proposed to"),
    ("his_proposals", r"(his|my) proposals"),
    ("felicity2", r"felicity which"),
]
compiled = [(n, re.compile(pat, re.I)) for n, pat in PATS]
out.append("\n\n################ OFFER-PHRASE SCAN ################\n")
for name, rx in compiled:
    out.append(f"\n### {name}:")
    seen = set()
    for r in sorted(surv, key=lambda x: (part_of(x["doc_path"]), x["start_char"])):
        t = r.get("text") or ""
        for m in rx.finditer(t):
            s = max(0, m.start() - 200); e = min(len(t), m.end() + 240)
            ctx = t[s:e].replace("\n", " ")
            h = ctx[:90]
            if h in seen: continue
            seen.add(h)
            out.append(f"  [part{part_of(r['doc_path'])} L{r['start_line']}-{r['end_line']} jev={r['score']:.3f}] {ctx}")

# 3) specific check segments (full text)
CHECK = {5: [314, 427], 7: [148], 10: [227, 284], 11: [210], 14: [94],
         15: [191], 22: [568], 24: [28], 25: [52, 216]}
out.append("\n\n################ CHECK SEGMENTS FULL ################\n")
for part, lines in CHECK.items():
    for line in lines:
        for r in by_part.get(part, []):
            if r["start_line"] <= line <= r["end_line"]:
                out.append(f"\n===== part{part} L{r['start_line']}-{r['end_line']} jev={r['score']:.4f} =====\n")
                out.append(r["text"][:2200])
                out.append("\n")

open(r"D:\codes\ClaudeGPT\rag_project\rag-knowledge\tmp\dump_beats2.txt", "w", encoding="utf-8").write("".join(out))
print("written", sum(len(x) for x in out))
