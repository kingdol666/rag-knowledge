# -*- coding: utf-8 -*-
"""Detached wrapper: run hybrid_search.py with a clean argv (no shell quoting)."""
import subprocess
import sys
from pathlib import Path

REPO = Path(__file__).resolve().parents[1]
CMD = [
    sys.executable,
    str(REPO / ".claude/skills/knowledgebase-hybrid/scripts/hybrid_search.py"),
    "--query", "marriage proposal refused accepted pride and prejudice",
    "--extra-terms", "proposal propose marriage Darcy Elizabeth Collins Jane Bingley rejected accepted",
    "--peek-heads",
    "--top-k-floor", "3",
    "--lane-agreement",
    "--doc-budget", "6",
    "--stem-max-parts", "26",
    "--peek-limit", "20",
    "--engine", "laya",
    "--require-real",
    "--output", str(REPO / "tmp" / "hybrid-loop.json"),
]
proc = subprocess.run(CMD, cwd=str(REPO), capture_output=True, text=True,
                      encoding="utf-8", errors="replace", timeout=1800)
out = REPO / "tmp" / "hybrid-loop.out"
err = REPO / "tmp" / "hybrid-loop.err"
out.write_text(proc.stdout or "", encoding="utf-8")
err.write_text((proc.stderr or "") + f"\n[wrapper] rc={proc.returncode}\n", encoding="utf-8")
