#!/usr/bin/env python3
"""Final demo: strict ladder over a REAL hierarchy (parent → sub-KBs → docs → judge).
Builds a throwaway 3-level sandbox, walks the ladder the way the librarian skill
mandates, prints each level's return size, then cleans up."""
import json, subprocess, sys, time

REPO = r"D:\codes\ClaudeGPT\rag_project\rag-knowledge"
S = str(int(time.time()))
Q = "如何把 BM25 和稠密向量两路检索的结果融合？"  # answer lives in sub-KB A


def mcp(tool, payload, timeout=300):
    r = subprocess.run([sys.executable, "scripts/mcp_call.py", tool,
                        json.dumps(payload, ensure_ascii=False), "--raw"],
                       capture_output=True, text=True, encoding="utf-8", cwd=REPO, timeout=timeout)
    out = (r.stdout or "").strip()
    if r.returncode != 0 or not out:
        raise RuntimeError(f"{tool}: {(r.stderr or out)[:200]}")
    return json.loads(out)


def sz(d):
    return len(json.dumps(d, ensure_ascii=False))


ids = []
try:
    # ---- build sandbox: parent + 2 sub-KBs + docs ----
    pid = mcp("kb_create", {"name": f"阶梯终验父库-{S}",
        "description": "终验父库：信息检索与电池材料两个子域。收录范围见各子库描述，本层不存正文。"})["knowledgeBase"]["id"]
    ids += [pid]
    said = mcp("kb_create", {"name": f"阶梯终验父库-检索算法-{S}",
        "description": "检索算法子库：RRF 融合、交叉编码器重排、BM25 调优。可回答多路召回合并与精排问题。",
        "parent_id": pid})["knowledgeBase"]["id"]
    sbid = mcp("kb_create", {"name": f"阶梯终验父库-电池材料-{S}",
        "description": "电池材料子库：硅碳负极首效/循环/膨胀控制。可回答高能量密度电池设计问题。",
        "parent_id": pid})["knowledgeBase"]["id"]
    ids += [said, sbid]
    mcp("kb_doc_create", {"kb_id": said, "name": "rrf-fusion.md",
        "description": "RRF 倒数排名融合：score=Σ1/(k+rank)，k=60，BM25+稠密向量双路合并无需调权，HotpotQA 实测优于加权求和。中文。",
        "content": "# RRF 倒数排名融合\n\nRRF（Reciprocal Rank Fusion）：score(d)=Σ 1/(k+rank_i(d))，k=60。\n将 BM25 与稠密向量两路召回按排名倒数融合，无需调权重，HotpotQA 实测优于加权分数求和。"})
    mcp("kb_doc_create", {"kb_id": said, "name": "cross-encoder.md",
        "description": "交叉编码器重排：bge-reranker 对 query-doc 逐对打分，top50→top5，NDCG@5 +12%。中文。",
        "content": "# 交叉编码器重排\n\n两阶段检索的第二阶段：bge-reranker 精排，NDCG@5 提升 12%。"})
    mcp("kb_doc_create", {"kb_id": sbid, "name": "si-c-anode.md",
        "description": "硅碳负极：首效 88%、1000 圈保持 80%、多孔碳骨架控膨胀。中文。",
        "content": "# 硅碳负极\n\n首效 88%，1000 圈循环保持率 80%，多孔碳骨架缓冲 300% 体积膨胀。"})
    for kb, doc in ((said, "rrf-fusion.md"), (said, "cross-encoder.md"), (sbid, "si-c-anode.md")):
        mcp("kb_index_document", {"kb_id": kb, "doc_path": doc})
    time.sleep(1)
    print(f"sandbox ready: parent={pid[:8]} subA={said[:8]} subB={sbid[:8]}\n")

    # ---- THE LADDER ----
    total_chars = 0
    # L0: root catalog only
    l0 = mcp("kb_list", {"lightweight": True, "parent_id": "__root__"})
    total_chars += sz(l0)
    parent = next(kb for kb in l0["catalog"] if "阶梯终验父库" in kb["name"])
    print(f"[L0] 根库目录 {l0['count']} 库 ({sz(l0)} chars) → 命中父库「{parent['name']}」 desc={parent['description'][:40]}…")

    # L0.5 level 1: sub-KBs only
    lv1 = mcp("kb_list", {"lightweight": True, "parent_id": pid})
    total_chars += sz(lv1)
    kids = lv1["catalog"]
    print(f"[L0.5·层1] 父库子库 {lv1['count']} 个 ({sz(lv1)} chars):")
    for k in kids:
        print(f"      - {k['name']}  desc={k['description'][:42]}…")
    pick = next(k for k in kids if "检索算法" in k["description"] or "RRF" in k["description"])
    print(f"      → 判定命中「{pick['name']}」")

    # L0.5 level 2: recurse — does the pick have children?
    lv2 = mcp("kb_list", {"lightweight": True, "parent_id": pick["kb_id"]})
    total_chars += sz(lv2)
    assert lv2["count"] == 0, "unexpected deeper level"
    print(f"[L0.5·层2] 「{pick['name'][:24]}」无子库 ({sz(lv2)} chars) → 叶子书架，进入文档层")

    # L1: leaf docs (single call; verify container tagging on parent listing too)
    pl = mcp("kb_get_documents", {"kb_id": pid, "lightweight": True})
    containers = [e for e in pl["catalog"] if e.get("entry_type") == "sub_kb"]
    assert len(containers) == 2 and all(c["description"] for c in containers), "container tagging failed"
    print(f"[容器打标] 父库清单同屏可见 2 个 entry_type=sub_kb 容器（各带子库描述）✓")
    docs = mcp("kb_get_documents", {"kb_id": pick["kb_id"], "lightweight": True})
    total_chars += sz(docs)
    cands = [d for d in docs["catalog"] if not d.get("entry_type")]
    print(f"[L1] 叶子文档层 {docs['count']} 篇 ({sz(docs)} chars):")
    for d in cands:
        print(f"      - {d['name']}  desc={d['description'][:46]}…")

    # L3: judge candidates (navigation complete FIRST)
    jd = mcp("kb_laya_judge", {"query": Q, "criterion": "evidence",
                                "documents": json.dumps([{"kb_id": pick["kb_id"], "doc_path": d["doc_path"]} for d in cands], ensure_ascii=False)})
    total_chars += sz({k: jd.get(k) for k in ("status", "scored_count", "survivor_count")})
    print(f"[L3] judge: {jd.get('scored_count')} 段评分 / {jd.get('survivor_count')} 幸存 ({sz(jd)} chars 摘要)")

    # L4: read survivor
    survivors = jd.get("survivors") or []
    target = survivors[0]["doc_path"] if survivors else "rrf-fusion.md"
    rd = mcp("kb_doc_read", {"kb_id": pick["kb_id"], "doc_path": target.replace("\\", "/"), "max_chars": 1500})
    ok = "RRF" in rd.get("content", "") and "60" in rd.get("content", "")
    print(f"[L4] 精读 {target} → 内容确认={ok}")
    print(f"\n=== 阶梯收敛: 根库→子库层1→叶子→文档→judge→精读 | 描述层总字节 {total_chars} chars ===")
    sys.exit(0 if ok else 1)
finally:
    for sid in reversed(ids):
        try:
            mcp("kb_delete", {"kb_id": sid})
        except Exception as e:
            print("cleanup warn:", str(e)[:80])
    print("sandbox cleaned")
