# Drive backend semantic_splitter.plan_split for weicheng_novel.md (same cfg as split_large_doc.py)
import json
import sys
from pathlib import Path

REPO = Path(r"D:\codes\ClaudeGPT\rag_project\rag-knowledge")
sys.path.insert(0, str(REPO / "backend"))

from app.services.semantic_splitter import plan_split  # noqa: E402

SRC = REPO / "tmp" / "weicheng-src" / "weicheng_novel.md"
OUT = REPO / "tmp" / "weicheng-ingest"

cfg = {
    "auto_split": True,
    "max_chars": 30000,
    "overlap_chars": 0,
    "strategy": "agent_semantic",
    "target_utilization": 0.85,
    "allow_oversized_atomic_unit": True,
    "allow_hard_fallback": False,
}
content = SRC.read_text(encoding="utf-8")
OUT.mkdir(parents=True, exist_ok=True)
result = plan_split(content, SRC.stem, cfg)
print(json.dumps({
    "success": True,
    "split": result.get("split"),
    "part_count": result.get("part_count") or len(result.get("parts") or []),
    "units": len(result.get("units") or []),
    "source_sha256": result.get("source_sha256", "")[:16],
}, ensure_ascii=False))
for p in result.get("parts") or []:
    name = f"weicheng_novel (part {p['part_index']} of {p['part_count']}).md"
    (OUT / name).write_text(str(p["content"]), encoding="utf-8")
    print(f"part {p['part_index']}/{p['part_count']}: chars={p.get('chars')} heading={p.get('heading_path') or ''}"[:160])
