﻿import pathlib
try:
    import fitz
    pdf = r"D:\codes\ClaudeGPT\rag_project\rag-knowledge\paper_demo\reference\cikm-demo__2606.19646__safe-cascade-cost-adaptive-vision-langua.pdf"
    doc = fitz.open(pdf)
    found = False
    for i, page in enumerate(doc):
        t = page.get_text()
        if "围城" in t:
            idx = t.find("围城")
            print("page", i, ":", t[max(0,idx-120):idx+160].replace("\n", " "))
            found = True
            break
    if not found: print("no 围城 in extracted text (byte hit may be binary noise)")
except Exception as e:
    print("err", e)
