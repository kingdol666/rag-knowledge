﻿import pathlib, re, json
repo = pathlib.Path(r"D:\codes\ClaudeGPT\rag_project\rag-knowledge")
p1 = repo / "benchmark-web" / "benchmark" / "data" / "miracl" / "pages-cache-zh.json"
try:
    raw = p1.read_text(encoding="utf-8", errors="ignore")
    idx = raw.find("围城")
    print("MIRACL ctx:", raw[max(0,idx-200):idx+260].replace("\n"," "))
except Exception as e:
    print("miracl err", e)
