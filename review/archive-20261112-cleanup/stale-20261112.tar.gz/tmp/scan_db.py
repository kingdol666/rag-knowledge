﻿import pathlib
repo = pathlib.Path(r"D:\codes\ClaudeGPT\rag_project\rag-knowledge")
TOKENS = ["围城","方鸿渐","苏文纨","唐晓芙","孙柔嘉","鲍小姐","赵辛楣","三闾大学","克莱登","Fortress Besieged"]
ENC = ("utf-8","gbk","utf-16")
targets = []
for pat in ("chroma_db","**/chroma_db"):
    targets += list(repo.glob(pat))
targets += list(repo.glob("*.db")) + list(repo.glob("*.sqlite*"))
targets += list(repo.glob("backend/logs/*")) + list(repo.glob("storage/*.db")) + list(repo.glob("storage/**/*.db"))
targets += list(repo.glob(".omc/**/*")) if (repo/".omc").exists() else []
seen = set(); hits = 0; scanned = 0
for t in targets:
    if not t.exists(): continue
    files = [t] if t.is_file() else [p for p in t.rglob("*") if p.is_file()]
    for p in files:
        key = str(p)
        if key in seen: continue
        seen.add(key)
        try:
            if p.stat().st_size > 200_000_000: continue
            raw = p.read_bytes()
        except OSError: continue
        scanned += 1
        found = []
        for tok in TOKENS:
            for enc in ENC:
                try:
                    if tok.encode(enc) in raw: found.append(tok); break
                except (UnicodeEncodeError, LookupError): continue
        if found:
            hits += 1
            print("HIT", p.relative_to(repo), found)
print(f"scanned_files={scanned} hit_files={hits}")
