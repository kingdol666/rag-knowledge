import json, re
from collections import defaultdict

p = r"D:\codes\ClaudeGPT\rag_project\rag-knowledge\tmp\judged-ragweak.json"
d = json.load(open(p, encoding="utf-8"))
surv = d["survivors"]
cand = json.load(open(r"D:\codes\ClaudeGPT\rag_project\rag-knowledge\tmp\candidates-ragweak.json", encoding="utf-8"))["candidates"]

def key(doc):
    m = re.search(r"part (\d+) of 26", doc)
    return int(m.group(1)) if m else 999

# per-doc candidate coverage
def stats(lst, name):
    g = defaultdict(list)
    for r in lst:
        g[r["doc_path"]].append((r["start_line"], r["end_line"], r.get("score")))
    print(f"\n== {name} per-doc coverage ==")
    for doc in sorted(g, key=key):
        rows = sorted(g[doc])
        last_end = max(r[1] for r in rows)
        print(f"  {doc.split('/')[-1]:55s} n={len(rows):3d} maxLine={last_end}")

stats(cand, "CANDIDATES (288)")
stats(surv, "SURVIVORS (284)")

# part22(2of2) full survivors
print("\n== part22(2of2) survivors ==")
for r in surv:
    if "part 22 of 26) (part 2 of 2" in r["doc_path"]:
        print(f"L{r['start_line']}-{r['end_line']} jev={r['score']:.4f}")
        print(r["text"])

# candidates of part22(1of2) trailing lines to see split point
print("\n== part22(1of2) candidate max line ==")
for r in cand:
    if "part 22 of 26) (part 1 of 2" in r["doc_path"]:
        pass
mx = max((r["end_line"] for r in cand if "part 22 of 26) (part 1 of 2" in r["doc_path"]), default=0)
print("max end_line part22(1of2):", mx)

# search survivors for the Bingley-engagement narration
PATS = [r"happiest creature", r"most fortunate creature", r"engaged to (Mr\.? )?Bingley",
        r"received his addresses", r"he has made me", r"unsettled (her|my) mind",
        r"Jane[^.]{0,80}(his|the) addresses", r"engagement.{0,60}Bingley"]
print("\n== BINGLEY-ENGAGEMENT NARRATION SEARCH (survivors) ==")
for pat in PATS:
    rx = re.compile(pat, re.I)
    for r in sorted(surv, key=lambda x: (key(x["doc_path"]), x["start_char"])):
        t = r.get("text") or ""
        for m in rx.finditer(t):
            s = max(0, m.start()-200); e = min(len(t), m.end()+240)
            print(f"  [{pat}] part{key(r['doc_path'])} L{r['start_line']}-{r['end_line']}: ...{t[s:e].replace(chr(10),' ')}...")
            break
