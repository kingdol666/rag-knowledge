# -*- coding: utf-8 -*-
"""Timing + real-engine probe for the local Laya filter on the built manifest."""
from __future__ import annotations

import json
import sys
import time
from pathlib import Path

REPO = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(REPO / ".claude" / "skills" / "knowledgebase-librarian" / "scripts"))
from jev_filter import criterion_for, laya_score  # noqa: E402

payload = json.loads((REPO / "tmp" / "candidates-ragweak.json").read_text(encoding="utf-8"))
query = payload["query"]
crit = criterion_for(query)
print("criterion:", crit)
times: list[float] = []
for i, c in enumerate(payload["candidates"][:5]):
    t1 = time.time()
    score, meta = laya_score(query, c["text"], crit)
    dt = time.time() - t1
    times.append(dt)
    print(f"seg{i} score={score:.4f} t={dt:.2f}s chars={len(c['text'])} id={c['candidate_id'][-60:]}")
print("first_call_incl_model_load=%.1fs" % times[0])
if len(times) > 1:
    print("per_seg_after_load=%.2fs avg" % (sum(times[1:]) / len(times[1:])))
