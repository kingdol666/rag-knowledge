#!/usr/bin/env python3
"""Re-run any wc1 shard that did not complete cleanly, then merge everything.

A shard is considered clean when its output exists, status == "ok", and every
score is non-null. Failed shards are re-run SERIALLY (one Laya process at a
time) to stay within the Windows pagefile budget. Then all shard outputs are
merged into tmp/judged-wc1.json.
"""
from __future__ import annotations

import json
import pathlib
import subprocess
import sys

REPO = pathlib.Path(__file__).resolve().parents[1]
JEV = REPO / ".claude" / "skills" / "knowledgebase-librarian" / "scripts" / "jev_filter.py"
SRC = REPO / "tmp" / "candidates-wc1.json"
WORK = REPO / "tmp" / "wc1_shards"
MERGE = REPO / "tmp" / "judged-wc1.json"
PY = sys.executable


def is_clean(path: pathlib.Path) -> bool:
    if not path.exists():
        return False
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return False
    if data.get("status") != "ok":
        return False
    scores = data.get("scores") or []
    return bool(scores) and all(item.get("score") is not None for item in scores)


def main() -> int:
    payload = json.loads(SRC.read_text(encoding="utf-8"))
    expected = len(payload["candidates"])
    slices = sorted(WORK.glob("in-*.json"))
    if not slices:
        print("no shard slices found — run run_wc1_judge.py first")
        return 1

    for inp in slices:
        outp = inp.with_name(inp.name.replace("in-", "out-"))
        n = len(json.loads(inp.read_text(encoding="utf-8"))["candidates"])
        if is_clean(outp):
            print(f"clean  {outp.name} n={n}")
            continue
        print(f"RERUN  {inp.name} n={n}", flush=True)
        proc = subprocess.run(
            [PY, str(JEV), "--engine", "laya", "--input", str(inp),
             "--output", str(outp), "--require-real"],
            cwd=REPO)
        print(f"       exit={proc.returncode}", flush=True)

    scored: list[dict] = []
    survivors: list[dict] = []
    errors: list[dict] = []
    statuses: dict[str, str] = {}
    for inp in slices:
        outp = inp.with_name(inp.name.replace("in-", "out-"))
        if not outp.exists():
            errors.append({"candidate_id": inp.stem, "error": "missing_output"})
            statuses[inp.stem] = "unavailable"
            continue
        result = json.loads(outp.read_text(encoding="utf-8"))
        statuses[inp.stem] = str(result.get("status"))
        scored.extend(result.get("scores") or [])
        survivors.extend(result.get("survivors") or [])
        errors.extend(result.get("errors") or [])

    null_scores = [s for s in scored if s.get("score") is None]
    merged = {
        "status": "ok" if not errors and not null_scores and len(scored) == expected else "error",
        "engine": "laya",
        "backend": "laya_sdk",
        "real_engine": True,
        "real_jev": False,
        "criterion": "instance",
        "threshold": 0.5,
        "candidate_count": expected,
        "scored_count": len(scored),
        "kept_count": len(survivors),
        "shard_statuses": statuses,
        "scores": scored,
        "result_list": survivors,
        "survivors": survivors,
        "errors": errors,
    }
    MERGE.write_text(json.dumps(merged, ensure_ascii=False, indent=1), encoding="utf-8")
    print(f"MERGED scored={len(scored)}/{expected} null={len(null_scores)} "
          f"kept={len(survivors)} errors={len(errors)} -> {MERGE}")
    return 0 if not errors and not null_scores and len(scored) == expected else 1


if __name__ == "__main__":
    raise SystemExit(main())
