#!/usr/bin/env python3
"""Probe: list the LIVE kb-mcp tool names + services reachability. Read-only."""
from __future__ import annotations

import json
import sys
import urllib.error
import urllib.request
from pathlib import Path

REPO = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(REPO / "benchmark-suite" / "scripts"))
import lib as L  # noqa: E402

out = {}

# ── services ────────────────────────────────────────────────────────────────
for label, url in (("backend_health", L.BACKEND + "/api/v1/health"),
                   ("web_catalog", L.WEB + "/api/kb/catalog")):
    try:
        tok = L.auth_token()
        req = urllib.request.Request(url, headers={"Authorization": f"Bearer {tok}"})
        with urllib.request.build_opener().open(req, timeout=20) as r:
            body = r.read().decode("utf-8", "replace")
        out[label] = {"status": r.status, "len": len(body), "head": body[:200]}
    except urllib.error.HTTPError as e:
        out[label] = {"http_error": e.code, "body": e.read().decode("utf-8", "replace")[:200]}
    except Exception as e:  # noqa: BLE001
        out[label] = {"error": f"{type(e).__name__}: {e}"}

# ── live MCP tool inventory ─────────────────────────────────────────────────
mc = L.McpClient()
try:
    mc._id += 1
    mc._send({"jsonrpc": "2.0", "id": mc._id, "method": "tools/list", "params": {}})
    res = mc._recv(mc._id, timeout=120)
    tools = sorted(t["name"] for t in (res.get("tools") or []))
    out["tool_count"] = len(tools)
    out["tools"] = tools
    out["has_kb_hybrid_search"] = "kb_hybrid_search" in tools
    for want in ("kb_laya_judge", "kb_search_vector", "kb_search_two_stage",
                 "kb_search_stats", "kb_doc_read", "kb_list", "kb_get_documents"):
        out[f"has_{want}"] = want in tools
    # kb_laya_judge signature
    for t in (res.get("tools") or []):
        if t["name"] == "kb_laya_judge":
            out["laya_schema"] = t.get("inputSchema")
finally:
    mc.close()

print(json.dumps(out, ensure_ascii=False, indent=1))
