# -*- coding: utf-8 -*-
"""Read-only Pre-Flight probe + catalog survey + rewritten-query vector wide net."""
import json
import sys
from pathlib import Path

REPO = Path(r"D:\codes\ClaudeGPT\rag_project\rag-knowledge")
sys.path.insert(0, str(REPO / "benchmark-suite" / "scripts"))
from lib import McpClient  # noqa: E402

c = McpClient(REPO)
try:
    print("=== kb_project_status ===")
    st = c.call("kb_project_status")
    print(json.dumps({
        "ready": st.get("ready"),
        "summary": st.get("summary"),
    }, ensure_ascii=False, indent=1))

    print("\n=== kb_list(lightweight) ===")
    cat = c.call("kb_list", {"lightweight": True})
    items = cat.get("catalog") or cat.get("knowledge_bases") or cat
    if isinstance(items, dict):
        items = items.get("catalog", [])
    print("KB count:", len(items))
    for k in items:
        print(f"  - {k.get('kb_id')} | {k.get('name')} | docs={k.get('doc_count')} | {(k.get('description') or '')[:120]}")

    q = ("HNSW 索引参数 ef_search 线上推荐起始值；索引重建验收基线 baseline 与回滚线 rollback 阈值")
    print("\n=== kb_search_vector (rewritten query, whole library) ===")
    v = c.call("kb_search_vector", {
        "query": q, "kb_id": "", "top_k": 30,
        "score_threshold": 0.35, "balance_kbs": True, "slim": True,
    }, timeout=300)
    hits = v.get("results") or v.get("chunks") or []
    print("hits:", len(hits))
    seen = {}
    for h in hits:
        p = (h.get("doc_path") or h.get("path") or "").replace("\\", "/")
        s = h.get("score") or h.get("similarity") or 0
        if p not in seen or s > seen[p][0]:
            seen[p] = (s, h.get("kb_id"), h.get("name"))
    for p, (s, kid, nm) in sorted(seen.items(), key=lambda x: -x[1][0]):
        print(f"  {round(s,4)} | {kid} | {p} | {nm}")
finally:
    c.close()
