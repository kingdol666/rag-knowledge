# -*- coding: utf-8 -*-
"""Final counts: kept=true docs, P&P survivor list with scores."""
import json
import io
import re
import sys

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")

with open("tmp/hybrid-ragweak.json", encoding="utf-8") as f:
    d = json.load(f)

ds = d["judge"]["doc_scores"]
kept_true = [x for x in ds if x.get("kept")]
print("judged docs:", len(ds))
print("kept=true docs:", len(kept_true))
print("abs >= 0.5:", sum(1 for x in ds if (x.get("judge_score") or 0) >= 0.5))
print("rel >= 0.864:", sum(1 for x in ds if (x.get("judge_score") or 0) >= 0.864))

# P&P survivors from result_list, sorted by part number
rl = d["result_list"]
pp = [r for r in rl if r.get("kb_name") == "Novel-PridePrejudice"]


def part_no(path):
    m = re.search(r"\(part (\d+) of 26\)", path)
    return int(m.group(1)) if m else 999


pp.sort(key=lambda r: part_no(r["doc_path"]))
print()
print("P&P survivors:", len(pp))
for r in pp:
    p = part_no(r["doc_path"])
    print("  part %2d | judge=%.4f | lane=%-7s | %s" % (
        p, r["judge_score"], r["lane"], r["doc_path"]))

# P&P docs that were judged but NOT kept, for blind-spot accounting
pp_judged = [x for x in ds if "pride_and_prejudice" in (x.get("doc_path") or "")]
not_kept = [x for x in pp_judged if not x.get("kept")]
print()
print("P&P docs judged:", len(pp_judged), "| judged-but-not-kept:", len(not_kept))
for x in not_kept:
    print("  dropped: %s score=%.4f" % (x["doc_path"], x["judge_score"] or 0))
