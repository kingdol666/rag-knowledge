import json, re
from collections import defaultdict

p = r"D:\codes\ClaudeGPT\rag_project\rag-knowledge\tmp\judged-ragweak.json"
d = json.load(open(p, encoding="utf-8"))
surv = d["survivors"]

def key(doc):
    m = re.search(r"part (\d+) of 26", doc)
    return int(m.group(1)) if m else 999

# highly distinctive phrases per known proposal beat + generic who/whom patterns
PATS = [
    ("D1_open",   r"in vain have I struggled"),
    ("D1_lastman", r"last man in the world"),
    ("D2_dearest", r"dearest,? loveliest"),
    ("D2_oneword", r"one word from you"),
    ("D2_generous", r"too generous to trifle"),
    ("C_hope",    r"may I hope"),
    ("C_pride",   r"(your modesty|violence of my affection|It is a subject on which I have long)"),
    ("C_ladycat", r"(Lady Catherine|condescension).{0,160}(marriage|marry|propose)"),
    ("B_bingley", r"Bingley.{0,160}(propos|hand|heart|accept|joy|happiest)"),
    ("B_propose", r"propos\w*.{0,160}(Jane|Bingley)"),
    ("CH_accept", r"(Charlotte|Miss Lucas)[^.]{0,80}(accepted|consent|engaged|married|happiness)"),
    ("CH_lucas",  r"(Lucas Lodge|Sir William)[^.]{0,200}(Collins|engaged|married)"),
    ("solicit",   r"solicited"),
    ("hand_in_m", r"(hand in marriage|offered me his hand|his hand was)"),
    ("consent_p", r"consent(ed)?[^.]{0,120}(union|marriage|engagement|addresses|proposal)"),
    ("wickham_m", r"Wickham[^.]{0,120}(marry|married|marriage)"),
    ("eliz_yes",  r"(my feelings|my affections|my heart)[^.]{0,120}(changed|yours|so different)"),
]

compiled = [(n, re.compile(pat, re.I)) for n, pat in PATS]

out = defaultdict(list)
for r in sorted(surv, key=lambda x: (key(x["doc_path"]), x["start_char"])):
    t = r.get("text") or ""
    for name, rx in compiled:
        for m in rx.finditer(t):
            s = max(0, m.start() - 260)
            e = min(len(t), m.end() + 300)
            ctx = t[s:e].replace("\n", " ")
            out[name].append((key(r["doc_path"]), r["start_line"], r["end_line"], r["score"], ctx[:620]))

for name, _ in PATS:
    rows = out.get(name, [])
    print("\n" + "#" * 110)
    print(f"### PATTERN {name}  ({len(rows)} matches)")
    seen = set()
    for part, sl, el, sc, ctx in rows:
        h = ctx[:100]
        if h in seen:
            continue
        seen.add(h)
        print(f"  [part{part} L{sl}-{el} jev={sc:.3f}] {ctx}")
