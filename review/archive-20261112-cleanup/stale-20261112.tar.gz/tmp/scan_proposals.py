import json, re
from collections import defaultdict

p = r"D:\codes\ClaudeGPT\rag_project\rag-knowledge\tmp\judged-ragweak.json"
d = json.load(open(p, encoding="utf-8"))
surv = d["survivors"]

# truncation check: is segment text shorter than its span?
trunc = 0
for r in surv:
    span = (r.get("end_char") or 0) - (r.get("start_char") or 0)
    tlen = len(r.get("text") or "")
    if span > 0 and tlen < span * 0.9:
        trunc += 1
print(f"total survivors={len(surv)}, segments whose text < 90% of span: {trunc}")

parts = sorted({r["doc_path"] for r in surv},
               key=lambda x: (lambda m: (int(m.group(1)), int(m.group(2)) if m.group(2) else 0))(
                   re.search(r"part (\d+) of (\d+)(?:\) \(part (\d) of \d+)?", x) or re.match(r"(?:.*?)", "")))
print("\n27 doc files:", len(parts))

PAT = re.compile(
    r"(proposal|propose[drs]?|proposing|marry me|offer(?:ed)? (?:me |her |him )?(?:his |my )?hand|"
    r"hand in marriage|in vain have I struggled|dearest,? loveliest|last man in the world|"
    r"my affections and wishes|one word from you|consent|refus(?:e|ed|es|ing)|"
    r"accepted (?:his|the) hand|felicity|ardour|ardent|passion(?:ate)?|address(?:ed)? (?:you|me|her|him)|"
    r"engaged|engagement|union|happiness in the marriage)",
    re.I)

hits = defaultdict(list)
for r in surv:
    t = r.get("text") or ""
    ms = list(PAT.finditer(t))
    if ms:
        hits[r["doc_path"]].append((r, ms))

print(f"docs with >=1 keyword hit: {len(hits)}")

def key(doc):
    m = re.search(r"part (\d+) of 26", doc)
    return int(m.group(1)) if m else 999

for doc in sorted(hits, key=key):
    rows = hits[doc]
    print("\n" + "=" * 100)
    print(f"DOC: {doc}  ({len(rows)} hit-segments)")
    for r, ms in rows:
        words = sorted({m.group(0).lower() for m in ms})
        print(f"  L{r['start_line']}-{r['end_line']} score={r['score']:.4f} chars={r['start_char']}-{r['end_char']} keywords={words[:8]}")
