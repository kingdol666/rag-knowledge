import json
from collections import defaultdict

p = r"D:\codes\ClaudeGPT\rag_project\rag-knowledge\tmp\judged-ragweak.json"
d = json.load(open(p, encoding="utf-8"))

print("== TOP LEVEL ==")
for k, v in d.items():
    if isinstance(v, list):
        print(f"{k}: list[{len(v)}]")
    elif isinstance(v, dict):
        print(f"{k}: dict keys={list(v.keys())[:25]}")
    else:
        print(f"{k}: {repr(v)[:300]}")

for key in ("result_list", "survivors"):
    lst = d.get(key)
    if isinstance(lst, list) and lst:
        print(f"\n== {key}[0] sample keys ==")
        print(list(lst[0].keys()))
        print(json.dumps(lst[0], ensure_ascii=False)[:800])

ep = d.get("evidence_pack")
if isinstance(ep, str):
    print(f"\n== evidence_pack (str, {len(ep)} chars) head ==")
    print(ep[:1500])
elif isinstance(ep, list):
    print(f"\n== evidence_pack list[{len(ep)}] first ==")
    print(json.dumps(ep[0], ensure_ascii=False)[:800] if ep else "EMPTY")

# survivors grouped by document
lst = d.get("result_list") or d.get("survivors") or []
if isinstance(lst, list):
    groups = defaultdict(list)
    for r in lst:
        kb = r.get("kb_id") or r.get("kb") or "?"
        doc = r.get("doc_path") or r.get("path") or r.get("doc_id") or "?"
        groups[(kb, doc)].append(r)
    print(f"\n== SURVIVORS BY DOC ({len(groups)} docs) ==")
    for (kb, doc), rows in sorted(groups.items()):
        scores = [x.get("score") for x in rows if isinstance(x.get("score"), (int, float))]
        smin = min(scores) if scores else None
        smax = max(scores) if scores else None
        offs = [(x.get("start_line"), x.get("end_line")) for x in rows]
        print(f"{kb} | {doc} | n={len(rows)} | score {smin}..{smax} | lines {offs[:3]}...{offs[-1:] if len(offs)>3 else ''}")
