#!/usr/bin/env python3
"""Sandbox probe: does the sub-KB chain actually work end-to-end?
create parent → create 2 sub-KBs w/ descriptions → create docs in sub-KB →
list/read/index/judge via sub-KB ids → move semantics → cleanup.
Everything is a throwaway sandbox KB deleted at the end."""
import json, subprocess, sys, time

REPO = r"D:\codes\ClaudeGPT\rag_project\rag-knowledge"
STAMP = str(int(time.time()))
PARENT = f"阶梯验证父库-{STAMP}"
SUB_A = f"阶梯验证父库-子库A-{STAMP}"
SUB_B = f"阶梯验证父库-子库B-{STAMP}"


def mcp(tool, payload, timeout=180):
    r = subprocess.run([sys.executable, "scripts/mcp_call.py", tool,
                        json.dumps(payload, ensure_ascii=False), "--raw"],
                       capture_output=True, text=True, encoding="utf-8", cwd=REPO, timeout=timeout)
    out = (r.stdout or "").strip()
    if r.returncode != 0 or not out:
        raise RuntimeError(f"{tool} rc={r.returncode}: {(r.stderr or out)[:300]}")
    return json.loads(out)


def step(name, ok, detail=""):
    print(("PASS " if ok else "FAIL "), name, "-", detail[:220])


def deep_id(d):
    """Extract kb UUID from kb_create/kb_list responses."""
    for k in ("id", "kbId", "kb_id", "knowledgeBase"):
        if k in d and isinstance(d[k], str) and d[k]:
            return d[k]
    kb = d.get("knowledgeBase") or d.get("data") or {}
    if isinstance(kb, dict):
        for k in ("id", "kbId", "kb_id"):
            if kb.get(k):
                return kb[k]
    return ""


def deep_get(d, dotted, default=None):
    cur = d
    for part in dotted.split("."):
        if not isinstance(cur, dict) or part not in cur:
            return default
        cur = cur[part]
    return cur


def deep_hits(d):
    if isinstance(d, dict):
        return d.get("hits") or d.get("results") or d.get("documents") or []
    return d if isinstance(d, list) else []


results = []
sandbox_ids = []

try:
    # 1. create parent KB (root)
    d = mcp("kb_create", {"name": PARENT, "description": "沙箱：逐级检索阶梯验证父库，验证后即删。覆盖子库A(检索算法)与子库B(储能材料)两个子域。"})
    step("kb_create parent", d.get("success"), json.dumps(d, ensure_ascii=False)[:150])
    pid = deep_id(d)
    sandbox_ids.append(pid)
    print("   parent id:", pid)

    # 2. create sub-KB A with parent_id = parent UUID
    d = mcp("kb_create", {"name": SUB_A, "description": "沙箱子库A：稀疏检索与重排算法（BM25、RRF、交叉编码器重排），覆盖检索质量评测问题。", "parent_id": pid})
    step("kb_create subA (parent_id=parent uuid)", d.get("success"), json.dumps(d, ensure_ascii=False)[:150])
    aid = deep_id(d)
    sandbox_ids.append(aid)
    print("   subA id:", aid)

    # 3. create sub-KB B
    d = mcp("kb_create", {"name": SUB_B, "description": "沙箱子库B：锂离子电池硅碳负极材料（循环稳定性、首效、膨胀控制），覆盖电池材料问题。", "parent_id": pid})
    step("kb_create subB", d.get("success"), json.dumps(d, ensure_ascii=False)[:150])
    bid = deep_id(d)
    sandbox_ids.append(bid)

    # 4. ladder view: kb_list parent_id filters
    d = mcp("kb_list", {"lightweight": True, "parent_id": pid})
    kids = d.get("catalog", [])
    step("kb_list(parent) one-level drill", d.get("success") and len(kids) == 2,
         f"children={[k['name'][:30] for k in kids]}")

    # 5. create docs inside sub-KB A
    doc1 = mcp("kb_doc_create", {"kb_id": aid, "name": "rrf-fusion.md",
        "description": "RRF 倒数排名融合算法：将 BM25 与稠密向量两路检索结果按 1/(k+rank) 融合，k=60 实测优于加权求和，适用于多路召回去重合并场景。中文。",
        "content": "# RRF 倒数排名融合\n\nRRF（Reciprocal Rank Fusion）将多路检索结果融合：score(d) = Σ 1/(k + rank_i(d))，k 取 60。\n实测在 HotpotQA 上 RRF 融合优于 BM25 单路与加权分数求和，且无需调权重。\n适用于 BM25 与稠密向量双路召回的合并场景。"[:4000]})
    step("kb_doc_create in subA", doc1.get("success"), json.dumps(doc1, ensure_ascii=False)[:150])

    doc2 = mcp("kb_doc_create", {"kb_id": aid, "name": "cross-encoder-rerank.md",
        "description": "交叉编码器重排：bge-reranker 对 query-doc 对逐对打分，top50→top5 精排，NDCG@5 提升 12%，适用于两阶段检索的精排层。中文。",
        "content": "# 交叉编码器重排\n\nCross-Encoder 对 (query, doc) 对逐对编码打分，精度高于 Bi-Encoder。\n两阶段检索：先向量召回 top50，再 bge-reranker 精排取 top5。NDCG@5 提升 12%。"[:4000]})
    step("kb_doc_create #2 in subA", doc2.get("success"), "")

    # 6. doc inside sub-KB B
    doc3 = mcp("kb_doc_create", {"kb_id": bid, "name": "si-c-anode.md",
        "description": "硅碳负极材料：硅碳复合负极首效 88%，1000 圈循环保持率 80%，膨胀控制用多孔碳骨架，适用于高能量密度锂电池设计问题。中文。",
        "content": "# 硅碳负极\n\n硅碳复合负极：首效 88%，1000 圈循环保持率 80%。膨胀控制采用多孔碳骨架缓冲硅的体积膨胀（~300%）。\n适用于 400Wh/kg 级高能量密度电池设计。"[:4000]})
    step("kb_doc_create in subB", doc3.get("success"), "")

    time.sleep(1)

    # 7. parent listing — does it show sub-KB containers or own docs?
    d = mcp("kb_get_documents", {"kb_id": pid, "lightweight": True})
    step("kb_get_documents(parent)", d.get("success"),
         f"count={d.get('count')} catalog={[c.get('name','')[:30] for c in d.get('catalog', [])][:5]}")

    # 8. sub-KB doc listing
    d = mcp("kb_get_documents", {"kb_id": aid, "lightweight": True})
    step("kb_get_documents(subA)", d.get("success") and d.get("count") == 2,
         f"count={d.get('count')} names={[c.get('name','')[:28] for c in d.get('catalog', [])]}")

    # 9. doc read from sub-KB
    d = mcp("kb_doc_read", {"kb_id": aid, "doc_path": "rrf-fusion.md"})
    step("kb_doc_read(subA, doc)", bool(d.get("content")), f"content[:60]={str(d.get('content',''))[:60]}")

    # 10. index sub-KB docs + vector search behavior (parent vs sub collection)
    idx = mcp("kb_index_document", {"kb_id": aid, "doc_path": "rrf-fusion.md"})
    coll = deep_get(idx, "vector_index.collection")
    total_chunks = deep_get(idx, "vector_index.total_chunks")
    step("kb_index_document(subA doc)", bool(coll), f"collection={coll} chunks={total_chunks}")

    v_sub = mcp("kb_search_vector", {"query": "多路检索结果融合 RRF", "kb_id": aid, "top_k": 3, "slim": True})
    v_par = mcp("kb_search_vector", {"query": "多路检索结果融合 RRF", "kb_id": pid, "top_k": 3, "slim": True})
    hit_sub = deep_hits(v_sub)
    hit_par = deep_hits(v_par)
    step("vector: search by sub-KB id", bool(hit_sub), f"top={[h.get('doc_path', h.get('path',''))[:40] for h in hit_sub][:2]}")
    step("vector: search by parent id", bool(hit_par), f"top={[h.get('doc_path', h.get('path',''))[:40] for h in hit_par][:2]}")

    # 11. judge on sub-KB doc
    jd = mcp("kb_laya_judge", {"query": "如何把 BM25 和向量检索的结果融合？", "criterion": "evidence",
                                "documents": json.dumps([{"kb_id": aid, "doc_path": "rrf-fusion.md"}], ensure_ascii=False)},
          timeout=300)
    step("kb_laya_judge(subA doc)", jd.get("status") in ("ok", "success") or jd.get("scored_count", 0) >= 0,
         json.dumps({k: jd.get(k) for k in ("status", "scored_count", "survivor_count")}, ensure_ascii=False))

    # 12. move semantics: parent doc → sub-KB
    dtmp = mcp("kb_doc_create", {"kb_id": pid, "name": "misplaced.md",
        "description": "误放文档：交叉编码器重排笔记，应归属子库A。", "content": "# 误放\n\nbge-reranker 交叉编码器精排笔记。"})
    mv_src = None
    for dd in (dtmp.get("document") or {}, dtmp):
        p = dd.get("path") or dd.get("doc_path")
        if p:
            mv_src = p
            break
    step("create misplaced doc in parent", dtmp.get("success"), f"path={mv_src}")
    if mv_src:
        mv = mcp("kb_doc_move", {"doc_path": mv_src, "target_kb_id": aid})
        step("kb_doc_move(parent→subA)", mv.get("success"), json.dumps(mv, ensure_ascii=False)[:150])
        time.sleep(2)
        da = mcp("kb_get_documents", {"kb_id": aid, "lightweight": True})
        step("post-move subA listing", da.get("count") == 3, f"subA count={da.get('count')}")
        dp = mcp("kb_get_documents", {"kb_id": pid, "lightweight": True})
        step("post-move parent listing", dp.get("count") == 0, f"parent count={dp.get('count')}")

finally:
    # cleanup sandbox
    for sid in reversed(sandbox_ids):
        try:
            mcp("kb_delete", {"kb_id": sid})
        except Exception as e:
            print("cleanup warn:", sid, str(e)[:80])
    print("sandbox cleaned:", sandbox_ids)
