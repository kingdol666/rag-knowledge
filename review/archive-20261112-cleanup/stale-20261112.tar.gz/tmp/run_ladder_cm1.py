#!/usr/bin/env python3
"""严格按逐级检索逻辑实跑 cm1（InstructDS）——每步只看下一级目录，记录每步返回大小。
L0 根库描述 → L0.5 子库下钻(逐级) → L1 叶子书架: 词法预扫描 → 分组图 → 定向组页 → L4 精读。
"""
import json, subprocess, sys

REPO = r"D:\codes\ClaudeGPT\rag_project\rag-knowledge"
Q_TERMS = "InstructDS"


def mcp(tool, payload, timeout=120):
    r = subprocess.run([sys.executable, "scripts/mcp_call.py", tool,
                        json.dumps(payload, ensure_ascii=False), "--raw"],
                       capture_output=True, text=True, encoding="utf-8", cwd=REPO, timeout=timeout)
    out = (r.stdout or "").strip()
    if r.returncode != 0 or not out:
        raise RuntimeError(f"{tool} rc={r.returncode}: {(r.stderr or out)[:200]}")
    return json.loads(out)


def sz(d):
    return len(json.dumps(d, ensure_ascii=False))


log = []
def step(name, detail, chars=None):
    line = f"[{name}] {detail}" + (f"  ({chars} chars)" if chars is not None else "")
    log.append(line)
    print(line)


# ---------- L0: 只看根知识库的描述 ----------
l0 = mcp("kb_list", {"lightweight": True, "parent_id": "__root__"})
step("L0", f"根库目录: {l0['count']} 个库, 逐条读 description", sz(l0))
cand = [kb for kb in l0["catalog"]
        if any(t in (kb["description"] + kb["name"]).lower()
               for t in ["computer", "nlp", "llm", "ai", "算法", "对话", "语言模型"])]
assert cand, "L0 无候选库"
kb = cand[0]
step("L0→判定", f"候选 {[c['name'] for c in cand]} → 选定「{kb['name']}」({kb['doc_count']} docs)")

# ---------- L0.5: 只看该库下一级的子知识库 ----------
l05 = mcp("kb_list", {"lightweight": True, "parent_id": kb["kb_id"]})
step("L0.5", f"「{kb['name']}」的子库: {l05['count']} 个 → {'叶子书架, 直接进 L1' if l05['count'] == 0 else '仅看子库描述并继续下钻'}", sz(l05))
kb_id = kb["kb_id"]

# ---------- L1a: 机侧词法预扫描（不向 LLM 展示任何清单）----------
pre = mcp("kb_search", {"query": Q_TERMS, "top_k": 5})
hits = pre.get("hits", [])
step("L1a", f"kb_search 词法预扫描「{Q_TERMS}」: {len(hits)} 命中", sz(pre))
gold_hit = None
for h in hits:
    if Q_TERMS.lower() in (h.get("docName", "") + h.get("description", "")).lower():
        gold_hit = h
        break

if gold_hit:
    step("L1a→判定", f"rank-1 即金标: {gold_hit['docName'][:70]}…（描述层直接确认, 阶梯提前收敛）")
    doc_path = gold_hit.get("path") or gold_hit.get("docPath") or gold_hit.get("doc_path")
    kb_id_hit = gold_hit.get("kbId") or gold_hit.get("kb_id") or kb_id
else:
    # ---------- L1b: 分组图 → 只看最想看的组的一页 ----------
    g = mcp("kb_get_documents", {"kb_id": kb_id, "lightweight": True, "view": "groups"})
    step("L1b", f"分组图: {g['group_count']} 组 / {g['total_docs']} docs", sz(g))
    grp = max(g["groups"], key=lambda x: x["count"])  # 演示: 取最大组
    step("L1b→判定", f"选中组「{grp['group']}」({grp['count']} docs), 只看这一组")
    pg = mcp("kb_get_documents", {"kb_id": kb_id, "lightweight": True,
                                  "view": "docs", "group": grp["group"], "page": 1})
    step("L1b", f"该组页 1: {pg['count']} 条描述, has_more={pg['has_more']}", sz(pg))
    sys.exit("演示路径(无预扫描命中)到此为止 — 本题预扫描应命中")

# ---------- L4: 只精读幸存者 ----------
read = mcp("kb_doc_read", {"kb_id": kb_id_hit, "doc_path": doc_path.replace("\\", "/"),
                           "max_chars": 2000})
content = read.get("content", "") or ""
ok = "InstructDS" in content and ("three-step" in content.lower() or "三步" in content or "query" in content.lower())
step("L4", f"kb_doc_read 精读: {len(content)} chars, InstructDS 内容确认={ok}")

print()
print("=== 逐级检索阶梯收敛 ===")
print(f"路径: 根目录({l0['count']}库) → 子库层(0) → 词法预扫描(rank-1 金标) → 精读")
print(f"LLM 实际看到的描述层字节: L0 {sz(l0)} + L0.5 {sz(l05)} + 预扫描 {sz(pre)} = "
      f"{sz(l0)+sz(l05)+sz(pre)} chars << 旧全量清单 73,742 chars")
sys.exit(0 if ok else 1)
