#!/usr/bin/env python3
"""Librarian (mode B) L4 helper for the 《围城》 enumeration task (wc1).

1) Byte-level entity scan of the real KB store (no ignore rules -> zero
   pagination blind spots; this is the completeness backbone).
2) Same scan over the legacy backup store and a repo-lite sweep (any other
   location that might hold 围城 content).
3) Build the Jev candidate manifest (tmp/candidates-wc1.json) from EVERY
   document in EVERY kept shelf, structure-aware segmented with offsets.
4) Emit a 3-segment smoke manifest (tmp/mini-wc-smoke.json) to test the engine.
"""
from __future__ import annotations

import json
import pathlib

REPO = pathlib.Path(__file__).resolve().parents[1]
STORAGE = REPO / "storage" / "tree-file-system"
BACKUP = REPO / ".bench_backup_20260916" / "tree-file-system"
OUT = REPO / "tmp" / "candidates-wc1.json"
SMOKE = REPO / "tmp" / "mini-wc-smoke.json"

TOKENS = ["围城", "方鸿渐", "鸿渐", "苏文纨", "文纨", "唐晓芙", "晓芙", "孙柔嘉",
          "柔嘉", "鲍小姐", "赵辛楣", "辛楣", "三闾大学", "克莱登", "Fortress Besieged"]
ENCODINGS = ("utf-8", "gbk", "utf-16")

EXCLUDE_PARTS = {".git", ".venv", "node_modules", "model", "chroma_db", "logs",
                 "output", "__pycache__", ".omc", "tool-results", "tmp"}
SHELF_EXCLUDE = {"计算机与人工智能", "自然科学与地球科学", "生命科学与医学",
                 "工程与能源", "经济与社会"}
# Descriptions that are clearly publication/front/back matter (L3-trusted) are
# skipped as manifest candidates per the task's "排除无关文档如出版说明".
FRONT_MATTER_NAMES = {
    "pride_and_prejudice (part 1 of 26) (part 1 of 2).md",
    "pride_and_prejudice (part 1 of 26) (part 2 of 2).md",
    "pride_and_prejudice (part 26 of 26).md",
}
TARGET_CHARS = 1800
MAX_FILE_BYTES = 8_000_000

QUERY = ("按出场顺序列出小说《围城》中方鸿渐先后与哪几位女性有过感情纠葛，"
         "每个阶段的关键情节与结局分别是什么")


def has_token(raw: bytes, token: str) -> bool:
    for enc in ENCODINGS:
        try:
            if token.encode(enc) in raw:
                return True
        except (UnicodeEncodeError, LookupError):
            continue
    return False


def scan(root: pathlib.Path, label: str, *, skip_storage: bool = False) -> int:
    print(f"== token scan: {label} ==")
    if not root.exists():
        print("  (missing)")
        return 0
    hits = 0
    for p in sorted(root.rglob("*")):
        if not p.is_file():
            continue
        if any(part in EXCLUDE_PARTS for part in p.parts):
            continue
        if skip_storage and "storage" in p.parts:
            continue
        try:
            if p.stat().st_size > MAX_FILE_BYTES:
                continue
        except OSError:
            continue
        try:
            raw = p.read_bytes()
        except OSError:
            continue
        found = [t for t in TOKENS if has_token(raw, t)]
        if found:
            hits += 1
            rel = p.relative_to(root) if root in p.parents or root == p.parent else p
            print(f"  HIT {rel} :: {found}")
    print(f"  hit-files={hits}")
    return hits


def load_tree_ids(tree_path: pathlib.Path) -> dict[str, str]:
    ids: dict[str, str] = {}
    if not tree_path.exists():
        return ids

    def walk(node: object) -> None:
        if isinstance(node, dict):
            path, node_id = node.get("path"), node.get("id")
            if path and node_id:
                ids[str(path).replace("/", "\\")] = str(node_id)
            for value in node.values():
                walk(value)
        elif isinstance(node, list):
            for value in node:
                walk(value)

    try:
        walk(json.loads(tree_path.read_text(encoding="utf-8")))
    except (OSError, ValueError) as exc:
        print(f"  ! tree parse failed: {exc}")
    return ids


def segment(text: str, target: int = TARGET_CHARS) -> list[dict]:
    """Paragraph-aware segmentation with section path + line offsets."""
    lines = text.splitlines()
    segments: list[dict] = []
    buf: list[str] = []
    buf_len = 0
    start_line = 1
    section = ""

    def flush(end_line: int) -> None:
        nonlocal buf, buf_len, start_line
        body = "\n".join(buf).strip()
        if body:
            segments.append({
                "section_path": section,
                "start_line": start_line,
                "end_line": end_line,
                "text": body,
            })
        buf, buf_len = [], 0

    for lineno, line in enumerate(lines, start=1):
        if line.startswith("#"):
            flush(lineno - 1)
            section = line.strip("# ").strip()
            start_line = lineno
            buf.append(line)
            buf_len += len(line)
            continue
        if not buf:
            start_line = lineno
        buf.append(line)
        buf_len += len(line)
        if buf_len >= target:
            flush(lineno)
            start_line = lineno + 1
    flush(len(lines))
    return segments


def part_index(name: str) -> int:
    for token in ("(part ", "（part "):
        idx = name.find(token)
        if idx >= 0:
            tail = name[idx + len(token):]
            num = ""
            for ch in tail:
                if ch.isdigit():
                    num += ch
                else:
                    break
            if num:
                return int(num)
    return 0


def build_manifest() -> None:
    print("== build manifest ==")
    ids = load_tree_ids(STORAGE / ".tree-fs.json")
    candidates: list[dict] = []
    per_kb: dict[str, list[int]] = {}
    skipped_front = 0
    for kb_dir in sorted(p for p in STORAGE.iterdir() if p.is_dir()):
        name = kb_dir.name
        if name.startswith(".") or name in SHELF_EXCLUDE:
            continue
        kb_id = ids.get(name, name)
        docs_read = 0
        segs_for_kb = 0
        for doc in sorted(kb_dir.rglob("*.md")):
            rel_parts = doc.relative_to(STORAGE).parts
            if "images" in rel_parts:
                continue
            if doc.name in FRONT_MATTER_NAMES:
                skipped_front += 1
                continue
            try:
                text = doc.read_text(encoding="utf-8", errors="ignore")
            except OSError:
                continue
            if not text.strip():
                continue
            doc_path = "\\".join(rel_parts)
            doc_id = ids.get(doc_path, "")
            docs_read += 1
            for seg in segment(text):
                candidates.append({
                    "candidate_id": f"wc1-{len(candidates):05d}",
                    "kb_id": kb_id,
                    "doc_id": doc_id,
                    "doc_path": doc_path,
                    "part_index": part_index(doc.name),
                    "section_path": seg["section_path"],
                    "start_line": seg["start_line"],
                    "end_line": seg["end_line"],
                    "text": seg["text"],
                })
                segs_for_kb += 1
        per_kb[name] = [docs_read, segs_for_kb]

    OUT.parent.mkdir(parents=True, exist_ok=True)
    payload = {"query": QUERY, "criterion": "instance", "engine": "laya",
               "candidates": candidates}
    OUT.write_text(json.dumps(payload, ensure_ascii=False, indent=1), encoding="utf-8")

    total_chars = sum(len(c["text"]) for c in candidates)
    print(f"  front-matter skipped: {skipped_front}")
    for name, (docs, segs) in per_kb.items():
        print(f"  {name}: docs={docs} segments={segs}")
    print(f"  TOTAL candidates={len(candidates)} chars={total_chars}")
    print(f"  wrote {OUT}")

    smoke = {"query": QUERY, "criterion": "instance", "engine": "laya",
             "candidates": candidates[:3]}
    SMOKE.write_text(json.dumps(smoke, ensure_ascii=False, indent=1), encoding="utf-8")
    print(f"  wrote {SMOKE}")


def main() -> int:
    print(f"repo={REPO}")
    print("== storage folders ==")
    if STORAGE.exists():
        for p in sorted(x for x in STORAGE.iterdir() if x.is_dir()):
            n = sum(1 for _ in p.rglob("*") if _.is_file())
            print(f"  {p.name}  files={n}")
    else:
        print("  (storage missing)")
    scan(STORAGE, "KB store (real)")
    scan(BACKUP, "legacy backup store")
    scan(REPO, "repo-lite sweep", skip_storage=True)
    build_manifest()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
