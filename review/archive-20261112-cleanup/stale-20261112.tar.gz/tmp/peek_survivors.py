﻿import json, pathlib
work = pathlib.Path(r"D:\codes\ClaudeGPT\rag_project\rag-knowledge\tmp\wc1_shards")
for f in sorted(work.glob("out-*.json")):
    d = json.loads(f.read_text(encoding="utf-8"))
    svs = d.get("survivors") or []
    if not svs: continue
    print(f"== {f.name} kept={len(svs)} status={d.get('status')} ==")
    for s in svs[:8]:
        txt = (s.get("text") or "").replace("\n", " ")[:110]
        print(f"  [{s['candidate_id']}] {s.get('score')} {s.get('doc_path','')[-60:]} :: {txt}")
