import json, re
p = r"D:\codes\ClaudeGPT\rag_project\rag-knowledge\tmp\judged-ragweak.json"
d = json.load(open(p, encoding="utf-8"))
scores = d["scores"]; surv_ids = {r["candidate_id"] for r in d["survivors"]}
trunc = d.get("truncated_candidate_ids") or []
print("truncated_candidate_ids:", trunc)
print("\n== NON-SURVIVORS (scored but not kept, or missing) ==")
for s in scores:
    cid = s.get("candidate_id","")
    if cid not in surv_ids:
        print(json.dumps({k: s.get(k) for k in ("candidate_id","score","kept","status","error","doc_path","start_line","end_line")}, ensure_ascii=False))
# any score entries with missing/None score
miss = [s for s in scores if s.get("score") is None]
print("\nmissing-score count:", len(miss), "| scored entries:", len(scores))

# the dropped file's candidate text
c = json.load(open(r"D:\codes\ClaudeGPT\rag_project\rag-knowledge\tmp\candidates-ragweak.json", encoding="utf-8"))["candidates"]
for x in c:
    if "part 1 of 26) (part 2 of 2" in x["doc_path"]:
        print("\nDROPPED CANDIDATE (part1 2of2):")
        print(json.dumps({k: x.get(k) for k in ("candidate_id","doc_path","start_line","end_line","start_char","end_char")}, ensure_ascii=False))
        print("TEXT:", x["text"][:400])

# extra dumps
surv = d["survivors"]
def part_of(doc):
    m = re.search(r"part (\d+) of 26", doc); return int(m.group(1)) if m else 999
def find(part, line, oneof2=None):
    for r in surv:
        if part_of(r["doc_path"]) == part and r["start_line"] <= line <= r["end_line"]:
            return r
    return None

EXTRA = [(2,442,None),(23,586,None),(24,441,None),(24,506,None),(24,559,None),(25,512,None),(26,1,None),(26,111,None),(23,415,None),(23,478,None)]
out=[]
for part,line,tag in EXTRA:
    r = find(part,line)
    if not r: out.append(f"\n----- part{part} L{line}: none -----\n"); continue
    out.append(f"\n===== part{part} L{r['start_line']}-{r['end_line']} jev={r['score']:.4f} =====\n" + r["text"][:1800])
open(r"D:\codes\ClaudeGPT\rag_project\rag-knowledge\tmp\dump_extra.txt","w",encoding="utf-8").write("".join(out))
print("\nextra dump written")
