# -*- coding: utf-8 -*-
"""Scrape tmp/hybrid-ragweak.json: result_list run list + evidence_pack inventory."""
import json
import sys
import io

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")

PATH = "tmp/hybrid-ragweak.json"
with open(PATH, encoding="utf-8") as f:
    d = json.load(f)

out = []


def w(s=""):
    out.append(str(s))


rl = d.get("result_list") or []
w("=== RESULT_LIST n=%d ===" % len(rl))
for i, r in enumerate(rl):
    desc = (r.get("description") or "").replace("\n", " ")
    if len(desc) > 130:
        desc = desc[:130] + "..."
    w("%2d | kb=%-24s | lane=%-7s | vec=%-5s | judge=%-6s | trunc=%-5s | %s" % (
        i, r.get("kb_name"), r.get("lane"), r.get("vector_score"),
        r.get("judge_score"), r.get("truncated"), r.get("doc_path")))
    w("     desc: %s" % desc)

ep = d.get("evidence_pack")
w()
w("=== EVIDENCE_PACK ===")
w("type=%s" % type(ep).__name__)
if isinstance(ep, dict):
    w("keys=%s" % list(ep.keys()))
    for k, v in ep.items():
        if isinstance(v, (list, dict)):
            w("  %s: %s len=%s" % (k, type(v).__name__, len(v)))
        else:
            sv = str(v)
            w("  %s: %s" % (k, sv[:300]))
elif isinstance(ep, list):
    w("len=%d" % len(ep))
    if ep:
        w("first item type=%s" % type(ep[0]).__name__)
        if isinstance(ep[0], dict):
            w("first item keys=%s" % list(ep[0].keys()))
            for k, v in ep[0].items():
                sv = str(v)
                w("  %s: %s" % (k, sv[:200]))
elif isinstance(ep, str):
    w("len=%d" % len(ep))
    w("head: %s" % ep[:500])

with open("tmp/hybrid-ragweak-runlist.txt", "w", encoding="utf-8") as f:
    f.write("\n".join(out))
print("\n".join(out[:4000]))
print()
print("[written tmp/hybrid-ragweak-runlist.txt]")
