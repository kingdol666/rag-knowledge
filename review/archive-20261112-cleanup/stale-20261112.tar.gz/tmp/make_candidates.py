# -*- coding: utf-8 -*-
"""L4 manifest builder (librarian lane).

Segments EVERY document of the Novel-PridePrejudice shelf — the same storage
files served by kb-mcp kb_doc_read — into structure-aware candidate segments
using the skill's own reference segmenter (complete_recall.segment_document).
Output payload is directly consumable by scripts/jev_filter.py.
"""
from __future__ import annotations

import json
import re
import sys
from pathlib import Path

REPO = Path(__file__).resolve().parents[1]
SKILL_SCRIPTS = REPO / ".claude" / "skills" / "knowledgebase-librarian" / "scripts"
sys.path.insert(0, str(SKILL_SCRIPTS))
from complete_recall import DEFAULT_MAX_SEGMENT_CHARS, segment_document  # noqa: E402

KB_ID = "b4c48237-6937-440a-9696-cc1e66bed5c1"
KB_NAME = "Novel-PridePrejudice"
DOC_DIR = REPO / "storage" / "tree-file-system" / "Novel-PridePrejudice"

QUERY = "列出《傲慢与偏见》小说中所有发生求婚的情节场景（谁向谁求婚、结果如何），按故事顺序排列"

DOC_IDS = {
    "pride_and_prejudice (part 1 of 26) (part 1 of 2).md": "f3066455-7eeb-4207-9d74-562c92f2eecc",
    "pride_and_prejudice (part 1 of 26) (part 2 of 2).md": "c7852b46-8eac-4d4c-b474-1aa065268c9e",
    "pride_and_prejudice (part 2 of 26).md": "09351942-2f89-4327-8758-25ef611da570",
    "pride_and_prejudice (part 3 of 26).md": "1a3649c7-ac48-49b9-8ba9-57ee5976c4e1",
    "pride_and_prejudice (part 4 of 26).md": "4d8bea35-ca4f-4ec3-8f36-1c6ebdb047cb",
    "pride_and_prejudice (part 5 of 26).md": "c97bba78-5fb4-4757-a12a-ae91ef804373",
    "pride_and_prejudice (part 6 of 26).md": "858143a0-8726-4c14-9198-e38da7bb73bd",
    "pride_and_prejudice (part 7 of 26).md": "6b2d6cb5-2b5e-4ea9-b0fd-b4f2ef858449",
    "pride_and_prejudice (part 8 of 26).md": "ab20f25b-7521-4804-9723-fa8af1561418",
    "pride_and_prejudice (part 9 of 26).md": "2f48436b-75a4-4125-b4d9-46fd140b5246",
    "pride_and_prejudice (part 10 of 26).md": "ecbfb10a-6556-44de-a550-5ed04888980e",
    "pride_and_prejudice (part 11 of 26).md": "adeaedcc-548c-4335-b1df-a4a4aca7449d",
    "pride_and_prejudice (part 12 of 26).md": "c7037a9f-aebb-4386-b7e4-3e244fb01e3e",
    "pride_and_prejudice (part 13 of 26).md": "d7f4c191-9f17-4848-99fe-7df71b55fb2f",
    "pride_and_prejudice (part 14 of 26).md": "ab34566b-557a-4117-b198-3afe0ad41b9a",
    "pride_and_prejudice (part 15 of 26).md": "16f33a41-5c75-41c9-a37c-8fa23d94bd17",
    "pride_and_prejudice (part 16 of 26).md": "19508f94-762b-4d7f-bdaf-655b0bb0e722",
    "pride_and_prejudice (part 17 of 26).md": "823b6976-3c02-4568-9847-00b7866e6a4c",
    "pride_and_prejudice (part 18 of 26).md": "69e39cfc-182c-4b96-b52e-98a5f15f904b",
    "pride_and_prejudice (part 19 of 26).md": "8dad2b09-3128-491a-812c-7b6fb527d46f",
    "pride_and_prejudice (part 20 of 26).md": "d7c73b58-a7ee-4e54-9fea-c8e01615d823",
    "pride_and_prejudice (part 21 of 26).md": "2dd87460-d176-4092-82ba-d35f21b1e200",
    "pride_and_prejudice (part 22 of 26) (part 1 of 2).md": "57952c3d-b8c4-413a-943a-9fbd25bd3b22",
    "pride_and_prejudice (part 22 of 26) (part 2 of 2).md": "cb62084f-5b92-43e6-af2d-ffdb9541e19a",
    "pride_and_prejudice (part 23 of 26).md": "e7860545-964a-4a5c-bf37-3c190d0f7cde",
    "pride_and_prejudice (part 24 of 26).md": "fee31bd2-6e18-4160-a78a-515adabf8296",
    "pride_and_prejudice (part 25 of 26).md": "bb5298e0-2645-41fa-944c-869c5439b01c",
    "pride_and_prejudice (part 26 of 26).md": "0dbe02d2-51ae-4b8c-b6b1-163357ba5d10",
}

_CH = re.compile(r"^\s*chapter\s+([ivxlcdm]+|\d+)\b", re.I)


def _part_number(name: str) -> int:
    m = re.search(r"part (\d+) of 26", name)
    return int(m.group(1)) if m else 0


def main() -> None:
    files = sorted(DOC_DIR.glob("*.md"), key=lambda p: (_part_number(p.name), p.name))
    candidates: list[dict] = []
    stats: list[dict] = []
    carry = ""
    for f in files:
        name = f.name
        content = f.read_text(encoding="utf-8")
        part = _part_number(name)
        doc = {
            "kb_id": KB_ID, "kb_name": KB_NAME, "doc_id": DOC_IDS.get(name, ""),
            "doc_path": f"Novel-PridePrejudice/{name}", "name": name,
            "content": content, "part_index": part,
        }
        segs = segment_document(doc, max_chars=DEFAULT_MAX_SEGMENT_CHARS)
        chapter_starts: list[tuple[int, str]] = []
        for i, ln in enumerate(content.splitlines()):
            m = _CH.match(ln)
            if m:
                chapter_starts.append((i + 1, "Chapter " + m.group(1).upper()))
        for s in segs:
            label = ""
            for line_no, txt in chapter_starts:
                if line_no <= s["start_line"]:
                    label = txt
                else:
                    break
            if label:
                carry = label
            s["section_path"] = label or carry
        candidates.extend(segs)
        stats.append({"doc": name, "chars": len(content), "segments": len(segs)})

    payload = {
        "query": QUERY, "engine": "laya", "criterion": "auto", "threshold": 0.5,
        "max_segment_chars": DEFAULT_MAX_SEGMENT_CHARS, "candidates": candidates,
    }
    out = REPO / "tmp" / "candidates-ragweak.json"
    out.write_text(json.dumps(payload, ensure_ascii=False, indent=1), encoding="utf-8")
    print(json.dumps({
        "docs": len(stats), "segments": len(candidates),
        "total_chars": sum(s["chars"] for s in stats), "per_doc": stats,
    }, ensure_ascii=False, indent=1))


if __name__ == "__main__":
    main()
