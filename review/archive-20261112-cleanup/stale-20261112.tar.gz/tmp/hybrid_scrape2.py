# -*- coding: utf-8 -*-
"""Dump evidence_pack and per-doc judge info for the Pride & Prejudice survivors."""
import json
import io
import sys

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")

with open("tmp/hybrid-ragweak.json", encoding="utf-8") as f:
    d = json.load(f)

ep = d["evidence_pack"]
with open("tmp/hybrid-ragweak-evidence.txt", "w", encoding="utf-8") as f:
    f.write(ep if isinstance(ep, str) else json.dumps(ep, ensure_ascii=False, indent=1))
print("evidence_pack chars:", len(ep))

# which doc headers appear in the pack
import re
headers = re.findall(r"\[([^\]]+?\.md)[^\]]*\]", ep)
print("headers in pack (%d):" % len(headers))
for h in headers:
    print("  -", h)

# unscanned list
uns = d.get("unscanned") or []
print()
print("unscanned n =", len(uns))
for u in uns[:40]:
    print("  ", json.dumps(u, ensure_ascii=False)[:220])

# expansion info
exp = d.get("expansion")
print()
print("expansion:", json.dumps(exp, ensure_ascii=False)[:600])

# kept_doc_paths count
kdp = d.get("kept_doc_paths") or []
print()
print("kept_doc_paths n =", len(kdp))
pp = [p for p in kdp if "Pride" in str(p) or "pride" in str(p)]
print("  P&P in kept_doc_paths:", len(pp))
