import json, re

p = r"D:\codes\ClaudeGPT\rag_project\rag-knowledge\tmp\judged-ragweak.json"
d = json.load(open(p, encoding="utf-8"))
surv = d["survivors"]

def part_of(doc):
    m = re.search(r"part (\d+) of 26", doc)
    return int(m.group(1)) if m else 999

by_part = {}
for r in surv:
    by_part.setdefault(part_of(r["doc_path"]), []).append(r)

def find(part, line):
    best = None
    for r in by_part.get(part, []):
        if r["start_line"] <= line <= r["end_line"]:
            if best is None or (r["end_line"] - r["start_line"]) < (best["end_line"] - best["start_line"]):
                best = r
    return best

CORE = [(8, 186), (8, 241), (8, 283), (8, 336), (9, 267), (13, 270), (13, 433),
        (23, 285), (23, 353), (24, 120), (24, 171), (24, 217), (24, 267), (24, 316),
        (22, 239), (22, 458)]
CHECK = [(1, 401), (1, 430), (11, 54), (12, 201), (14, 94), (16, 308), (17, 501),
         (18, 30), (19, 0), (21, 468), (25, 216)]

out = []
out.append("################ CORE SCENES (full text) ################\n")
for part, line in CORE:
    r = find(part, line)
    if not r:
        out.append(f"\n----- part{part} L{line}: NO SURVIVOR SEGMENT -----\n")
        continue
    out.append(f"\n===== part{part} L{r['start_line']}-{r['end_line']} jev={r['score']:.4f} chars={r['start_char']}-{r['end_char']} =====\n")
    out.append(r["text"][:4200])
    out.append("\n")

out.append("\n\n################ CHECK CANDIDATES (head 500) ################\n")
for part, line in CHECK:
    r = find(part, line)
    if not r:
        out.append(f"\n----- part{part} L{line}: NO SURVIVOR SEGMENT -----\n")
        continue
    out.append(f"\n===== part{part} L{r['start_line']}-{r['end_line']} jev={r['score']:.4f} =====\n")
    out.append(r["text"][:500].replace("\n", " "))
    out.append("\n")

open(r"D:\codes\ClaudeGPT\rag_project\rag-knowledge\tmp\dump_beats.txt", "w", encoding="utf-8").write("".join(out))
print("written", sum(len(x) for x in out), "chars")
