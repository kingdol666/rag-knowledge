# -*- coding: utf-8 -*-
"""Exact Laya verdict counts for hybrid-ragweak.json."""
import json
import io
import sys

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")

with open("tmp/hybrid-ragweak.json", encoding="utf-8") as f:
    d = json.load(f)

j = d["judge"]
ds = j["doc_scores"] or []
print("doc_scores n =", len(ds))
print("doc_scores[0] =", json.dumps(ds[0], ensure_ascii=False)[:400])

# try to extract per-doc best score
best = []
for x in ds:
    if isinstance(x, dict):
        s = x.get("best") or x.get("best_score") or x.get("score") or x.get("max_score")
        best.append(s)

if best and all(isinstance(b, (int, float)) for b in best):
    abs_kept = [b for b in best if b >= 0.5]
    rel_cut = j.get("relative_cut")
    rel_kept = [b for b in best if b >= 0.5 and b >= rel_cut]
    print("docs scored:", len(best))
    print("abs kept (>=0.5):", len(abs_kept))
    print("rel kept (>= rel_cut %.3f):" % rel_cut, len(rel_kept))
else:
    print("score field keys sample:", [list(x.keys()) for x in ds[:3] if isinstance(x, dict)])

print("len(abs_kept) field =", len(j.get("abs_kept") or []))
print("len(kept_doc_indices) =", len(j.get("kept_doc_indices") or []))
print("kept_total =", j.get("kept_total"))
print("scored_segments =", j.get("scored_segments"), "/ total_segments =", j.get("total_segments"))
print("global_best =", j.get("global_best"), "| relative_cut =", j.get("relative_cut"),
      "| threshold =", j.get("threshold"))

# lanes + merge + seconds
print("vector lane:", json.dumps(d["lanes"]["vector"], ensure_ascii=False))
c = d["lanes"]["catalog"]
print("catalog lane keys:", {k: c[k] for k in ("shelves_scanned", "shelves_excluded", "descriptions_scanned",
                                              "description_overlap_docs", "docs_read", "peek_docs",
                                              "zero_overlap_docs_unread", "seconds", "peek_seconds") if k in c})
print("merge:", json.dumps(d["merge"], ensure_ascii=False))
print("reread:", json.dumps(d["reread"], ensure_ascii=False))
print("expansion:", json.dumps(d["expansion"], ensure_ascii=False))
print("total seconds:", d.get("seconds"))
