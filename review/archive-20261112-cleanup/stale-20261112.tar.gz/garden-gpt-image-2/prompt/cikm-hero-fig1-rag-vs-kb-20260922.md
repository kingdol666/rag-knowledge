# CIKM Hero Figure 1 — Content-Adjudicated KB vs Conventional Dense RAG

## Rendered Prompt

A publication-ready academic teaser figure (Figure 1) for an ACM CIKM research paper on retrieval-augmented generation. Horizontal landscape composition, pure white background, flat vector diagram style, crisp geometry, clean Helvetica-style sans-serif typography, generous white space. Low-saturation engineering palette with exactly three hues: desaturated slate gray for the baseline pipeline, deep teal green (#0F766E family) for the proposed system, muted brick red only for pain-point annotations. No gradients, no 3D, no drop shadows, no photographic textures, no cartoon mascots, no decorative flourish — it must look like a top-conference paper figure, printable in grayscale.

LAYOUT: a small bold title line at top center; below it two equal side-by-side panels separated by generous whitespace with a small round "VS" badge between them; a slim full-width dark navy outcome strip along the bottom edge.

TOP TITLE (short, bold, dark navy): "Content-Adjudicated, Domain-Scoped Retrieval" with the smaller gray subtitle "vs. conventional dense RAG over a shared multi-domain corpus".

LEFT PANEL — header bar in plain gray reading "Conventional Dense RAG" with a small gray tag "single pass · fixed chunks". Inside, one left-to-right pipeline of four flat gray rounded boxes joined by thin gray arrows:
1. "Query"
2. "Single embedding index" drawn above a stack of many identical fixed-size gray document rectangles with visible mid-sentence scissor-cut marks
3. "Top-k chunks" — two of the retrieved rectangles are outlined in brick red with two tiny red callout labels: "adjacent ≠ relevant" and "one large base floods top-k"
4. "LLM answer" with a small red warning chip below it: "unverified context, chunk-level citations only".
Everything in the left panel stays gray and visually flat, deliberately plain and slightly faded.

RIGHT PANEL — header bar in deep teal with white text "Content-Adjudicated KB Protocol" and a small white tag "route · recall · adjudicate · cite". Inside, one left-to-right pipeline of five white rounded boxes with teal 1.5px outlines joined by thin teal arrows:
1. "Query rewrite"
2. "Domain router" drawn beside five small vertical drawer icons labeled as category knowledge bases
3. "Vector-first recall" with a tiny sub-label "cross-KB balanced"
4. "Content gate" with a small teal diamond below it and two branch arrows: a solid teal arrow right labeled "score ≥ 6 → generate", and a thin dashed teal loop arrow curving back to the recall box labeled "score < 6 → librarian deep retrieval"
5. "Grounded answer" with a tiny citation chip "verbatim: base · doc · part · section".
Two small teal chips under this pipeline: "irrelevant evidence filtered before generation" and "blind spots declared, never guessed".

BOTTOM STRIP — dark navy rounded bar with four short white labels evenly spaced: "same corpus, same queries" · "relevant evidence in context" · "section-level verbatim citations" · "honest abstention instead of guessing".

STYLE RULES: all shapes flat fills or thin outlines; thin 1.2px dark-gray connector arrows with small triangular heads, no crossing lines; all text short phrases, large and legible; strict alignment to an invisible grid; equal visual weight balanced so the teal right panel clearly feels more structured than the gray left panel; suitable as the opening figure of a ACM/IEEE journal or conference paper.

## Notes
- Model: gpt-image-2.5 (gateway grsaiapi.com), size 1536x1024, quality high
- Purpose: design draft; final figure is replicated 1:1 in HTML+SVG where all text is typeset exactly
