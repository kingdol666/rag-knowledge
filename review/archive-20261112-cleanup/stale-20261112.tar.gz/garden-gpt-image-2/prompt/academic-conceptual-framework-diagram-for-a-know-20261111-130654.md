Academic conceptual framework diagram for a knowledge-management systems paper. Flat 2D vector scientific illustration, Nature-journal figure quality.

Title top-left in navy serif bold: "HMRS: manage at three levels, query tier by tier". Small gray subtitle below: "The managed collection, not the query, is the primary design object".

Layout: two columns above a full-width bottom band, then a bottom strip.

LEFT COLUMN, header in navy small caps: "MANAGEMENT LEVELS - WRITE". Three stacked rectangular cards of equal width, thin navy borders, light warm-gray fill #F2F0EB. Each card has a bold navy level name and one short gray sub-label:
Card 1: "Collection" with sub-label "content-informed placement, descriptions, tags"
Card 2: "Document" with sub-label "duplicate review, move, rename, delete, re-index"
Card 3: "Segment" with sub-label "structural split, dense + lexical indices"

RIGHT COLUMN, header in amber small caps: "TIERED ACCESS PATH - READ". Four stacked rectangles connected top-to-bottom by downward amber arrows. Each has a bold navy tier name and a short gray sub-label:
"Catalogue" / "collections and descriptions"
"Shelf" / "documents in one collection"
"Document" / "open a body"
"Segment" / "score and admit"
Small gray note right of the ladder: "each tier narrows the next".

Three thin horizontal amber mapping arrows between the columns: Collection to Catalogue, Document to Shelf, Segment to Segment. Small gray label below the right column: "retrieval algorithms act only at the lower two tiers".

FULL-WIDTH BOTTOM BAND with navy border and ivory fill #FEF9F0, header "SHARED AUDITABLE STATE", containing four chips in one row: "Document files", "Tree registry .tree-fs.json", "Per-library .knowledge-base.yml", "Search indices". Thin vertical gray connectors from both columns down into this band.

BOTTOM STRIP: three numbered contract tags in one row, amber numerals and navy text:
"1 Content classifies the collection"
"2 A tier narrows before it answers"
"3 Scope is reported, not assumed"

Style: warm paper-white background #FAF9F6; deep navy #1B2A4A primary; warm amber gold #C8963E accent; warm gray #E5E0D8 dividers; gray #6B6760 secondary text; Georgia-style serif labels; precise 1-2pt consistent stroke weights; right-angle corners; no rounded corners, no drop shadows, no gradients, no 3D, no photographic textures, no emoji; generous whitespace (about 30%); all English labels rendered exactly as specified with correct spelling; no quantitative data, no invented numbers, no extra text beyond the labels listed.
