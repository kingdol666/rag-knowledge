Academic two-lane pipeline diagram for a knowledge-management systems paper. Flat 2D vector scientific illustration, Nature-journal figure quality, minimal and geometrically precise.

Title top-left in navy serif bold: "HMRS end-to-end workflow". Small gray subtitle: "Document maintenance and question answering share one knowledge state".

TOP LANE, left label in navy small caps: "DOCUMENT PATH". A horizontal left-to-right flow of five equal-size rectangular stage blocks, light warm-gray fill #F2F0EB, thin navy borders, connected by thin navy arrows with small triangle heads. Each block has a bold navy name and one short gray sub-label:
"Parse" / "MinerU, quality review"
"Place" / "content-informed library choice"
"Store" / "files, registry, metadata"
"Index" / "dense + BM25, separate step"
"Probe" / "post-index retrievability check"
At the far left, a small document glyph labeled "Raw document" with an arrow into Parse.

MIDDLE FULL-WIDTH BAND, ivory fill #FEF9F0, thin navy border, header "SHARED KNOWLEDGE STATE", four chips in one row: "Document files", "Tree registry", "Library metadata", "Search indices". Downward amber arrows from Store and Index into this band; upward amber arrows from the band into the first two blocks of the bottom lane.

BOTTOM LANE, left label in amber small caps: "QUERY PATH". Horizontal flow starting with a small question glyph labeled "Question", then five equal-size blocks connected by thin navy arrows:
"Catalogue" / "select collection"
"Shelf" / "select documents"
"Document" / "open body"
"Segment" / "score parts"
"Evidence gate" / "Laya, optional call" (this block has an amber border and ivory fill to mark it optional)
At the far right, two stacked output boxes: a navy-filled box with white text "Answer + provenance", and below it a gray-bordered box "Scoped not-found". Small gray note under the outputs: "not-found only after a completed search".
A dashed gray branch from the bottom lane to a small tag: "timeout or fetch failure = incomplete execution".
Small gray annotation above the bottom lane: "each tier narrows the next; rank is advisory".

Style: warm paper-white background #FAF9F6; deep navy #1B2A4A primary; warm amber gold #C8963E accent; gray #6B6760 secondary text; warm gray #E5E0D8 dividers; Georgia-style serif labels; precise 1-2pt strokes; right-angle corners; all stage blocks identical size and aligned baselines; arrows never cross blocks and labels never collide; no rounded corners, no drop shadows, no gradients, no 3D, no emoji, no cartoon icons; all English text rendered exactly as specified with correct spelling; no invented numbers or quantitative data; no extra text beyond the labels listed.
