Smoke test: a single deep-blue rounded square centered on a plain white background, minimal flat vector style, no text.
