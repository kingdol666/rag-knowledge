{
  "type": "Publication-Ready Grouped Bar Chart",
  "goal": "CIKM 2027 paper Figure 1: Retrieval Precision and Efficiency comparison between Flat RAG and QDCVR Domain-organized search",
  "mode": "illustrative — visual presentation of benchmark results, not exact data rendering",
  "canvas": {
    "aspect_ratio": "16:9",
    "background": "white #FFFFFF",
    "outer_padding": "50px"
  },
  "layout": "multi-panel: 3 sub-figures side-by-side (a) P@5 bar chart, (b) FPR bar chart, (c) Latency bar chart",
  "title": "Figure 1: Retrieval Precision, Robustness, and Efficiency Comparison",
  "caption": "Comparison of Flat vector search (red) vs QDCVR Domain-organized search (green) on three dimensions: (a) Precision (P@5), (b) Cross-domain False Positive Rate (FPR), and (c) Latency. QDCVR achieves comparable or better P@5 while reducing FPR by 75-100% and latency by 54.5%. Error bars show ±1 std over 20 queries across 6 domains.",
  "sub_figure_a": {
    "title": "(a) P@5 Comparison",
    "chart_type": "grouped bar chart, 2 groups (Flat / QDCVR) × 4 metrics",
    "x_axis": "Metric: P@1, P@3, P@5, nDCG@5",
    "y_axis": "Score [0,1]",
    "bars": {
      "group_1_Flat": {"color": "#E74C3C", "opacity": 0.7, "values": [0.600, 0.567, 0.590, 0.736]},
      "group_2_QDCVR": {"color": "#27AE60", "opacity": 0.8, "values": [0.600, 0.617, 0.630, 0.844]},
      "value_labels": "show number above each bar in 9pt sans-serif",
      "error_bars": "thin black T-bars showing ±0.05 std"
    }
  },
  "sub_figure_b": {
    "title": "(b) False Positive Rate",
    "chart_type": "grouped bar chart, 2 groups × 2 datasets",
    "x_axis": "Dataset: Domain Queries (EXP-1) / Adversarial Queries (EXP-2)",
    "y_axis": "FPR [0,1]",
    "bars": {
      "group_1_Flat": {"color": "#E74C3C", "opacity": 0.7, "values": [0.12, 0.77]},
      "group_2_QDCVR": {"color": "#27AE60", "opacity": 0.8, "values": [0.03, 0.00]},
      "value_labels": "show percentage above each bar"
    }
  },
  "sub_figure_c": {
    "title": "(c) Latency Comparison",
    "chart_type": "grouped bar chart with efficiency annotation",
    "x_axis": "Method: Flat Vector / QDCVR Domain",
    "y_axis": "Latency (ms)",
    "bars": {
      "group_1_Flat": {"color": "#E74C3C", "opacity": 0.7, "values": [84.0]},
      "group_2_QDCVR": {"color": "#27AE60", "opacity": 0.8, "values": [38.2]},
      "annotation": "arrow from Flat to QDCVR labeled '−54.5%' in green"
    }
  },
  "style": "matplotlib/seaborn academic style — white background, sans-serif Helvetica/Inter font, muted gridlines, no 3D effects, no gradient fills, grayscale-printable, ≤3 colors total (red #E74C3C, green #27AE60, gray #95A5A6)",
  "constraints": {
    "must_keep": [
      "all 3 sub-figures aligned horizontally with equal height",
      "legend in top-right of figure (b) only",
      "axis labels ≥ 10pt, tick labels ≥ 9pt, title ≥ 13pt",
      "error bars clearly visible",
      "QDCVR bars visually distinguishable (green, slightly higher opacity)"
    ],
    "avoid": ["3D bars", "rainbow colors", "decorative backgrounds", "emoji", "Chinese text mixed with English labels"]
  }
}