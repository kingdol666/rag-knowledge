{
  "type": "学术论文方法 Pipeline 总览图 (CVPR/NeurIPS style)",
  "goal": "CIKM 2027 paper Figure 2: QDCVR (Query-Document Content Verification Retrieval) system architecture pipeline — illustrating the 'Organize First, Retrieve Later' paradigm",
  "canvas": {
    "aspect_ratio": "16:9",
    "background": "pure white #FFFFFF",
    "outer_padding": "50px"
  },
  "figure_label": "Figure 2.",
  "caption": "Overview of the QDCVR retrieval pipeline. Unlike flat RAG which searches all 13,709 chunks indiscriminately, QDCVR first selects the relevant Knowledge Base (KB) via domain-aware catalog lookup, then performs two-stage retrieval (BM25 keyword + vector semantic) scoped to that KB. Content Verification (0-8 rubric) overrides vector scores for low-content high-score false positives. Results are tiered (P0/P1/P2) with blind-spot declarations.",
  "input": {
    "label": "User Query",
    "thumbnail": "a text bubble containing example query 'battery thermal management phase change material liquid cooling PCM'",
    "position": "leftmost"
  },
  "stages": {
    "count": 5,
    "items": [
      {
        "id": "S0",
        "name": "Query Understanding",
        "glyph": "a magnifying glass over a text snippet with keywords highlighted (e.g. 'thermal', 'management', 'battery', 'PCM')",
        "sub_label": "Keyword extraction + intent detection"
      },
      {
        "id": "S1",
        "name": "KB Selection",
        "glyph": "a tree/hierarchy icon with 13 KB nodes, one highlighted in green (Energy-Batteries selected)",
        "sub_label": "Catalog lookup via kb_list() → 13 KB → 1 selected"
      },
      {
        "id": "S2",
        "name": "Two-Stage Recall",
        "glyph": "split box: left half 'BM25 Keyword' with inverted index icon, right half 'Vector Semantic' with BGE-M3 embedding vector icon, merged by arrow",
        "sub_label": "Stage1: BM25+Graph candidates → Stage2: Vector fine-search"
      },
      {
        "id": "S3",
        "name": "Content Verification",
        "glyph": "a checklist/rubric icon with 0-8 score — green checkmark on '6-8 Accept', orange on '5 Supplement', red X on '0-4 Discard'",
        "sub_label": "0-8 rubric: content-overrides-vector"
      },
      {
        "id": "S4",
        "name": "Confidence Tiering",
        "glyph": "three stacked cards labeled 'P0 (High Confidence)', 'P1 (Medium)', 'P2 (Weak)', with blind-spot flag on the bottom",
        "sub_label": "Tier assignment + blind-spot declaration"
      }
    ]
  },
  "output": {
    "label": "Ranked Results",
    "thumbnail": "a ranked list of 5 document cards with scores, tier badges, and confidence levels — top result highlighted",
    "position": "rightmost"
  },
  "stage_block_style": {
    "shape": "rounded rectangle, corner radius 6px",
    "size": "140px × 100px each, all identical",
    "fill": "S0+S1: light blue #EBF5FB, S2+S3: light amber #FEF9C3, S4: light green #E8F8F5",
    "border": "1.2px solid #334155",
    "title_font": "Helvetica Bold 11pt",
    "sub_label_font": "Helvetica Italic 8pt gray"
  },
  "connectors": {
    "style": "thin black arrows (1.2px) with triangle arrowheads, horizontal flow left→right",
    "between_stages": "arrow from right edge of S_i to left edge of S_{i+1}",
    "skip_connection": {
      "enabled": true,
      "from": "S0",
      "to": "S3",
      "style": "dashed curved arrow above main flow",
      "label": "direct query (no KB context)"
    }
  },
  "annotation_boxes": {
    "top": "a callout box at top-center: 'Search Space: 13,709 chunks (Flat) → ~10-600 chunks (Domain) = ×1000+ reduction' with green highlight",
    "bottom": "a small box at bottom: '71 MCP Tools | 14 Skills | BGE-M3 1024-dim | ChromaDB + Neo4j'"
  },
  "color_palette": "deep blue #2C3E8F (accent), slate #334155 (borders), light tints for stage fills, green #27AE60 (positive indicators)",
  "constraints": {
    "must_keep": [
      "all 5 stage blocks identical size, vertically aligned center",
      "horizontal flow left to right, clearly numbered S0-S4",
      "arrows must not overlap stage blocks",
      "monochrome-printable (grayscale still readable)",
      "looks like it came from a CVPR/NeurIPS PDF"
    ],
    "avoid": ["3D effects", "drop shadows", "gradients", "cartoon icons", "emoji", "photo backgrounds in blocks"]
  }
}