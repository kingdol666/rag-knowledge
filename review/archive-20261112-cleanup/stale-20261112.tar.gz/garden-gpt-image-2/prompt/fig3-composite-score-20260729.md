{
  "type": "Publication-Ready Radar Chart + Grouped Comparison",
  "goal": "CIKM 2027 paper Figure 3: Composite Score Radar Chart showing QDCVR's 11-dimension performance profile, plus Cross-Domain FPR elimination evidence",
  "canvas": {
    "aspect_ratio": "16:9",
    "background": "white #FFFFFF",
    "outer_padding": "50px"
  },
  "figure_label": "Figure 3.",
  "caption": "(a) Radar chart showing QDCVR's composite benchmark score across 11 evaluation dimensions. Robustness (1.00), Reliability (0.95), Consistency (0.90), and Agent completeness (0.90) are the strongest dimensions. (b) Cross-domain False Positive Rate comparison: QDCVR Domain-organized search eliminates essentially all cross-domain pollution across both domain-specific and adversarial queries, while Flat vector search yields FPR of 12-77%. (c) Efficiency-Accuracy trade-off: QDCVR achieves both higher P@5 and lower latency than Flat vector search.",
  "layout": "3 sub-figures: (a) top-left radar chart, (b) top-right grouped bar chart, (c) bottom scatter plot spanning full width",
  "sub_figure_a": {
    "title": "(a) Composite Score Profile",
    "chart_type": "radar chart, 11 axes",
    "axes_labels": ["Retrieval (0.20)", "Efficiency (0.12)", "Robustness (0.15)", "DocMgmt (0.10)", "Experience (0.08)", "Agent (0.06)", "Consistency (0.06)", "Diversity (0.05)", "Reliability (0.05)", "ParseQuality (0.07)", "Meditation (0.06)"],
    "data_series": [{"label": "QDCVR", "values": [0.641, 0.543, 1.000, 0.850, 0.800, 0.900, 0.900, 0.660, 0.950, 0.850, 0.700], "fill_color": "rgba(44,62,143,0.15)", "line_color": "#2C3E8F", "line_width": 2.5}],
    "scale": "0 to 1, concentric rings at 0.2 intervals, grid lines light gray dashed"
  },
  "sub_figure_b": {
    "title": "(b) Cross-Domain FPR Elimination",
    "chart_type": "grouped bar chart, 2 groups × 2 conditions",
    "x_axis": "Query Type: Domain Queries (EXP-1) / Adversarial Queries (EXP-2)",
    "y_axis": "False Positive Rate",
    "bars": {
      "Flat_Vector": {"color": "#E74C3C", "opacity": 0.7, "values": [0.12, 0.77]},
      "QDCVR_Domain": {"color": "#27AE60", "opacity": 0.8, "values": [0.03, 0.00]},
      "value_labels": "12%, 77%, 3%, 0% above bars",
      "significance": "*** between groups for adversarial queries"
    }
  },
  "sub_figure_c": {
    "title": "(c) Efficiency-Accuracy Trade-off",
    "chart_type": "scatter plot with Pareto frontier arrow",
    "x_axis": "Latency (ms), log-friendly scale 10-100",
    "y_axis": "P@5 Score [0,1]",
    "points": [
      {"label": "Flat Vector", "x": 84, "y": 0.64, "color": "#E74C3C", "size": 10, "shape": "circle"},
      {"label": "QDCVR Domain", "x": 39, "y": 0.74, "color": "#27AE60", "size": 14, "shape": "circle", "border": "2px black"},
      {"label": "Two-Stage", "x": 538, "y": 0.00, "color": "#95A5A6", "size": 8, "shape": "triangle"}
    ],
    "annotation": "green curved arrow from Flat to QDCVR labeled '2.5× efficiency gain'",
    "quadrant_labels": "top-left = 'Better' (high P@5, low latency)"
  },
  "style": "matplotlib/seaborn publication style — white background, sans-serif, ≤4 colors, clean gridlines, no 3D",
  "colors": {
    "primary": "#2C3E8F",
    "ours": "#27AE60",
    "baseline": "#E74C3C",
    "neutral": "#95A5A6"
  },
  "constraints": {
    "must_keep": ["three sub-figures clearly labeled (a)(b)(c)", "all text ≥ 9pt", "grayscale readable", "consistent color scheme across sub-figures"],
    "avoid": ["3D pie charts", "photo backgrounds", "decorative elements", "emoji"]
  }
}